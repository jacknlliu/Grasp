/** @file Model.h
 *
 * Model density
 *
 * @author Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_CONTACT_MODEL_H_
#define _GRASP_CONTACT_MODEL_H_

//------------------------------------------------------------------------------

#include <Grasp/Core/Triangle.h>
#include <Grasp/App/Recorder/Data.h>

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** Point3D Appearance */
class Point3DAppearance {
public:
	/** Point colour */
	golem::RGBA colour;

	/** Constructs description. */
	Point3DAppearance() {
		setToDefault();
	}
	/** Sets the parameters to the default values. */
	void setToDefault() {
		colour = golem::RGBA::BLACK;
	}
	/** Assert that the description is valid. */
	void assertValid(const Assert::Context& ac) const {
	}
	/** Load descritpion from xml context. */
	void load(const golem::XMLContext* xmlcontext);
	/** Draw */
	void draw(const data::Point3D::Point::Seq& points, golem::DebugRenderer& renderer) const;
};

//------------------------------------------------------------------------------

/** Contact represents average point "seen" in the local frame of a given shape (bounds) */
class Contact3D : public golem::Sample<golem::Real> {
public:
	/** Collection */
	typedef std::vector<Contact3D> Seq;
	/** Collection */
	typedef std::vector<Seq*> SeqPtrSeq;
	/** Collection */
	typedef std::map<std::string, Seq> Map;

	/** Default floating point */
	typedef golem::F32 Real;
	/** Default 3D vector */
	typedef golem::_Vec3<Real> Vec3;
	/** Triangle */
	typedef grasp::_Triangle<Real> Triangle;

	/** Contact type */
	enum Type {
		/** Point */
		TYPE_POINT,
		/** Normal */
		TYPE_NORMAL,
		/** Feature */
		TYPE_FEATURE,
		/** Part */
		TYPE_PART3D,
	};

	/** Contact type name string */
	static const char* typeName[TYPE_PART3D + 1];

	/** Contact relation */
	enum Relation {
		/** None/Undefined */
		RELATION_NONE,
		/** Default/all types */
		RELATION_DFLT,
		/** Volume */
		RELATION_VOLUME,
		/** Surface */
		RELATION_SURFACE,
		/** Edge/line */
		RELATION_EDGE,
		/** Vertex/point */
		RELATION_VERTEX,
	};

	/** Contact relation name string */
	static const char* relationName[RELATION_VERTEX + 1];
	/** Contact relation colour */
	static golem::RGBA relationColour[RELATION_VERTEX + 1];

	/** Appearance */
	class Appearance {
	public:
		/** Collection */
		typedef std::map<std::string, Appearance> Map;

		/** Show points */
		bool pointsShow;
		/** Show frames */
		bool framesShow;
		/** Contact colour */
		golem::RGBA colour[Contact3D::RELATION_VERTEX + 1];
		/** Contact frame axes size */
		golem::Vec3 frameSize;
		/** Show frame */
		bool boundsFrameShow;
		/** Frame axes size */
		golem::Vec3 boundsFrameSize;

		/** Contact relation */
		mutable Contact3D::Relation relation;

		/** Constructs description. */
		Appearance() {
			setToDefault();
		}
		/** Sets the parameters to the default values. */
		void setToDefault() {
			pointsShow = true;
			framesShow = true;
			std::copy(Contact3D::relationColour, Contact3D::relationColour + sizeof(Contact3D::relationColour) / sizeof(golem::RGBA), colour);
			frameSize.set(golem::Real(0.002));
			boundsFrameShow = true;
			boundsFrameSize.set(golem::Real(0.01));

			relation = Contact3D::RELATION_NONE;
		}
		/** Assert that the description is valid. */
		void assertValid(const Assert::Context& ac) const {
			Assert::valid(frameSize.isPositive(), ac, "frameSize: <= 0");
			Assert::valid(boundsFrameSize.isPositive(), ac, "boundsFrameSize: <= 0");
		}
		/** Load descritpion from xml context. */
		void load(const golem::XMLContext* xmlcontext);
	};

	/** Contact creator description */
	class Desc {
	public:
		/** Point cloud subsampling */
		golem::U32 subsampleSize;
		/** Maximum distance */
		golem::Real distance;
		/** Likelihood ~ exp(-lambda*distance) */
		golem::Real lambda;
		/** Maximum normal slope */
		golem::Real normalSlope;
		/** Min number of contacts */
		golem::U32 minNum;

		/** Constructs description. */
		Desc() {
			setToDefault();
		}
		/** Sets the parameters to the default values. */
		void setToDefault() {
			subsampleSize = 0;
			distance = golem::Real(0.01);
			lambda = golem::Real(100.0);
			normalSlope = golem::REAL_PI;
			minNum = 100;
		}
		/** Assert that the description is valid. */
		void assertValid(const Assert::Context& ac) const {
			Assert::valid(distance > golem::REAL_ZERO, ac, "distance: <= 0");
			Assert::valid(lambda > golem::REAL_ZERO, ac, "lambda: <= 0");
			Assert::valid(normalSlope > golem::REAL_ZERO, ac, "normalSlope: <= 0");
			Assert::valid(minNum > 0, ac, "minNum: <= 0");
		}
		/** Load descritpion from xml context. */
		void load(const golem::XMLContext* xmlcontext);
	};

	/** Point/feature/parts point (can be different than frame for parts) */
	golem::Vec3 point;
	/** Point normal (quaternion x, y, z) or feature/parts orientation (quaternion x, y, z, w) */
	golem::Quat orientation;
	/** Point/feature/parts local (inverse) frame: transformation frame - shape frame (in the feature/parts body frame) */
	grasp::RBCoord frame;

	/** Feature vector */
	data::Feature3D::Feature feature;
	/** Parts id */
	golem::U64 id;

	/** Surface distance, zero if intersects with shape */
	golem::Real distance;
	/** Projection onto the nearest surface point in the local frame */
	golem::Vec3 projection;
	/** Contact3D contact relation */
	Relation relation;

	/** Find relation */
	static void find(const Triangle::Seq& triangles, const golem::Vec3& point, golem::Real& distance, golem::Vec3& projection, Relation& relation);

	/** Draw contact at given pose */
	void draw(const Appearance& appearance, const golem::Mat34& pose, golem::DebugRenderer& renderer) const;
	/** Draw contacts at given pose */
	static void draw(const Appearance& appearance, const Seq& contacts, const golem::Mat34& pose, golem::DebugRenderer& renderer);

	/** Reset weights */
	Contact3D(golem::Real weight = golem::REAL_ONE, golem::Real cdf = -golem::REAL_ONE) : golem::Sample<golem::Real>(weight, cdf), id(0) {}
};

/** Reads/writes object from/to a given XML context */
void XMLData(const std::string &attr, Contact3D::Type& val, golem::XMLContext* context, bool create = false);

//------------------------------------------------------------------------------

/** Model density */
class Model {
public:
	typedef golem::shared_ptr<Model> Ptr;
	/** Collection */
	typedef std::map<std::string, Ptr> Map;

	/** Mesh collection */
	typedef std::vector<const golem::BoundingConvexMesh*> MeshSeq;

	/** Description */
	class Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;
		/** Collection */
		typedef std::map<std::string, Ptr> Map;

		/** Contact type */
		Contact3D::Type contact3DType;
		/** Contact description */
		Contact3D::Desc contact3DDesc;

		/** Constructs description object */
		Desc() {
			Desc::setToDefault();
		}
		virtual ~Desc() {}
		/** Creates the object from the description. */
		virtual Model::Ptr create(golem::Context& context, const std::string& name) const {
			return Model::Ptr(new Model(*this, context, name));
		}
		/** Sets the parameters to the default values. */
		void setToDefault() {
			contact3DType = Contact3D::TYPE_POINT;
			contact3DDesc.setToDefault();
		}
		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			contact3DDesc.assertValid(Assert::Context(ac, "contact3DDesc."));
		}
		/** Load descritpion from xml context. */
		virtual void load(const golem::XMLContext* xmlcontext);
	};

	/** Create 3D contact model density */
	virtual bool create(const data::Point3D::ConstSeq& points, const golem::Mat34& pose, const golem::Bounds::Seq& bounds, Contact3D::Seq& contacts) const;
	/** Create 3D contact model density */
	virtual bool create(const data::Point3D::ConstSeq& points, const golem::Mat34& pose, const grasp::Contact3D::Triangle::Seq& triangles, Contact3D::Seq& contacts) const;

	/** Model density name */
	const std::string& getName() const {
		return name;
	}

	/** Model density description */
	Desc& getDesc() {
		return desc;
	}
	const Desc& getDesc() const {
		return desc;
	}

	/** Bye bye */
	virtual ~Model() {}

protected:
	/** Context object */
	golem::Context &context;
	/** Parallels */
	golem::Parallels* parallels;

	/** Model density name */
	const std::string name;
	/** Model density description */
	Desc desc;

	/** Create 3D contact model density */
	virtual bool create(const data::Point3D& points, const golem::Mat34& pose, const grasp::Contact3D::Triangle::Seq& triangles, Contact3D::Seq& contacts) const;

	/** Converts bounds to triangles */
	static void convert(const golem::Bounds::Seq& bounds, grasp::Contact3D::Triangle::Seq& triangles);

	/** Creates Model */
	Model(const Desc& desc, golem::Context& context, const std::string& name);
};

void XMLData(grasp::Contact3D::Appearance::Map::value_type& val, golem::XMLContext* context, bool create = false);
void XMLData(grasp::Model::Desc::Map::value_type& val, golem::XMLContext* context, bool create = false);

//------------------------------------------------------------------------------

};	// namespace

//------------------------------------------------------------------------------

namespace golem {
	template <> void Stream::read(grasp::Contact3D::Map::value_type& value) const;
	template <> void Stream::write(const grasp::Contact3D::Map::value_type& value);
};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_CONTACT_MODEL_H_*/
