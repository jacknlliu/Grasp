/** @file Data.h
 * 
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_CONTACT_DATA_H_
#define _GRASP_CONTACT_DATA_H_

//------------------------------------------------------------------------------

#include <Grasp/Core/Ctrl.h>
#include <Grasp/Core/Data.h>
#include <Grasp/App/Recorder/Data.h>
#include <Grasp/Contact/Model.h>
#include <Grasp/Contact/Query.h>
#include <Grasp/Contact/Configuration.h>
#include <Grasp/Contact/Cluster.h>
#include <vector>
#include <map>

//------------------------------------------------------------------------------

namespace grasp {
namespace data {

//------------------------------------------------------------------------------

/** Contact model data interface.
*	(Optionally) Implemented by Item.
*/
class ContactModel {
public:
	class Data {
	public:
		/** Data collection: name -> data */
		typedef std::map<std::string, Data> Map;

		/** Appearance */
		class Appearance {
		public:
			/** Show path */
			bool pathShow;
			/** Path appearance */
			Configuration::Path::Appearance path;

			/** Contacts appearance */
			Contact3D::Appearance::Map contacts;
			/** Show contact relations */
			Contact3D::Relation relation;

			/** Show point */
			bool pointShow;
			/** Point colour */
			Point3DAppearance point;

			/** Constructs description. */
			Appearance() {
				setToDefault();
			}
			/** Sets the parameters to the default values. */
			void setToDefault() {
				pathShow = true;
				path.setToDefault();
				contacts.insert(std::make_pair(Manipulator::Link(Manipulator::Link::TYPE_ANY).toString(), Contact3D::Appearance()));
				relation = Contact3D::RELATION_DFLT;
				pointShow = true;
				point.setToDefault();
			}
			/** Assert that the description is valid. */
			void assertValid(const Assert::Context& ac) const {
				path.assertValid(Assert::Context(ac, "path."));

				Assert::valid(!contacts.empty(), ac, "contacts: empty");
				for (Contact3D::Appearance::Map::const_iterator i = contacts.begin(); i != contacts.end(); ++i)
					i->second.assertValid(Assert::Context(ac, "contacts[]."));

				point.assertValid(Assert::Context(ac, "point."));
			}
			/** Load descritpion from xml context. */
			void load(const golem::XMLContext* xmlcontext);
		};

		/** Paths */
		Configuration::Path::Seq paths;
		/** Configuration model */
		Configuration::Kernel::Seq configs;
		/** Contact model */
		Contact3D::Map contacts;
		/** Points */
		Point3D::Point::Seq points;

		/** Draw training data */
		void draw(const Configuration& configuration, const Appearance& appearance, golem::U32 pathIndex, golem::DebugRenderer& renderer) const;
	};

	/** Sets contact model data. */
	virtual void setData(const ContactModel::Data::Map& dataMap) = 0;
	/** Returns contact model data. */
	virtual const ContactModel::Data::Map& getData() const = 0;
};

//------------------------------------------------------------------------------

/** Contact query data interface.
*	(Optionally) Implemented by Item.
*/
class ContactQuery {
public:
	class Data {
	public:
		/** Appearance */
		class Appearance {
		public:
			/** Config appearance */
			Contact::Config::Appearance config;

			/** Show point */
			bool pointShow;
			/** Point colour */
			Point3DAppearance point;

			/** Constructs description. */
			Appearance() {
				setToDefault();
			}
			/** Sets the parameters to the default values. */
			void setToDefault() {
				config.setToDefault();
				pointShow = true;
				point.setToDefault();
			}
			/** Assert that the description is valid. */
			void assertValid(const Assert::Context& ac) const {
				config.assertValid(Assert::Context(ac, "config."));
				point.assertValid(Assert::Context(ac, "point."));
			}
			/** Load descritpion from xml context. */
			void load(const golem::XMLContext* xmlcontext);
		};

		/** Configs */
		Contact::Config::Seq configs;
		/** Clusters */
		Cluster::Seq clusters;
		/** Points */
		Point3D::Point::Seq points;
	};

	/** Sets contact query data. */
	virtual void setData(const ContactQuery::Data& data) = 0;
	/** Returns contact query data. */
	virtual const ContactQuery::Data& getData() const = 0;
};

//------------------------------------------------------------------------------

};	// namespace
};	// namespace

//------------------------------------------------------------------------------

namespace golem {
	template <> GOLEM_LIBRARY_DECLDIR void Stream::read(grasp::data::ContactModel::Data::Map::value_type& value) const;
	template <> GOLEM_LIBRARY_DECLDIR void Stream::write(const grasp::data::ContactModel::Data::Map::value_type& value);
};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_CONTACT_DATA_H_*/
