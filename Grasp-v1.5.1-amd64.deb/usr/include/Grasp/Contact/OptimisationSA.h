/** @file OptimisationSA.h
 *
 * Contact optimisation using simulated annealing (SA)
 *
 * @author Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_CONTACT_OPTIMISATIONSA_H_
#define _GRASP_CONTACT_OPTIMISATIONSA_H_

//------------------------------------------------------------------------------

#include <Grasp/Contact/Contact.h>
#include <Grasp/Contact/OptimisationEvalCPU.h>

//------------------------------------------------------------------------------

// Optimisation debug
//#define _GRASP_CONTACT_OPTIMISATION_DEBUG

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** Contact optimisation using CPU */
class OptimisationSA : public Contact::Optimisation {
public:
	/** Configuration model */
	typedef EvalConfigModelCPU<golem::F32, golem::F32> ConfigModel;
	/** Contact model */
	typedef EvalContactModelCPU<golem::F32, golem::F32> ContactModel;

	/** Optimisation description */
	class Desc : public Contact::Optimisation::Desc {
	public:
		/** number of runs */
		size_t runs;
		/** number of steps per run */
		size_t steps;
		/** number of tries per run */
		size_t tries;

		/** Simulated annealing minimum temperature */
		golem::Real saTemp;
		/** Simulated annealing temperature to local coordinate scaling factor */
		grasp::RBDist saDelta;
		/** Simulated annealing temperature to energy scaling factor */
		golem::Real saEnergy;

		/** Component validity test */
		golem::Real epsilon;

		/** Collisions during last optimisation step */
		bool collisionLast;
		/** Collisions during all optimisation steps */
		bool collisionAll;

		/** Constructs description object */
		Desc() {
			Desc::setToDefault();
		}
		/** Creates the object from the description. */
		virtual Contact::Optimisation::Ptr create(Contact& contact) const {
			return Contact::Optimisation::Ptr(new OptimisationSA(contact, *this));
		}
		/** Sets the parameters to the default values */
		virtual void setToDefault() {
			runs = 500;
			steps = 500;
			tries = 100;

			saTemp = golem::Real(0.1);
			saDelta.set(golem::Real(1.0), golem::Real(1.0));
			saEnergy = golem::Real(0.5);
			epsilon = golem::REAL_EPS;

			collisionLast = true;
			collisionAll = false;
		}
		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			Assert::valid(runs > 0, ac, "runs: <= 0");
			Assert::valid(saTemp >= golem::REAL_ZERO, ac, "saTemp: < 0");
			Assert::valid(saDelta.isValid(), ac, "saDelta: invalid");
			Assert::valid(saEnergy > golem::REAL_ZERO, ac, "saEnergy: <= 0");
			Assert::valid(golem::Math::isFinite(epsilon), ac, "epsilon: invalid");
		}
		/** Load descritpion from xml context. */
		virtual void load(const golem::XMLContext* xmlcontext);
	};

	/** Initialisation */
	virtual void create(const data::Point3D& points);
	/** Optimisation: find initial solutions */
	virtual Contact::Config::Seq::iterator find(Contact::Config::Seq& configs, Contact::Config::Seq::iterator ptr);
	/** Optimisation: improve specified solutions [begin, end), using steps [beginStep, endStep], where: 0 <= beginStep < endStep <= 1 */
	virtual void find(Contact::Config::Seq::const_iterator begin, Contact::Config::Seq::const_iterator end, golem::Real beginStep, golem::Real endStep);

	/** Link contacts */
	const ContactModel::Seq& getLinks() const {
		return links;
	}
	/** Base contacts */
	const ContactModel& getBase() const {
		return base;
	}

protected:
	golem::Parallels* parallels;
	const grasp::Manipulator& manipulator;
	const grasp::Configuration& configuration;
	const Desc desc;
	
	/** Manipulator pose distribution standard deviation */
	grasp::RBDist poseStdDev;
	/** Manipulator pose distribution covariance */
	grasp::RBDist poseCovInv;
	/** Manipulator configuration distribution standard deviation */
	golem::ConfigspaceCoord configStdDev;

	/** Configuration model */
	ConfigModel config;
	/** Link contacts */
	ContactModel::Seq links;
	/** Base contacts */
	ContactModel base;
	/** Collision models */
	Collision::Seq collision;

	void evaluate(golem::U32 jobId, const grasp::Manipulator::Waypoint& waypoint, grasp::Contact::Likelihood& likelihood) const;
	void evaluate(golem::U32 jobId, const grasp::Configuration::Path& path, grasp::Contact::Likelihood& likelihood, bool collisions = false) const;
	bool isFeasible(const grasp::Configuration::Path& path) const;

	/** Create and copy description */
	OptimisationSA(Contact& contact, const Desc& desc);
};

//------------------------------------------------------------------------------

};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_CONTACT_OPTIMISATIONSA_H_*/
