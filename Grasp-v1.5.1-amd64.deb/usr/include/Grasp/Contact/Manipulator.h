/** @file Manipulator.h
 *
 * Grasp manipulator interface
 *
 * @author Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_CONTACT_MANIPULATOR_H_
#define _GRASP_CONTACT_MANIPULATOR_H_

//------------------------------------------------------------------------------

#include <Grasp/Core/Defs.h>
#include <Grasp/Core/Ctrl.h>
#include <Grasp/Core/RB.h>
#include <Golem/Plan/Planner.h>
#include <Golem/UI/Renderer.h>
#include <Golem/Math/VecN.h>

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** Manipulator arm + hand proxy */
class Manipulator {
public:
	typedef golem::shared_ptr<Manipulator> Ptr;

	/** Control vector coordinates */
	typedef golem::_VecN<golem::Real, (size_t)golem::Configspace::DIM> ControlCoord;
	/** Configspace map */
	typedef golem::ScalarCoord<golem::I32, golem::Configspace> ConfigspaceMap;

	/** Command -> Control */
	typedef std::function<void(const golem::Controller::State&, ControlCoord&)> CommandToControl;
	/** Control -> Command */
	typedef std::function<void(const ControlCoord&, golem::Controller::State&)> ControlToCommand;

	/** Link identifier */
	class Link {
	public:
		/** Link type */
		enum Type {
			/** Any link */
			TYPE_ANY = -1,
			/** Base */
			TYPE_BASE = -2,
			/** Chain */
			TYPE_CHAIN = -3,
			/** Joint */
			TYPE_JOINT = 0,
		};

		/** Sets default values */
		Link(Type type = TYPE_ANY, golem::U32 index = 0) {
			set(type, index);
		}
		/** Conversion from string */
		Link(const std::string& str) {
			fromString(str);
		}

		/** Link id */
		golem::I32 getID() const {
			return id;
		}

		/** Get type */
		Type getType() const {
			return id < TYPE_JOINT ? id > TYPE_CHAIN ? Type(id) : TYPE_CHAIN : TYPE_JOINT;
		}
		/** Get index */
		golem::U32 getIndex() const {
			return id < TYPE_JOINT ? id > TYPE_CHAIN ? 0 : TYPE_CHAIN - id : id - TYPE_JOINT;
		}

		/** Get joint index */
		golem::Configspace::Index getJoint() const {
			if (id < TYPE_JOINT)
				throw golem::Message(golem::Message::LEVEL_ERROR, "Manipulator::Link::getJoint(): not a joint!");
			return golem::Configspace::Index(id - TYPE_JOINT);
		}
		/** Get chain index */
		golem::Chainspace::Index getChain() const {
			if (id > TYPE_CHAIN)
				throw golem::Message(golem::Message::LEVEL_ERROR, "Manipulator::Link::getChain(): not a chain!");
			return golem::Chainspace::Index(TYPE_CHAIN - id);
		}
		
		/** Set type and index */
		void set(Type type = TYPE_ANY, golem::U32 index = 0) {
			id = type != TYPE_JOINT ? type != TYPE_CHAIN ? golem::I32(type) : golem::I32(TYPE_CHAIN) - index : golem::I32(TYPE_JOINT) + index;
		}

		/** Link name */
		const std::string& getName(Type type) const {
			return name[golem::I32(type) + 3];
		}

		/** Link name */
		std::string toString() const {
			const Type type = getType();
			std::string name = getName(type);
			if (type == TYPE_JOINT) name += std::to_string(getIndex() + 1);
			return name;
		}
		/** Link id */
		void fromString(const std::string& str) {
			if (str.find_first_of(getName(TYPE_JOINT)) == 0)
				set(TYPE_JOINT, (golem::U32)golem::Math::clamp(std::atoi(&str[getName(TYPE_JOINT).length()]), int(1), int(golem::Configspace::DIM)) - 1);
			else if (str.find_first_of(getName(TYPE_CHAIN)) == 0)
				set(TYPE_CHAIN, (golem::U32)golem::Math::clamp(std::atoi(&str[getName(TYPE_CHAIN).length()]), int(1), int(golem::Chainspace::DIM)) - 1);
			else if (str.find_first_of(getName(TYPE_BASE)) == 0)
				set(TYPE_BASE);
			else
				set(TYPE_ANY);
		}

		/** Get map item */
		template <typename _Iter, typename _Map> _Iter get(_Map& map) const {
			// (1) Any-Any/Base-Base/Joint-Joint/Chain-Chain
			_Iter iter = map.find(toString());
			// (2) if (1) fails: Base-Any/Joint-Any/Chain-Any
			return iter != map.end() ? iter : map.find(Link(TYPE_ANY).toString());
		}

	private:
		/** Link default name */
		static const std::string name[4];
		/** Link id mapped onto type and link index */
		golem::I32 id;
	};

	/** Manipulator kinematic configuration in configspace (joints) and workspace (effector frame) */
	class Config {
	public:
		/** Collection of configurations */
		typedef std::vector<Config> Seq;

		/** Kinematic parameter: Configuration */
		golem::ConfigspaceCoord config;
		/** Kinematic parameter: Base (end-effector) frame */
		RBCoord frame;

		/** No initialisation */
		Config() {}
		/** Copy constructor */
		Config(const golem::ConfigspaceCoord& config) : config(config) {}
		/** Copy constructor */
		Config(const RBCoord& frame) : frame(frame) {}
		/** Copy constructor */
		Config(const golem::ConfigspaceCoord& config, const RBCoord& frame) : config(config), frame(frame) {}

		/** Sets the parameters to the default values */
		inline void setToDefault(golem::Real val = golem::REAL_ZERO) {
			config.fill(val);
			frame.setId();
		}
	};

	/** Weighted manipulator configuration with control vector */
	class Waypoint : public Config, public golem::Sample<golem::Real> {
	public:
		/** Collection of waypoints */
		typedef std::vector<Waypoint> Seq;

		/** Dynamic parameter: Control vector coordinates (such as motor currents) */
		ControlCoord control;

		/** Default constructor */
		Waypoint(golem::Real weight = golem::REAL_ONE, golem::Real cdf = -golem::REAL_ONE) : golem::Sample<golem::Real>(weight, cdf) {}
		/** Copy constructor */
		Waypoint(const Config& config, const ControlCoord& control, golem::Real weight = golem::REAL_ONE, golem::Real cdf = -golem::REAL_ONE) : Config(config), golem::Sample<golem::Real>(weight, cdf), control(control) {}
		/** From Pose */
		explicit Waypoint(const golem::ConfigspaceCoord& config, const RBCoord& frame, golem::Real weight = golem::REAL_ONE, golem::Real cdf = -golem::REAL_ONE) : Config(config, frame), golem::Sample<golem::Real>(weight, cdf) {}

		/** Distance value */
		inline golem::Real getDistance() const {
			return weight;
		}
		/** Distance alignment */
		template <typename _Iter> static void alignDistance(_Iter begin, _Iter end, golem::Real offset) {
			for (; begin != end; ++begin)
				begin->weight += offset;
		}

		/** Low and high bounds of a waypoint sequence */
		template <typename _Iter> static void bounds(_Iter begin, _Iter end, golem::Real distance, _Iter& lo, _Iter& hi) {
			if (begin + 2 > end)
				throw golem::Message(golem::Message::LEVEL_ERROR, "Manipulator::Waypoint::bounds(): At least two waypoints required");

			// binary search
			hi = std::lower_bound(begin, end, distance, [] (const golem::Sample<golem::Real>& l, const golem::Real& r) {return l.weight < r; });
			if (hi == end)
				--hi;
			if (hi == begin)
				++hi;
			lo = hi - 1;
		}

		/** Find the closest waypoint */
		template <typename _Iter> static _Iter find(_Iter begin, _Iter end, golem::Real distance = golem::REAL_ZERO) {
			if (begin + 1 > end)
				throw golem::Message(golem::Message::LEVEL_ERROR, "Manipulator::Waypoint::find(): At least one waypoints required");
			else if (begin + 2 > end)
				return begin;
			else {
				_Iter lo, hi;
				bounds(begin, end, distance, lo, hi);
				return golem::Math::abs(lo->weight - distance) <= golem::Math::abs(hi->weight - distance) ? lo : hi;
			}
		}
	};

	/** Bounds Appearance */
	class BoundsAppearance {
	public:
		/** Show bounds solid */
		bool showSolid;
		/** Show bounds wire frames */
		bool showWire;
		/** Bounds solid colour */
		golem::RGBA solidColour;
		/** Bounds wire colour */
		golem::RGBA wireColour;
		/** Bounds wireframe thickness */
		golem::Real wireWidth;

		/** Constructs from description object */
		BoundsAppearance() {
			setToDefault();
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			showSolid = true;
			showWire = false;
			solidColour = golem::RGBA(golem::U8(255), golem::U8(255), golem::U8(0), golem::U8(127));
			wireColour = golem::RGBA(golem::U8(255), golem::U8(255), golem::U8(0), golem::U8(127));
			wireWidth = golem::Real(1.0);
		}
		/** Assert that the description is valid. */
		void assertValid(const Assert::Context& ac) const {
			Assert::valid(wireWidth > golem::REAL_ZERO, ac, "wireWidth: <= 0");
		}
		/** Draw bounds */
		void draw(const golem::Bounds::Seq& bounds, golem::DebugRenderer& renderer) const;
		/** Load descritpion from xml context. */
		void load(const golem::XMLContext* xmlcontext);
	};

	/** Appearance */
	class Appearance {
	public:
		/** Show bounds */
		bool showBounds;
		/** Show frames */
		bool showFrames;

		/** Bounds colour */
		BoundsAppearance bounds;
		/** Bounds selection colour */
		BoundsAppearance boundsSelection;

		/** Frame size joints */
		golem::Vec3 jointsFrameSize;
		/** Frame size chain */
		golem::Vec3 chainsFrameSize;

		/** Joint selection index */
		mutable golem::U32 selectionIndex;

		/** Constructs from description object */
		Appearance() {
			setToDefault();
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			bounds.setToDefault();
			boundsSelection.setToDefault();
			showBounds = true;
			showFrames = true;
			jointsFrameSize.set(golem::Real(0.02));
			chainsFrameSize.set(golem::Real(0.1));
			selectionIndex = (golem::U32)-1;
		}
		/** Assert that the description is valid. */
		void assertValid(const Assert::Context& ac) const {
			bounds.assertValid(Assert::Context(ac, "bounds."));
			boundsSelection.assertValid(Assert::Context(ac, "boundsSelection."));
			Assert::valid(jointsFrameSize >= golem::REAL_ZERO, ac, "jointsFrameSize: < 0");
			Assert::valid(chainsFrameSize >= golem::REAL_ZERO, ac, "chainsFrameSize: < 0");
		}
		/** Draw robot */
		void draw(const Manipulator& manipulator, const Config& config, golem::DebugRenderer& renderer) const;
		/** Load descritpion from xml context. */
		void load(const golem::XMLContext* xmlcontext);
	};

	/** Configuration model description */
	class Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;

		/** Joint mutual mapping/dependency */
		ConfigspaceMap configMap;
		/** Trajectory error multiplier */
		RBDistEx trajectoryErr;
		/** Trajectory computation timeout */
		golem::SecTmReal trajectoryTimeout;
		/** Trajectory search maximum number of tries per cluster */
		golem::U32 trajectoryClusterSize;
		/** Trajectory throw */
		bool trajectoryThrow;

		/** State -> Control */
		CommandToControl commandToControl;
		/** Control -> State */
		ControlToCommand controlToCommand;

		/** Constructs object description */
		Desc() {
			Desc::setToDefault();
		}
		virtual ~Desc() {
		}
		/** Creates the object from the description. */
		virtual Manipulator::Ptr create(const golem::Planner& planner, const StringSeq& controllerIDSeq) const {
			return Manipulator::Ptr(new Manipulator(*this, planner, controllerIDSeq));
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			configMap.fill(0);
			trajectoryErr.set(golem::Real(10000.0), golem::Real(10000.0), true);
			trajectoryTimeout = golem::SecTmReal(1.0);
			trajectoryClusterSize = 10;
			trajectoryThrow = false;
			commandToControl = nullptr;
			controlToCommand = nullptr;
		}
		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			//Assert::valid(configMap.isValid(), ac, "configMap: invalid");
			Assert::valid(trajectoryErr.isValid(), ac, "trajectoryErr: invalid");
			Assert::valid(trajectoryTimeout > golem::REAL_ZERO, ac, "trajectoryTimeout: <= 0");
			Assert::valid(trajectoryClusterSize > 0, ac, "trajectoryClusterSize: <= 0");
		}
		/** Load descritpion from xml context. */
		virtual void load(const golem::XMLContext* xmlcontext);
	};

	/** Create waypoints from trajectory with distance metrics */
	template <typename _Distance> Waypoint::Seq create(const grasp::Waypoint::Seq& waypoints, _Distance distance) {
		if (waypoints.empty())
			throw golem::Message(golem::Message::LEVEL_ERROR, "Manipulator::create(): At least one waypoints required");

		Waypoint::Seq seq;
		seq.reserve(waypoints.size());

		// create waypoints
		for (grasp::Waypoint::Seq::const_iterator i = waypoints.begin(); i != waypoints.end(); ++i) {
			const Waypoint* prev = i != waypoints.begin() ? &seq.back() : nullptr;
			const Config config(getConfig(i->state, prev));
			ControlCoord control;
			if (desc.commandToControl) desc.commandToControl(i->command, control); // optional
			seq.push_back(Waypoint(config, control, prev ? prev->getDistance() + distance(*prev, config) : golem::REAL_ZERO));
		}

		return seq;
	}
	
	/** Find path in the configuration space */
	virtual RBDist find(Waypoint::Seq& path) const;

	/** Find best path in the configuration space */
	template <typename _Iter, typename _Find> std::pair<_Iter, RBDistEx> find(_Iter begin, _Iter end, _Find find) const {
		if (begin == end)
			throw golem::Message(golem::Message::LEVEL_ERROR, "Manipulator::find(): At least one waypoint required");

		golem::Real err = golem::REAL_MAX;
		RBDistEx dist;
		_Iter j = begin;
		for (_Iter i = begin; i != end; ++i) {
			const RBDistEx newDist = find(i);
			const golem::Real newErr = desc.trajectoryErr.dot(newDist);
			if (err >= newErr && !newDist.collision || i == begin) {
				err  = newErr;
				dist = newDist;
				j = i;
			}
			if (newErr < golem::REAL_ONE && !newDist.collision)
				return std::make_pair(i, newDist);
		}

		if (desc.trajectoryThrow)
			throw golem::Message(golem::Message::LEVEL_ERROR, "Manipulator::find(): No trajectory found");

		return std::make_pair(j, dist);
	}
	/** Create waypoints from path */
	virtual void create(const Waypoint::Seq& path, grasp::Waypoint::Seq& waypoints) const;
	/** Path interpolation */
	virtual Config interpolate(const Waypoint::Seq& path, golem::Real distance) const;

	/** Manipulator configuration */
	virtual golem::Controller::State getState(const Waypoint& waypoint) const;

	/** Manipulator configuration */
	virtual Config getConfig(const golem::Controller::State& state, const Config* prev = nullptr) const;

	/** Fix joint limits and dependencies */
	virtual void clamp(Config& config) const;

	/** Manipulator base frame */
	golem::Mat34 getBaseFrame(const golem::ConfigspaceCoord& config) const;
	/** Joint frames */
	void getJointFrames(const golem::ConfigspaceCoord& config, const golem::Mat34& base, golem::WorkspaceJointCoord& joints) const;
	/** Local frame */
	golem::Mat34 getLocalFrame() const;
	/** Reference frame */
	golem::Mat34 getReferenceFrame() const;

	/** Base bounds */
	virtual bool hasBaseBounds() const;
	/** Base bounds */
	virtual golem::Bounds::Seq getBaseBounds() const;
	/** Base bounds */
	virtual void getBaseBounds(const golem::Mat34& frame, golem::Bounds::Seq& boundsSeq) const;
	/** Joint bounds */
	virtual bool hasJointBounds(golem::Configspace::Index joint) const;
	/** Joint bounds */
	virtual golem::Bounds::Seq getJointBounds(golem::Configspace::Index joint) const;
	/** Joint bounds */
	virtual void getJointBounds(golem::Configspace::Index joint, const golem::Mat34& frame, golem::Bounds::Seq& boundsSeq) const;
	/** Manipulator bounds at given pose */
	virtual golem::Bounds::Seq getBounds(const golem::ConfigspaceCoord& config, const golem::Mat34& frame) const;

	/** Planner */
	const golem::Planner& getPlanner() const {
		return planner;
	}
	/** Controller */
	const golem::Controller& getController() const {
		return controller;
	}
	/** Controller state info */
	inline const golem::Controller::State::Info& getInfo() const {
		return info;
	}
	
	/** Controller arm */
	inline const golem::Controller* getArm() const {
		return arm;
	}
	/** Controller arm state info */
	inline const golem::Controller::State::Info& getArmInfo() const {
		return armInfo;
	}

	/** Controller hand */
	inline const golem::Controller* getHand() const {
		return hand;
	}
	/** Controller hand state info */
	inline const golem::Controller::State::Info& getHandInfo() const {
		return handInfo;
	}

	/** Manipulator range */
	inline const golem::Configspace::Range& getConfigRange() const {
		return configRange;
	}
	/** Manipulator joint position limits */
	inline const golem::ConfigspaceCoord& getConfigMin() const {
		return configMin;
	}
	/** Manipulator joint position limits */
	inline const golem::ConfigspaceCoord& getConfigMax() const {
		return configMax;
	}

	/** Context */
	inline golem::Context& getContext() {
		return context;
	}
	inline const golem::Context& getContext() const {
		return context;
	}

	/** Configuration description */
	inline Desc& getDesc() {
		return desc;
	}
	inline const Desc& getDesc() const {
		return desc;
	}

	/** Object deletion */
	virtual ~Manipulator();

private:
	golem::Context& context;
	const golem::Planner& planner;
	const golem::Controller& controller;
	golem::Controller* arm;
	golem::Controller* hand;

	/** Controller state info */
	golem::Controller::State::Info info;
	/** Controller state info */
	golem::Controller::State::Info armInfo;
	/** Controller state info */
	golem::Controller::State::Info handInfo;

	/** Manipulator range */
	golem::Configspace::Range configRange;
	/** Manipulator joint position limits */
	golem::ConfigspaceCoord configMin, configMax;

	/** Manipulator description */
	Desc desc;

	/** From Golem controller */
	Manipulator(const Desc& desc, const golem::Planner& planner, const StringSeq& controllerIDSeq);
};

//------------------------------------------------------------------------------

};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_CONTACT_MANIPULATOR_H_*/
