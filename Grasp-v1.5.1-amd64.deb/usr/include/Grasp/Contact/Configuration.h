/** @file Configuration.h
 *
 * Robot configuration model
 *
 * @author Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_CONTACT_CONFIGURATION_H_
#define _GRASP_CONTACT_CONFIGURATION_H_

//------------------------------------------------------------------------------

#include <Grasp/Contact/Manipulator.h>
#include <Golem/Tools/Stream.h>

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** Configuration model */
class Configuration {
public:
	typedef golem::shared_ptr<Configuration> Ptr;

	/** Trajectory parameter vector coordinates */
	typedef golem::_VecN<golem::Real, (size_t)golem::Configspace::DIM> ParamCoord;

	/** Weighted configuration */
	class Kernel : public Manipulator::Config, public golem::Sample<golem::Real> {
	public:
		/** Kernel density estimator */
		typedef std::vector<Kernel> Seq;

		/** Default constructor */
		Kernel(golem::Real weight = golem::REAL_ONE, golem::Real cdf = -golem::REAL_ONE) : golem::Sample<golem::Real>(weight, cdf) {}
		/** Copy constructor */
		Kernel(const Manipulator::Config& config, golem::Real weight = golem::REAL_ONE, golem::Real cdf = -golem::REAL_ONE) : Manipulator::Config(config), golem::Sample<golem::Real>(weight, cdf) {}
		/** Copy constructor */
		Kernel(const golem::ConfigspaceCoord& config, const RBCoord& frame, golem::Real weight = golem::REAL_ONE, golem::Real cdf = -golem::REAL_ONE) : Manipulator::Config(config, frame), golem::Sample<golem::Real>(weight, cdf) {}
	};

	/** Sequence of waypoints */
	class Path : public Manipulator::Waypoint::Seq, public golem::Sample<golem::Real> {
	public:
		/** Collection of paths */
		typedef std::vector<Path> Seq;

		/** Path appearance */
		class Appearance {
		public:
			/** Manipulator */
			Manipulator::Appearance manipulator;

			/** Show edges */
			bool showEdges;
			/** Show vertices */
			bool showVertices;

			/** Path segments */
			golem::U32 pathSegments;
			/** Path extrapolation distance delta */
			golem::Real pathDelta;
			/** Path colour */
			golem::RGBA pathColour;

			/** Current subspace distance */
			mutable golem::I32 subspaceDist;
			/** Current subspace Config */
			mutable golem::ConfigspaceCoord subspaceConfig;
			/** Current subspace distance */
			mutable golem::Real subspaceDistLo, subspaceDistHi, subspaceDistVal;

			/** Constructs from description object */
			Appearance() {
				setToDefault();
			}
			/** Sets the parameters to the default values */
			void setToDefault() {
				manipulator.setToDefault();

				showEdges = true;
				showVertices = true;

				pathSegments = 20;
				pathDelta = golem::Real(0.0);
				pathColour = golem::RGBA::WHITE;

				subspaceDist = 0;
				subspaceConfig.fill(golem::REAL_ZERO);
				subspaceDistLo = subspaceDistHi = subspaceDistVal = golem::REAL_ZERO;
			}
			/** Assert that the description is valid. */
			void assertValid(const Assert::Context& ac) const {
				manipulator.assertValid(Assert::Context(ac, "manipulator."));
				Assert::valid(pathDelta >= golem::REAL_ZERO, ac, "pathDelta: < 0");
				Assert::valid(pathSegments > 1, ac, "pathSegments: < 2");
			}
			/** Load descritpion from xml context. */
			void load(const golem::XMLContext* xmlcontext);
		};

		/** Kinematic parameter: vector parameterising trajectory "shape" */
		//ParamCoord param;

		/** Default constructor */
		Path(golem::Real weight = golem::REAL_ONE, golem::Real cdf = -golem::REAL_ONE) : golem::Sample<golem::Real>(weight, cdf) {}
		/** Copy constructor */
		Path(const Manipulator::Waypoint::Seq& path, golem::Real weight = golem::REAL_ONE, golem::Real cdf = -golem::REAL_ONE) : Manipulator::Waypoint::Seq(path), golem::Sample<golem::Real>(weight, cdf) {}

		/** Sets the parameters to the default values */
		inline void setToDefault() {
			clear();
		}
		/** Valid */
		inline void assertValid() {
			if (empty())
				throw golem::Message(golem::Message::LEVEL_ERROR, "Configuration::Path::assertValid(): empty path");
		}

		/** Grip */
		inline Manipulator::Waypoint& getGrip() {
			return back();
		}
		/** Grip */
		inline const Manipulator::Waypoint& getGrip() const {
			return back();
		}

		/** Approach */
		inline Manipulator::Waypoint& getApproach() {
			return front();
		}
		/** Approach */
		inline const Manipulator::Waypoint& getApproach() const {
			return front();
		}

		/** Draw path */
		void draw(const Manipulator& manipulator, const Appearance& appearance, golem::DebugRenderer& renderer) const;
	};

	/** Configuration model description */
	class Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;

		/** Manipulator frame distribution standard deviation */
		grasp::RBDist poseStdDev;
		/** Manipulator configuration distribution standard deviation */
		golem::ConfigspaceCoord configStdDev;
		/** Distance scale multiplier */
		golem::Real distanceScale;
		/** Distance standard deviation */
		golem::Real distanceStdDev;
		/** Maximum distance between query point and kernel */
		golem::Real distanceStdDevMax;
		/** Number of kernels per path */
		golem::U32 kernels;
		/** Transformation gradient interpolation distance */
		golem::Real transformGradDist;

		/** Constructs object description */
		Desc() {
			Desc::setToDefault();
		}
		virtual ~Desc() {
		}
		/** Creates the object from the description. */
		virtual Configuration::Ptr create(Manipulator& manipulator) const {
			return Configuration::Ptr(new Configuration(*this, manipulator));
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			poseStdDev.set(golem::Real(0.002), golem::Real(1000.0));
			configStdDev.fill(golem::REAL_PI*golem::Real(0.01));
			distanceScale = golem::Real(0.02);
			distanceStdDev = golem::Real(2.0);
			distanceStdDevMax = golem::Real(5.0);
			kernels = 100000;
			transformGradDist = golem::Real(2.0);
		}
		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			Assert::valid(poseStdDev.isValid(), ac, "poseStdDev: invalid");
			for (golem::idx_t i = 0; i < golem::Configspace::DIM; ++i)
				Assert::valid(configStdDev.data()[i] > golem::REAL_EPS, ac, "configStdDev[i]: < eps");

			Assert::valid(distanceScale > golem::REAL_ZERO, ac, "distanceScale: <= 0");
			Assert::valid(distanceStdDev > golem::REAL_ZERO, ac, "distanceStdDev: <= 0");
			Assert::valid(distanceStdDevMax > golem::REAL_ZERO, ac, "distanceStdDevMax: <= 0");
			Assert::valid(kernels > 0, ac, "kernels: <= 0");

			Assert::valid(transformGradDist > golem::REAL_ZERO, ac, "transformGradDist: <= 0");
		}
		/** Load descritpion from xml context. */
		virtual void load(const golem::XMLContext* xmlcontext);
	};

	/** Create path from trajectory */
	virtual Path create(const grasp::Waypoint::Seq& waypoints) const;
	/** Create configuration subspace from path */
	virtual Kernel::Seq create(const Path& path) const;

	/** Create trajectory subspace */
	virtual void add(const Path::Seq& paths, const Kernel::Seq& kernels);
	/** Clear all paths */
	virtual void clear();

	/** Path sampling: p(config|path) */
	virtual void sample(golem::Rand& rand, const Manipulator::Config& config, Path& path) const;
	/** Conditional path generation: p(config, prev|next)	*/
	virtual void generate(golem::Rand& rand, const Manipulator::Config& config, const Path& prev, Path& next) const;

	/** Configuration sampling: p(config) */
	virtual Manipulator::Config sampleConfig(golem::Rand& rand) const;

	/** Linear distance between given waypoints on a path */
	virtual golem::Real distancePath(const Manipulator::Config& left, const Manipulator::Config& right) const;

	/** Configuration distance */
	virtual golem::Real distance(const Manipulator::Config& left, const Manipulator::Config& right) const;

	/** Configuration evaluation */
	virtual golem::Real evaluate(const Manipulator::Config& config) const;

	/** Paths */
	inline const Path::Seq& getPaths() const {
		return paths;
	}
	/** Kernel collection */
	const Kernel::Seq& getKernels() const {
		return kernels;
	}

	/** Manipulator */
	const Manipulator& getManipulator() const {
		return manipulator;
	}

	/** Configuration description */
	Desc& getDesc() {
		return desc;
	}
	const Desc& getDesc() const {
		return desc;
	}

	/** Manipulator frame distribution covariance */
	inline const grasp::RBDist& getPoseCovInv() const {
		return poseCovInv;
	}
	/** Manipulator configuration distribution covariance */
	inline const golem::ConfigspaceCoord& getConfigCovInv() const {
		return configCovInv;
	}

	/** Object deletion */
	virtual ~Configuration();

protected:
	/** Manipulator */
	Manipulator& manipulator;
	/** Context object */
	golem::Context &context;
	/** Contact description */
	Desc desc;

	/** Manipulator pose distribution covariance */
	grasp::RBDist poseCov, poseCovInv;
	/** Manipulator configuration distribution covariance */
	golem::ConfigspaceCoord configCov, configCovInv;
	/** Maximum distance between query point and kernel */
	golem::Real distanceMax;

	/** Path collection */
	Path::Seq paths;
	/** Kernel collection */
	Kernel::Seq kernels;

	/** Configuration sampling: p(kernel|config) */
	virtual Manipulator::Config sampleConfigKernel(golem::Rand& rand, const Manipulator::Config& kernel) const;

	/** Transform path to the new pose */
	virtual void transform(const Manipulator::Config& config, Path& path) const;

	/** Normalise data */
	virtual void normalise();

	/** Creates Contact */
	Configuration(const Desc& desc, Manipulator& manipulator);
};

//------------------------------------------------------------------------------

};	// namespace

//------------------------------------------------------------------------------

namespace golem {
	template <> void Stream::read(grasp::Configuration::Path& value) const;
	template <> void Stream::write(const grasp::Configuration::Path& value);
};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_CONTACT_CONFIGURATION_H_*/
