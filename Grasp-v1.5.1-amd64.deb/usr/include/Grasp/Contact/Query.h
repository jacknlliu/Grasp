/** @file Query.h
 *
 * Query density
 *
 * @author Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_CONTACT_QUERY_H_
#define _GRASP_CONTACT_QUERY_H_

//------------------------------------------------------------------------------

#include <Grasp/Contact/Model.h>
#include <Grasp/Core/Search.h>

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** Query density */
class Query : public golem::Sample<golem::Real> {
public:
	typedef golem::shared_ptr<Query> Ptr;
	/** Container */
	typedef std::map<std::string, Ptr> Map;

	/** Kernel */
	class Kernel : public RBCoord {
	public:
		/** Covariance (used in sampling) */
		RBDist cov;
		/** Std deviation (used in sampling) */
		RBDist stdDev;
		/** Covariance inverse (used in evaluation) */
		RBDist covInv;
		/** Distance maximum (used in evaluation) */
		RBDist distMax;

		/** No initialisation */
		Kernel() {}
		/** Cope frame */
		Kernel(const RBCoord& coord, const RBDist& cov, const RBDist& stdDev, const RBDist& covInv, const RBDist& distMax) :
			RBCoord(coord), cov(cov), stdDev(stdDev), covInv(covInv), distMax(distMax)
		{}
	};

	/** Query pose hypothesis. Inheritance order: RBCoord first, Sample last */
	class Pose : public Kernel, public golem::Sample<golem::Real> {
	public:
		/** Pose collection/distribution */
		typedef std::vector<Pose> Seq;

		/** Dereferencing template */
		struct Ref {
			template <typename _Ptr> static inline const Kernel& get(_Ptr& ptr) {
				return ptr; // nothing to do
			}
		};
		/** Copying */
		inline const Pose& operator = (const Kernel& kernel) {
			(Kernel&)*this = kernel;
			return *this;
		}

		Pose(golem::Real weight = golem::REAL_ONE, golem::Real cdf = -golem::REAL_ONE) : golem::Sample<golem::Real>(weight, cdf) {}
		Pose(const Kernel& kernel, golem::Real weight = golem::REAL_ONE, golem::Real cdf = -golem::REAL_ONE) : Kernel(kernel), golem::Sample<golem::Real>(weight, cdf) {}
	};

	/** Description */
	class Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;
		/** Collection */
		typedef std::map<std::string, Ptr> Map;

		/** Contact type */
		Contact3D::Type contact3DType;

		/** Number of kernels */
		golem::U32 kernels;
		/** Query density normalisation constant */
		golem::Real weight;
		/** Query density normalisation epsilon */
		golem::Real epsilon;
		/** Maximum number of subsequent trials to compute a single kernel of M(u|r) */
		golem::U32 trials;
		/** Maximum distance between features in standard deviations */
		golem::Real featureStdDevMax;
		/** Maximum distance between frames in standard deviations */
		golem::Real poseStdDevMax;

		/** NN search: number of neighbours */
		golem::U32 neighbours;
		/** NN search: description */
		KDTreeDesc nnSearchDesc;

		/** Constructs description object */
		Desc() {
			Desc::setToDefault();
		}
		virtual ~Desc() {
		}
		/** Creates the object from the description. */
		virtual Query::Ptr create(golem::Context& context, const std::string& name) const {
			return Query::Ptr(new Query(*this, context, name));
		}
		/** Sets the parameters to the default values. */
		void setToDefault() {
			contact3DType = Contact3D::TYPE_NORMAL;

			kernels = 2000;
			weight = golem::REAL_ONE;
			epsilon = golem::REAL_EPS;
			trials = 100;
			featureStdDevMax = golem::Real(5.0);
			poseStdDevMax = golem::Real(5.0);

			neighbours = 100;
			nnSearchDesc.setToDefault();
		}
		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			Assert::valid(kernels > 0, ac, "kernels: <= 0");
			Assert::valid(weight >= golem::REAL_ZERO, ac, "weight: < 0");
			Assert::valid(epsilon >= golem::REAL_ZERO, ac, "epsilon: < 0");
			Assert::valid(trials >= 0, ac, "trials: < 0");
			Assert::valid(featureStdDevMax > golem::REAL_EPS, ac, "featureStdDevMax: < eps");
			Assert::valid(poseStdDevMax > golem::REAL_EPS, ac, "poseStdDevMax: < eps");

			Assert::valid(neighbours >= 0, ac, "neighbours: < 0");
			nnSearchDesc.assertValid(Assert::Context(ac, "nnSearchDesc."));
		}
		/** Load descritpion from xml context. */
		virtual void load(const golem::XMLContext* xmlcontext);
	};

	/** Create 3D contact query density */
	virtual void create(const Contact3D::Seq& contacts, const data::Point3D& points);
	/** Create 3D contact query density */
	virtual void create(const Contact3D::Seq& contacts, const data::Normal3D& normals);
	/** Create 3D contact query density */
	virtual void create(const Contact3D::Seq& contacts, const data::Feature3D& features);
	/** Create 3D contact query density */
	virtual void create(const Contact3D::Seq& contacts, const data::Part3D& parts);
	/** Clear query density data */
	virtual void clear();

	/** Query density poses */
	const Pose::Seq& getPoses() const {
		return poses;
	}

	/** Sample query density */
	RBCoord sample(golem::Rand& rand) const;
	/** Sample query density */
	RBCoord sample(golem::Rand& rand, const Kernel& kernel) const;
	/** Evaluate pose given query density */
	golem::Real evaluate(const RBCoord& coord) const;
	
	/** Query density name */
	const std::string& getName() const {
		return name;
	}

	/** Query density description */
	const Desc& getDesc() const {
		return desc;
	}

	/** Bye bye */
	virtual ~Query() {}

protected:
	/** Context object */
	golem::Context &context;
	/** Parallels */
	golem::Parallels* parallels;

	/** Query density name */
	const std::string name;
	/** Query density description */
	Desc desc;
	/** Maximum distance between features in squared standard deviations */
	golem::Real featureDistanceMax;
	/** Maximum distance between frames in squared standard deviations */
	golem::Real poseDistanceMax;

	/** Query density */
	Pose::Seq poses;

	/** Creates query density */
	Query(const Desc& desc, golem::Context& context, const std::string& name);
};

void XMLData(grasp::Query::Desc::Map::value_type& val, golem::XMLContext* context, bool create = false);

//------------------------------------------------------------------------------

};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_CONTACT_QUERY_H_*/
