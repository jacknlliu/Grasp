/** @file Cluster.h
 * 
 * Contact clustering
 * 
 * @author Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_CONTACT_CLUSTER_H_
#define _GRASP_CONTACT_CLUSTER_H_

//------------------------------------------------------------------------------

#include <Grasp/Contact/Contact.h>

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** Configuration cluster */
class Cluster {
public:
	/** Cluster collection */
	typedef std::vector<Cluster> Seq;

	/** Clustering algorithm description */
	class Desc {
	public:
		/** Clustering search distance */
		RBDist distance;
		/** Clustering search distance radius */
		golem::Real radius;
		/** Clustering min neighbours */
		golem::U32 density;

		/** Constructs description object */
		Desc() {
			Desc::setToDefault();
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			distance.set(golem::Real(100.0), golem::Real(10.0));
			radius = golem::Real(1.0);
			density = 15;
		}
		/** Checks if the description is valid. */
		bool isValid() const {
			if (!distance.isValid() || radius <= golem::REAL_ZERO || density < 1)
				return false;
			return true;
		}
		/** Assert that the description is valid. */
		void assertValid(const Assert::Context& ac) const {
			Assert::valid(distance.isValid(), ac, "distance: invalid");
			Assert::valid(radius > golem::REAL_EPS, ac, "radius: < eps");
			Assert::valid(density > 0, ac, "density: < 1");
		}
		/** Load descritpion from xml context. */
		void load(const golem::XMLContext* xmlcontext);
	};

	/** Begin */
	golem::U32 begin;
	/** End */
	golem::U32 end;

	/** Construction */
	Cluster() {}
	/** Construction */
	Cluster(golem::U32 begin, golem::U32 end) : begin(begin), end(end) {}

	/** Cluster size */
	golem::U32 size() const {
		return end - begin;
	}
	/** Is empty */
	bool empty() const {
		return begin == 0 && end == 0;
	}
	/** Is valid */
	template <typename _Seq> bool valid(const _Seq& seq) const {
		return begin <= end && end <= (golem::U32)seq.size();
	}

	/** Get index */
	static golem::U32 getIndex(const Cluster::Seq& clusters, golem::I32& cluster, golem::I32& index) {
		if (clusters.empty())
			return golem::U32(cluster = index = 0);
		cluster = golem::Math::clamp(cluster, (golem::I32)0, (golem::I32)clusters.size() - 1);
		index = golem::Math::clamp(index, (golem::I32)clusters[cluster].begin, (golem::I32)clusters[cluster].end - 1);
		return clusters[cluster].begin + index;
	}

	/** Find contact type clusters */
	static void findType(const Desc& desc, Contact::Config::Seq& configs, Cluster::Seq& clusters);
	/** Find contact likelihood clusters */
	static void findLikelihood(const Desc& desc, Contact::Config::Seq& configs, Cluster::Seq& clusters);
	/** Find contact configuration clusters */
	static void findConfiguration(const Desc& desc, Contact::Config::Seq& configs, Cluster::Seq& clusters, golem::Real radius, golem::U32 density);
};

//------------------------------------------------------------------------------

};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_CONTACT_CLUSTER_H_*/
