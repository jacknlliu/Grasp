/** @file Contact.h
 * 
 * Contact estimator
 * 
 * @author Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_CONTACT_CONTACT_H_
#define _GRASP_CONTACT_CONTACT_H_

//------------------------------------------------------------------------------

#include <Grasp/Core/Search.h>
#include <Grasp/Contact/Configuration.h>
#include <Grasp/Contact/Query.h>
#include <Grasp/Contact/Collision.h>

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** Contact estimator for a single contact type */
class Contact {
public:
	typedef golem::shared_ptr<Contact> Ptr;
	/** Contact estimator collection: contact estimator name -> contact estimator */
	typedef std::map<std::string, Ptr> Map;

	/** Link Query density pair */
	typedef std::pair<Manipulator::Link, Query*> LinkQuery;
	/** Sequence of Query densities */
	typedef std::vector<LinkQuery> LinkQuerySeq;
	/** Query reference */
	struct QueryRef {
		template <typename _Type, typename Ptr> static inline _Type& get(Ptr& linkQuery) {
			return *linkQuery.second;
		}
	};

	/** Contact likelihood */
	class Likelihood {
	public:
		/** Number of contacts */
		static const size_t CONTACTS = golem::Configspace::DIM + 1;

		/** Contact likelihood components */
		union {
			struct {
				/** Links contact likelihood */
				golem::ConfigspaceCoord links;
				/** Base contact likelihood */
				golem::Real base;
			};

			/** As an array */
			golem::Real contacts[CONTACTS];
		};

		/** Configuration likelihood */
		golem::Real config;
		/** Collision component */
		golem::Real collision;
		/** Kinematics component */
		//golem::Real kinematics;

		/** Log-Likelihood value */
		golem::Real value;
		/** Log-Likelihood value active contacts */
		golem::Real valueActive;
		/** Log-Likelihood value inactive contacts */
		golem::Real valueInactive;

		/** Basic initialisation */
		Likelihood(golem::Real value = golem::REAL_ZERO) : value(value) {}

		/** Sets the parameters to the default values */
		inline void setToDefault(golem::Real likelihood = -golem::REAL_ONE, golem::Real value = golem::REAL_ZERO) {
			std::fill(contacts, contacts + CONTACTS, likelihood);
			config = likelihood;
			collision = likelihood;
			//kinematics = likelihood;
			
			this->value = value;
			valueActive = valueInactive = value;
		}

		/** Is data valid */
		inline static bool isValid(const golem::Real& component, golem::Real eps) {			
			return component <= -golem::REAL_ONE || component - eps > golem::REAL_ZERO;
		}
		/** Is data valid */
		inline bool isValid(golem::Real eps) const {			
			for (size_t i = 0; i < CONTACTS; ++i)
				if (!isValid(contacts[i], eps))
					return false;
			return isValid(config, eps);
		}

		/** Number of active contacts */
		inline size_t getActiveContacts() const {
			size_t activeContacts = 0;
			for (size_t i = 0; i < CONTACTS; ++i) {
				if (contacts[i] > golem::REAL_ZERO)
					++activeContacts;
			}
			return activeContacts;
		}
		/** Average value of active contacts */
		inline golem::Real getActiveContactsAverageValue() const {
			golem::Real value = golem::REAL_ZERO;
			size_t activeContacts = 0;
			for (size_t i = 0; i < CONTACTS; ++i) {
				const golem::Real contact = contacts[i];
				if (contact > golem::REAL_ZERO) {
					++activeContacts;
					value += contact;
				}
			}
			return activeContacts > 0 ? value/activeContacts : golem::REAL_ZERO;
		}

		/** Log value */
		inline static golem::Real getLogValue(golem::Real value) {
			return value < golem::REAL_ZERO ? golem::REAL_ZERO : golem::Math::ln(value > golem::REAL_ZERO ? value : golem::numeric_const<golem::Real>::MIN);
		}

		/** Log-likelihood product update */
		inline void makeLogProduct() {
			valueActive = golem::REAL_ZERO;
			for (size_t i = 0; i < CONTACTS; ++i)
				valueActive += getLogValue(contacts[i]);
			
			value = golem::REAL_ZERO;
			value += valueActive;
			value += getLogValue(config);
			value += collision;
			//value += kinematics;
		}

		/** Log-likelihood normalised product update */
		inline void makeLogNormProduct(size_t activeContacts, golem::Real penaltyExp) {

			valueActive = golem::REAL_ZERO;
			valueInactive = golem::REAL_ZERO;
			size_t n = 0;

			for (size_t i = 0; i < CONTACTS; ++i) {
				const golem::Real contact = contacts[i];
				valueActive += getLogValue(contact);
				if (contact > golem::REAL_ZERO) {
					valueInactive += contact;
					++n;
				}
			}

			valueInactive = n > 0 && activeContacts > n ? getLogValue(valueInactive/n)*(activeContacts - n)*penaltyExp : golem::REAL_ZERO;

			value = golem::REAL_ZERO;
			value += valueActive;
			value += valueInactive;
			value += getLogValue(config);
			value += collision;
			//value += kinematics;
		}
	};

	/** Contact configuration */
	class Config {
	public:
		/** Unique pointer for performance reasons */
		typedef std::shared_ptr<Config> Ptr;
		/** Collection */
		typedef std::vector<Ptr> Seq;

		/** Collection range */
		typedef std::pair<Seq::iterator, Seq::iterator> Range;
		/** Collection range sequence */
		typedef std::vector<Range> RangeSeq;

		/** Contact estimator config collection: contact type name -> contact config */
		typedef std::multimap<std::string, Config> Map;
		/** Contact estimator config sequence collection: contact type name -> contact estimator config sequence */
		typedef std::map<std::string, Seq> SeqMap;

		/** Config appearance */
		class Appearance {
		public:
			/** Path */
			bool showConfig;
			/** Config model */
			bool showModelConfig;
			/** Contact model */
			bool showModelContact;

			/** Config path appearance */
			Configuration::Path::Appearance configPath;
			/** Model manipulator */
			Manipulator::Appearance modelManipulator;

			/** Show frames, not points */
			bool showModelFrames;
			/** Model distribution num of samples */
			golem::U32 modelDistribSamples;
			/** Model distribution num of bounds */
			golem::U32 modelDistribBounds;
			/** Model selection index */
			golem::U32 modelSelectionIndex;
			/** Samples colour */
			golem::RGBA modelSamplesColour;
			/** Samples point size */
			golem::Real modelSamplesPointSize;
			/** Samples frame size */
			golem::Vec3 modelSamplesFrameSize;

			/** Constructs from description object */
			Appearance() {
				setToDefault();
			}
			/** Sets the parameters to the default values */
			void setToDefault() {
				showConfig = true;
				showModelConfig = false;
				showModelContact = false;
				
				configPath.setToDefault();
				modelManipulator.setToDefault();

				showModelFrames = false;
				modelDistribSamples = 1000;
				modelDistribBounds = 1;
				modelSelectionIndex = -1;
				modelSamplesColour = golem::RGBA(golem::RGBA::RED._rgba.r, golem::RGBA::RED._rgba.g, golem::RGBA::RED._rgba.b, 50);
				modelSamplesPointSize = golem::Real(3.0);
				modelSamplesFrameSize.set(golem::Real(0.01));
			}
			/** Assert that the description is valid. */
			void assertValid(const Assert::Context& ac) const {
				configPath.assertValid(Assert::Context(ac, "configPath."));
				modelManipulator.assertValid(Assert::Context(ac, "modelManipulator."));

				Assert::valid(modelSamplesPointSize > golem::REAL_ZERO, ac, "modelSamplesPointSize: < 0");
				Assert::valid(modelSamplesFrameSize.isPositive(), ac, "modelSamplesFrameSize: <= 0");
			}
			/** Load descritpion from xml context. */
			void load(const golem::XMLContext* xmlcontext);
		};

		/** Type */
		std::string type;
		/** Path */
		Configuration::Path path;
		/** Likelihood */
		Likelihood likelihood;
		
		/** Basic initialisation */
		Config(golem::Real value = golem::REAL_ZERO) : likelihood(value), contact(nullptr) {}

		/** Allocates and copies parameters */
		static void alloc(Ptr& ptr) {
			if (!ptr) ptr.reset(new Config);
		}
		/** Allocates and copies parameters */
		inline void set(const Contact& contact, const Configuration::Path& path, const Likelihood& likelihood) {
			this->contact = &contact;
			this->type = contact.getType();
			this->path = path;
			this->likelihood = likelihood;
		}

		/** Sets the parameters to the default values */
		inline void setToDefault() {
			contact = nullptr;
			type.clear();
			path.setToDefault();
			likelihood.setToDefault();
		}
		/** Valid */
		template <typename _Ptr> static void assertValid(const _Ptr& ptr) {
			if (!ptr || ptr->path.empty() || ptr->type.length() <= 0)
				throw golem::Message(golem::Message::LEVEL_ERROR, "Contact::Config::assertValid(): invalid configuration");
		}

		/** Size */
		template <typename _RangePtr> static inline size_t getSize(_RangePtr begin, _RangePtr end) {
			size_t size = 0;
			for (; begin != end; ++begin)
				size += (size_t)(begin->second - begin->first);
			return size;
		}
		/** Number of active contacts */
		template <typename _Range> static inline size_t getActiveContacts(const _Range& range) {
			size_t activeContacts = 0;
			for (typename _Range::first_type i = range.first; i != range.second; ++i) {
				const size_t ac = (*i)->likelihood.getActiveContacts();
				if (activeContacts < ac)
					activeContacts = ac;
			}
			return activeContacts;
		}
		/** Number of active contacts */
		template <typename _RangePtr> static inline size_t getActiveContacts(_RangePtr begin, _RangePtr end) {
			size_t activeContacts = 0;
			for (; begin != end; ++begin) {
				const size_t ac = getActiveContacts(*begin);
				if (activeContacts < ac)
					activeContacts = ac;
			}
			return activeContacts;
		}
		/** Log-likelihood normalised product update */
		template <typename _Range> static inline void makeLogNormProduct(const _Range& range, size_t activeContacts) {
			for (typename _Range::first_type i = range.first; i != range.second; ++i)
				(*i)->likelihood.makeLogNormProduct(activeContacts, (*i)->getContact() ? (*i)->getContact()->getDesc().penaltyExp : golem::REAL_ONE);
		}
		/** Log-likelihood normalised product update */
		template <typename _RangePtr> static inline void makeLogNormProduct(_RangePtr begin, _RangePtr end, size_t activeContacts) {
			for (; begin != end; ++begin)
				makeLogNormProduct(*begin, activeContacts);
		}

		/** Contact pointer */
		const Contact* getContact() const {
			return contact;
		}

		/** Draw contact config */
		void draw(const Manipulator& manipulator, const Appearance& appearance, golem::Rand& rand, golem::DebugRenderer& renderer) const;

	private:
		/** Contact pointer */
		const Contact* contact;
	};

	/** Contact configuration optimisation */
	class Optimisation {
	public:
		typedef golem::shared_ptr<Optimisation> Ptr;
		
		/** Optimisation description */
		class Desc {
		public:
			typedef golem::shared_ptr<Desc> Ptr;

			/** Nothing to do here */
			virtual ~Desc() {}
			/** Creates the object from the description. */
			virtual Optimisation::Ptr create(Contact& contact) const = 0;
			/** Sets the parameters to the default values */
			virtual void setToDefault() = 0;
			/** Assert that the description is valid. */
			virtual void assertValid(const Assert::Context& ac) const = 0;
			/** Load descritpion from xml context. */
			virtual void load(const golem::XMLContext* xmlcontext) = 0;
		};

		/** Nothing to do here */
		virtual ~Optimisation() {}

		/** Initialisation */
		virtual void create(const data::Point3D& points) = 0;
		/** Optimisation: find initial solutions */
		virtual Config::Seq::iterator find(Config::Seq& configs, Config::Seq::iterator ptr) = 0;
		/** Optimisation: improve specified solutions [begin, end), using steps [beginStep, endStep], where: 0 <= beginStep < endStep <= 1 */
		virtual void find(Config::Seq::const_iterator begin, Config::Seq::const_iterator end, golem::Real beginStep, golem::Real endStep) = 0;

	protected:
		Contact& contact;
		golem::Context& context;
		
		Optimisation(Contact& contact) : contact(contact), context(contact.getContext()) {}
	};

	/** Contact description */
	class Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;
		/** Contact estimator description collection: contact estimator name -> contact estimator description */
		typedef std::map<std::string, Ptr> Map;
		
		/** Name */
		std::string name;
		/** Type */
		mutable std::string type;

		/** Query descriptions */
		Query::Desc::Map queryDescMap;

		/** Inactive contact penalty exponent */
		golem::Real penaltyExp;

		/** Configuration description */
		Configuration::Desc::Ptr configurationDesc;

		/** Optimisation description */
		Optimisation::Desc::Ptr optimisationDesc;
		/** Collision description */
		Collision::Desc::Ptr collisionDesc;

		/** Constructs description object */
		Desc() {
			Desc::setToDefault();
		}
		virtual ~Desc() {
		}
		/** Creates the object from the description. */
		virtual Contact::Ptr create(Manipulator& manipulator) const {
			return Contact::Ptr(new Contact(*this, manipulator));
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			name = "Default";
			type = "Generic";
			queryDescMap.insert(std::make_pair(Manipulator::Link(Manipulator::Link::TYPE_ANY).toString(), Query::Desc::Ptr(new Query::Desc)));
			penaltyExp = golem::Real(1.0);
			configurationDesc.reset(new Configuration::Desc);
			optimisationDesc.reset();
			collisionDesc.reset(new Collision::Desc);
		}
		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			Assert::valid(name.length() > 0, ac, "name: empty");
			Assert::valid(type.length() > 0, ac, "type: empty");

			Assert::valid(!queryDescMap.empty(), ac, "queryDescMap: empty");
			for (Query::Desc::Map::const_iterator i = queryDescMap.begin(); i != queryDescMap.end(); ++i) {
				Assert::valid(i->second != nullptr, ac, "queryDescMap[]: null");
				i->second->assertValid(Assert::Context(ac, "queryDescMap[]->"));
			}

			Assert::valid(golem::Math::isFinite(penaltyExp), ac, "penaltyExp: invalid");

			Assert::valid(configurationDesc != nullptr, ac, "configurationDesc: null");
			configurationDesc->assertValid(Assert::Context(ac, "configurationDesc->"));
			Assert::valid(optimisationDesc != nullptr, ac, "optimisationDesc: null");
			optimisationDesc->assertValid(Assert::Context(ac, "optimisationDesc->"));
			Assert::valid(collisionDesc != nullptr, ac, "collisionDesc: null");
			collisionDesc->assertValid(Assert::Context(ac, "collisionDesc->"));
		}
		/** Load descritpion from xml context. */
		virtual void load(const golem::XMLContext* xmlcontext);
	};

	/** Add training data */
	virtual void add(const Configuration::Path::Seq& paths, const Configuration::Kernel::Seq& kernels, const Contact3D::Map& contacts);
	/** Clear training data */
	virtual void clear();
	/** Clear training data */
	virtual bool empty() const;

	/** Create query densities, initialise search */
	virtual void create(const data::Point3D& points);

	/** Find configurations */
	virtual void find(Config::Seq& configs);
	/** Find initial solutions */
	virtual Config::Seq::iterator find(Config::Seq& configs, Config::Seq::iterator ptr);
	/** Improve specified solutions [begin, end), using steps [beginStep, endStep], where: 0 <= beginStep < endStep <= 1 */
	virtual void find(Config::Seq::const_iterator begin, Config::Seq::const_iterator end, golem::Real beginStep, golem::Real endStep);

	/** Sampling */
	virtual Manipulator::Config sample(golem::Rand& rand) const;

	/** Contact estimator name */
	const std::string& getName() const {
		return desc.name;
	}
	/** Contact estimator type */
	const std::string& getType() const {
		return desc.type;
	}

	/** Manipulator */
	const Manipulator& getManipulator() const {
		return manipulator;
	}

	/** Configuration model */
	const Configuration* getConfiguration() const {
		return configuration.get();
	}
	/** Query densities */
	const LinkQuerySeq& getQuery() const {
		return querySeq;
	}
	/** Collision model */
	const Collision::Desc* getCollision() const {
		return desc.collisionDesc.get();
	}

	/** Optimisation */
	const Optimisation* getOptimisation() const {
		return optimisation.get();
	}

	/** Contact description */
	Desc& getDesc() {
		return desc;
	}
	const Desc& getDesc() const {
		return desc;
	}

	/** Context */
	golem::Context& getContext() {
		return context;
	}
	const golem::Context& getContext() const {
		return context;
	}

protected:
	/** Manipulator */
	Manipulator& manipulator;
	/** Context object */
	golem::Context &context;
	/** Contact description */
	Desc desc;

	/** Contacts */
	Contact3D::Map contacts;
	/** Query densities */
	Query::Map queryMap;
	/** Query densities */
	LinkQuerySeq querySeq;

	/** Configuration model */
	Configuration::Ptr configuration;

	/** Optimisation */
	Optimisation::Ptr optimisation;

	/** Creates Contact */
	Contact(const Desc& desc, Manipulator& manipulator);
};

void XMLData(grasp::Contact::Desc::Map::value_type& val, golem::XMLContext* xmlcontext, bool create = false);

//------------------------------------------------------------------------------

};	// namespace

//------------------------------------------------------------------------------

namespace golem {
	template <> void Stream::read(grasp::Contact::Config::Ptr& value) const;
	template <> void Stream::write(const grasp::Contact::Config::Ptr& value);

	template <> void Stream::read(grasp::Contact::Config& value) const;
	template <> void Stream::write(const grasp::Contact::Config& value);

	template <> void Stream::read(grasp::Contact::Config::Map::value_type& value) const;
	template <> void Stream::write(const grasp::Contact::Config::Map::value_type& value);
};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_CONTACT_CONTACT_H_*/
