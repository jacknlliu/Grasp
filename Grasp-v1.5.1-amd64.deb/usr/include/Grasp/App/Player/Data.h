/** @file Data.h
 *
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_APP_PLAYER_DATA_H_
#define _GRASP_APP_PLAYER_DATA_H_

//------------------------------------------------------------------------------

#include <Grasp/Core/Ctrl.h>
#include <Grasp/Core/Data.h>
#include <Grasp/Core/RB.h>
#include <Golem/Plan/Planner.h>

//------------------------------------------------------------------------------

namespace grasp {
namespace data {

//------------------------------------------------------------------------------

/** Initialises handler.
*	(Optionally) Implemented by Handler.
*/
class HandlerPlan {
public:
	/** Sets planner and controllers. */
	virtual void set(const golem::Planner& planner, const StringSeq& controllerIDSeq) = 0;
};

/** Trajectory collection and tools.
*	(Optionally) Implemented by Item.
*/
class Trajectory {
public:
	/** Sets waypoint collection with no velocity profile. */
	virtual void setWaypoints(const Waypoint::Seq& waypoints) = 0;
	/** Returns waypoints without velocity profile. */
	virtual const Waypoint::Seq& getWaypoints() const = 0;

	/** Returns command trajectory with velocity profile. */
	virtual void createTrajectory(golem::Controller::State::Seq& trajectory) = 0;
};

//------------------------------------------------------------------------------

};	// namespace
};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_APP_PLAYER_DATA_H_*/
