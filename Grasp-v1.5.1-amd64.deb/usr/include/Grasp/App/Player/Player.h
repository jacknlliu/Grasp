/** @file Player.h
 *
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_APP_PLAYER_PLAYER_H_
#define _GRASP_APP_PLAYER_PLAYER_H_

//------------------------------------------------------------------------------

#include <Grasp/App/Recorder/Recorder.h>
#include <Golem/UICtrl/UIPlanner.h>
#include <Grasp/Core/ActiveCtrl.h>
#include <Grasp/App/Player/Data.h>

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** Player. */
class Player : public Recorder {
public:
	/** Player description */
	class Desc : public Recorder::Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;

		/** Controller leafs ids in the controller tree */
		StringSeq controllerIDSeq;
		/** Sensors ids */
		StringSeq sensorIDSeq;

		/** Active controller libraries */
		Library::Path::Seq activectrls;

		/** Arm and hand + planner. */
		golem::UIPlanner::Desc::Ptr uiPlannerDesc;
		/** Arm tool bounds */
		golem::Bounds::Desc::Seq armToolBounds;
		/** Obstacle bounds */
		golem::Bounds::Desc::Seq obstacleBounds;
		/** Obstacle bounds appearance */
		golem::Appearance::Seq obstacleAppearance;

		/** Min trajectory duration */
		golem::SecTmReal trajectoryDuration;
		/** Trajectory idle time begin */
		golem::SecTmReal trajectoryIdleBegin;
		/** Trajectory idle time end */
		golem::SecTmReal trajectoryIdleEnd;
		/** Trajectory idle time performance */
		golem::SecTmReal trajectoryIdlePerf;
		/** Max trajectory plan trials */
		golem::U32 trajectoryTrials;
		/** Default name */
		std::string trajectoryName;
		/** Default handler */
		std::string trajectoryHandler;

		/** Server port */
		unsigned short serverPort;
		/** Server clients */
		golem::U32 serverClients;
		/** Server message interval */
		golem::SecTmReal serverMessageInterval;

		/** Constructs from description object */
		Desc() {
			Desc::setToDefault();
		}
		/** Sets the parameters to the default values */
		virtual void setToDefault() {
			Recorder::Desc::setToDefault();

			controllerIDSeq.clear();
			sensorIDSeq.clear();
			activectrls.clear();

			uiPlannerDesc.reset(new golem::UIPlanner::Desc);
			armToolBounds.clear();
			obstacleBounds.clear();
			obstacleAppearance.clear();
			
			trajectoryDuration = golem::SecTmReal(1.0);
			trajectoryIdleBegin = golem::SecTmReal(0.5);
			trajectoryIdleEnd = golem::SecTmReal(1.0);
			trajectoryIdlePerf = golem::SecTmReal(5.0);
			trajectoryTrials = 5;
			trajectoryName = "trajectory";
			trajectoryHandler = "Trajectory+Trajectory";

			serverPort = 54312;
			serverClients = 0; // disable by default
			serverMessageInterval = golem::SecTmReal(60.0);
		}
		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			Recorder::Desc::assertValid(ac);

			Assert::valid(uiPlannerDesc != nullptr && uiPlannerDesc->isValid(), ac, "uiPlannerDesc: invalid");
			for (golem::Bounds::Desc::Seq::const_iterator i = armToolBounds.begin(); i != armToolBounds.end(); ++i)
				Assert::valid(*i != nullptr && (*i)->isValid(), ac, "armToolBounds[i]: invalid");
			for (golem::Bounds::Desc::Seq::const_iterator i = obstacleBounds.begin(); i != obstacleBounds.end(); ++i)
				Assert::valid(*i != nullptr && (*i)->isValid(), ac, "obstacleBounds[i]: invalid");
			Assert::valid(obstacleAppearance.size() == obstacleBounds.size(), ac, "obstacleAppearance: invalid size");
			for (golem::Appearance::Seq::const_iterator i = obstacleAppearance.begin(); i != obstacleAppearance.end(); ++i)
				Assert::valid(i->isValid(), ac, "obstacleAppearance[i]: invalid");

			Assert::valid(trajectoryDuration > golem::SecTmReal(0.0), ac, "trajectoryDuration <= 0");
			Assert::valid(trajectoryIdleBegin >= golem::SecTmReal(0.0), ac, "trajectoryIdleBegin < 0");
			Assert::valid(trajectoryIdleEnd >= golem::SecTmReal(0.0), ac, "trajectoryIdleEnd < 0");
			Assert::valid(trajectoryIdlePerf >= golem::SecTmReal(0.0), ac, "trajectoryIdleEnd < 0");
			Assert::valid(trajectoryTrials > 0, ac, "trajectoryTrials <= 0");
			Assert::valid(!trajectoryName.empty(), ac, "trajectoryName: empty");
			Assert::valid(!trajectoryHandler.empty(), ac, "trajectoryHandler: empty");

			Assert::valid(serverPort > 0, ac, "serverPort: invalid");
			Assert::valid(serverMessageInterval >= golem::SEC_TM_REAL_ZERO, ac, "serverMessageInterval: < 0");
		}
		/** Load descritpion from xml context. */
		virtual void load(golem::Context& context, const golem::XMLContext* xmlcontext);

	protected:
		GRASP_CREATE_FROM_OBJECT_DESC1(Player, golem::Object::Ptr, golem::Scene&)
	};

	/** Runs main task */
	virtual void main(bool runMenu = true);

protected:
	/** UIPlanner */
	golem::UIPlanner* uiPlanner;
	/** Planner */
	golem::Planner* planner;
	/** Robot controller heuristic */
	golem::Heuristic* heuristic;
	/** Robot controller */
	golem::Controller* controller;

	/** Controller state info */
	golem::Controller::State::Info info;
	/** Controller state info */
	golem::Controller::State::Info armInfo;
	/** Controller state info */
	golem::Controller::State::Info handInfo;

	/** Arm tool bounds */
	golem::Bounds::Desc::Seq armToolBounds;
	/** Obstacle bounds */
	golem::Bounds::Desc::Seq obstacleBounds;
	/** Obstacle actors */
	golem::Object::Seq obstacles;

	/** Min trajectory duration */
	golem::SecTmReal trajectoryDuration;
	/** Trajectory idle time */
	golem::SecTmReal trajectoryIdleBegin;
	/** Trajectory idle time end */
	golem::SecTmReal trajectoryIdleEnd;
	/** Trajectory idle time performance */
	golem::SecTmReal trajectoryIdlePerf;
	/** Max trajectory plan trials */
	golem::U32 trajectoryTrials;
	/** Default name */
	std::string trajectoryName;
	/** Default handler */
	std::string trajectoryHandler;

	/** Server port */
	unsigned short serverPort;
	/** Server clients */
	golem::U32 serverClients;
	/** Server message interval */
	golem::SecTmReal serverMessageInterval;

	/** Used controller leafs in the controller tree */
	golem::Controller::PtrSeq controllerSeq;
	/** Used sensors */
	Sensor::Seq sensorSeq;

	/** ActiveCtrl interface */
	ActiveCtrl::Map activectrlMap;
	/** ActiveCtrl sequence in order of initialisation */
	ActiveCtrl::Seq activectrlSeq;
	/** ActiveCtrl pointer */
	ActiveCtrl::Map::iterator activectrlCurrentPtr;

	/** Object renderer */
	golem::DebugRenderer objectRenderer;

	/** Forward kinematics all chains */
	virtual golem::GenWorkspaceChainState forwardTransformChains(const golem::ConfigspaceCoord& cc) const;
	inline golem::GenWorkspaceChainState forwardTransformChains(const golem::Controller::State& state) const { return forwardTransformChains(state.cpos); }
	/** Forward kinematics arm end-effector */
	virtual golem::Mat34 forwardTransformArm(const golem::ConfigspaceCoord& cc) const;
	inline golem::Mat34 forwardTransformArm(const golem::Controller::State& state) const { return forwardTransformArm(state.cpos); }
	/** (Global search) trajectory from the configuration space and/or workspace target */
	virtual RBDist findTrajectory(const golem::Controller::State& begin, const golem::Controller::State* pcend, const golem::Mat34* pwend, golem::SecTmReal t, golem::Controller::State::Seq& trajectory);
	/** (Local search) trajectory of the arm only from a sequence of configuration space targets in a new reference frame */
	virtual RBDist transformTrajectory(const golem::Mat34& trn, golem::Controller::State::Seq::const_iterator begin, golem::Controller::State::Seq::const_iterator end, golem::Controller::State::Seq& trajectory);
	/** Send trajectory */
	virtual void sendTrajectory(const golem::Controller::State::Seq& trajectory, bool clear = false);

	/** Colision bounds */
	CollisionBounds::Ptr selectCollisionBounds(bool draw = true);
	/** Perform trajectory */
	virtual void perform(const std::string& data, const std::string& item, const golem::Controller::State::Seq& trajectory, bool testTrajectory = true);

	/** Move to the specified configuration */
	virtual void gotoConfig(const golem::Controller::State& state);
	/** Move to the specified configuration */
	virtual void gotoPose(const ConfigMat34& pose);
	/** Read current configuration */
	virtual void getPose(golem::U32 joint, ConfigMat34& pose) const;

	// golem::Object interface
	virtual void render() const;

	/** UIKeyboardMouse: Mouse button handler. */
	virtual void mouseHandler(int button, int state, int x, int y);
	/** UIKeyboardMouse: Mouse motion handler. */
	virtual void motionHandler(int x, int y);
	/** UIKeyboardMouse: Keyboard handler. */
	virtual void keyboardHandler(int key, int x, int y);

	void create(const Desc& desc);
	Player(golem::Scene &scene);
	~Player();
};

//------------------------------------------------------------------------------

};	// namespace


#endif /*_GRASP_APP_PLAYER_PLAYER_H_*/
