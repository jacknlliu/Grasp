/** @file Data.h
 *
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_APP_RECORDER_DATA_H_
#define _GRASP_APP_RECORDER_DATA_H_

//------------------------------------------------------------------------------

#include <Grasp/Core/Data.h>
#include <Grasp/Core/Camera.h>
#include <Grasp/Core/Triangle.h>
#include <Golem/Math/VecN.h>
#include <Golem/Math/Rand.h>
#include <vector>
#include <map>
#include <set>

//------------------------------------------------------------------------------

namespace grasp {
namespace data {

//------------------------------------------------------------------------------

/** Captures snapshot or sequence from sensor.
*	(Optionally) Implemented by Handler.
*/
class Capture {
public:
	/** Sensor control with sync start and stop condition. */
	typedef std::function<bool(const grasp::TimeStamp*)> Control;

	/** Captures snapshot or sequence from sensor. */
	virtual Item::Ptr capture(grasp::Sensor& sensor, Control control) = 0;
};

/** Estimates model pose.
*	(Optionally) Implemented by Item.
*/
class Model {
public:
	/** Estimates model pose. */
	virtual void model(grasp::ConfigMat34& config, golem::Mat34& frame, Vec3Seq* vertices = nullptr, TriangleSeq* triangles = nullptr) = 0;
};

//------------------------------------------------------------------------------

/** Position and normal in 3D.
*	(Optionally) Implemented by Item.
*/
class Point3D {
public:
	/** Point3D interface sequence */
	typedef std::vector<Point3D*> Seq;
	/** Point3D interface sequence */
	typedef std::vector<const Point3D*> ConstSeq;

	/** Default floating point */
	typedef golem::F64 Real;
	/** Default 3D vector */
	typedef golem::_Vec3<Real> Vec3;
	/** Default 3D rotation matrix */
	typedef golem::_Mat33<Real> Mat33;
	/** Default 3D rigid body transformation */
	typedef golem::_Mat34<Real> Mat34;
	/** Default SE(3) distance metric */
	typedef grasp::_RBDist<Real> RBDist;

	/** Weighted point */
	class Point : public Vec3, public golem::Sample<Real> {
	public:
		/** Sequence */
		typedef std::vector<Point> Seq;

		/** Construction */
		Point(const Vec3& vec = Vec3(), Real weight = golem::numeric_const<Real>::ONE, Real cdf = -golem::numeric_const<Real>::ONE) :
			Vec3(vec), golem::Sample<Real>(weight, cdf)
		{}
	};

	/** Total number of available points */
	virtual size_t getNumOfPoints() const = 0;
	/** Sample point. */
	virtual size_t samplePoint(golem::Rand& rand) const = 0;
	/** Conditional point */
	virtual Point getPoint(size_t index) const = 0;

	/** Point transform */
	virtual void transform(const golem::Mat34& trn) = 0;

	/** Sensor frame. */
	virtual void getSensorFrame(golem::Mat34& frame) const = 0;
};

/** 3D feature consists of a frame and a feature vector.
*	(Optionally) Implemented by Item.
*/
class Normal3D : public Point3D {
public:
	/** Query density normal covariance */
	virtual RBDist getNormalCovariance() const = 0;

	/** Select normal given point index. */
	virtual void getNormal(size_t index, Vec3& normal) const = 0;
};

/** 3D feature consists of a frame and a feature vector.
*	(Optionally) Implemented by Item.
*/
class Feature3D : public Point3D {
public:
	/** Feature size */
	static const size_t FEATURE_SIZE = 12;
	/** Feature vector */
	typedef golem::_VecN<Real, FEATURE_SIZE> Feature;

	/** Featur covariance */
	virtual Feature getFeatureCovariance() const = 0;
	/** Query density frame covariance */
	virtual RBDist getFrameCovariance() const = 0;

	/** Select feature given point index. Do not sample orientation - return only mean value to use later with sensor model.  */
	virtual void getFeature(size_t index, Feature& feature, Mat33& orientation) const = 0;

	/** Sample local frame orientations from sensor model. */
	virtual void sampleSensorModel(golem::Rand& rand, size_t index, Mat33& orientation) const = 0;

	/** Debug reset */
	virtual void debugReset() const {}
	/** Debug string */
	virtual void debugString(std::string& str) const {}
};

/** Hierarchies of parts 3D consists of a unique identifier, a frame and has some spatial extent.
*	(Optionally) Implemented by Item.
*/
class Part3D : public Point3D {
public:
	/** Index */
	typedef golem::U32 Index;
	/** Index set */
	typedef std::set<Index> IndexSet;
	/** Index map */
	typedef std::map<Index, Index> IndexMap;
	/** Index sequence map */
	typedef std::map<Index, IndexSet> IndexSetMap;

	/** Identifier type */
	enum IndexType {
		/** Default/uninitialised id */
		INDEX_TYPE_DEFAULT = -1,
	};

	/** Part */
	class Part : public golem::Sample<Real> {
	public:
		/** Realisation -> model mapping */
		typedef std::map<Index, Part> Map;

		/** Model */
		Index model;
		/** Frame */
		Mat34 frame;

		Part(Index model = INDEX_TYPE_DEFAULT, Real weight = golem::numeric_const<Real>::ONE, Real cdf = -golem::numeric_const<Real>::ONE) :
			model(model), golem::Sample<Real>(weight, cdf)
		{}
		Part(Mat34& frame, Index model = INDEX_TYPE_DEFAULT, Real weight = golem::numeric_const<Real>::ONE, Real cdf = -golem::numeric_const<Real>::ONE) :
			frame(frame), model(model), golem::Sample<Real>(weight, cdf)
		{}
	};

	/** Query density frame covariance for a given id */
	virtual RBDist getFrameCovariance(Index model) const = 0;

	/** Select id given point index. Do not sample orientation - return only mean value to use later with sensor model. */
	virtual void getPart(size_t index, Part::Map& partMap) const = 0;

	/** Sample local frames from sensor model. */
	virtual void sampleSensorModel(golem::Rand& rand, size_t index, Index model, Mat34& frame) const = 0;
};

//------------------------------------------------------------------------------

};	// namespace
};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_APP_RECORDER_DATA_H_*/
