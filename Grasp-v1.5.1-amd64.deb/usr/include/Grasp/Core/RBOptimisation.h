/** @file RBOptimisation.h
 * 
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_CORE_RBOPTIMISATION_H_
#define _GRASP_CORE_RBOPTIMISATION_H_

//------------------------------------------------------------------------------

#include <Golem/Math/Optimisation.h>
#include <Grasp/Core/RB.h>
#include <functional>
#include <vector>

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** Rigid body optimisation vector */
template <typename _RBCoord, size_t _RB_N, size_t _M = 0> class RBVec {
public:
	/** Sequence of vectors*/
	typedef std::vector<RBVec> Seq;
	/** Rigid body coordinate */
	typedef _RBCoord Coord;
	/** Transformations */
	static const size_t RB_N = _RB_N;
	/** Reserved dimensions */
	static const size_t M = _M;
	/** Total dimensions */
	static const size_t N = RB_N*_RBCoord::N + M;

	/** Data */
	golem::Real data[N];
	
	/** Access to reserved dimensions. */
	inline golem::Real& getReserved(size_t idx) {
		return data[RB_N*_RBCoord::N + idx];
	}
	/** Access to reserved dimensions. */
	inline const golem::Real& getReserved(size_t idx) const {
		return data[RB_N*_RBCoord::N + idx];
	}
	
	/** Access vector of coordinates. */
	inline _RBCoord& getRB(size_t idx) {
		return (_RBCoord&)data[idx*_RBCoord::N];
	}
	/** Access vector of coordinates. */
	inline const _RBCoord& getRB(size_t idx) const {
		return (const _RBCoord&)data[idx*_RBCoord::N];
	}

	/** Access vector of reals as an array. */
	inline golem::Real& operator [] (size_t idx) {
		return data[idx];
	}
	/** Access vector of reals as an array. */
	inline const golem::Real& operator [] (size_t idx) const {
		return data[idx];
	}
};

/** Rigid body optimisation heuristic. */
template <typename _RBCoord, size_t _RB_N, size_t _M = 0> class RBHeuristic : public golem::DEHeuristic<golem::U32, grasp::RBVec<_RBCoord, _RB_N, _M>, golem::Real> {
public:
	/** Heuristic base class */
	typedef golem::DEHeuristic<golem::U32, grasp::RBVec<_RBCoord, _RB_N, _M>, golem::Real> Heuristic;

	/** Thread data */
	typedef typename Heuristic::ThreadData ThreadData;
	/** Vector type */
	typedef typename Heuristic::Vec Vec;
	/** Value type */
	typedef typename Heuristic::Type Type;

	/** Sample function */
	typedef std::function<void(golem::Rand&, Vec&)> Sample;
	/** Process function */
	typedef std::function<void(Vec&)> Process;
	/** Objective function */
	typedef std::function<golem::Real(const Vec&)> Value;
	/** Distance function */
	typedef std::function<golem::Real(const Vec&, const Vec&)> Distance;

	/** Sample function */
	Sample pSample;
	/** Process function */
	Process pProcess;
	/** Objective function */
	Value pValue;
	/** Distance function */
	Distance pDistance;

	/** Initialisation */
	RBHeuristic(golem::Context& context) : Heuristic(context) {
	}

	/** Vector size */
	inline size_t size() const {
		return Vec::N;
	}
	/** Vector sampling */
	inline void sample(golem::Rand& rand, Vec& vector) {
		if (pSample) pSample(rand, vector);
	}
	/** Vector processing */
	inline void process(Vec& vector, ThreadData& threadData) const {
		if (pProcess) pProcess(vector);
	}
	/** Objective function */
	inline Type value(Vec& vector, ThreadData& threadData) const {
		return pValue ? pValue(vector) : golem::numeric_const<Type>::ZERO;
	}
	/** Default distance function implemented as Euclidean distance */
	inline Type distance(const Vec& a, const Vec& b) const {
		return pDistance ? pDistance(a, b) : golem::numeric_const<Type>::ZERO;
	}
};

//------------------------------------------------------------------------------

};	// namespace grasp

#endif /*_GRASP_CORE_RBOPTIMISATION_H_*/
