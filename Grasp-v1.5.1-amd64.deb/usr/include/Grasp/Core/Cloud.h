/** @file Cloud.h
 * 
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_CORE_CLOUD_H_
#define _GRASP_CORE_CLOUD_H_

//------------------------------------------------------------------------------

#include <Grasp/Core/Defs.h>
#include <Grasp/Core/Import.h>
#include <Golem/Math/Quat.h>
#include <Golem/Math/Bounds.h>
#include <Golem/Math/Queue.h>
#include <Golem/UI/Renderer.h>
#include <limits>

#define PCL_NO_PRECOMPILE
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** Point cloud tools */
class Cloud {
public:
	/** Point type */
	typedef pcl::PointXYZRGBNormal Point;
	/** Point sequence */
	typedef pcl::PointCloud<Point> PointSeq;
	/** Point sequence pointer */
	typedef boost::shared_ptr<PointSeq> PointSeqPtr;
	
	/** Point sequence queue */
	typedef golem::queue<PointSeq> PointSeqQueue;

	/** Curvature */
	typedef pcl::PrincipalCurvatures Curv;

	/** Point with curvature type definition */
	struct EIGEN_ALIGN16 PointCurv : public Point, public Curv {
		/** Reset all members to the default values */
		PointCurv() {
			principal_curvature_x = principal_curvature_y = principal_curvature_z = golem::numeric_const<float>::ZERO;
			pc1 = pc2 = golem::numeric_const<float>::ZERO;
		}

		EIGEN_MAKE_ALIGNED_OPERATOR_NEW
	};
	typedef pcl::PointCloud<PointCurv> PointCurvSeq;
	/** Point with curvature sequence pointer */
	typedef boost::shared_ptr<PointCurvSeq> PointCurvSeqPtr;

	/** Appearance */
	class Appearance {
	public:
		/** Mode */
		enum Mode {
			/** Nothing */
			MODE_NONE,
			/** Point */
			MODE_POINT,
			/** Normal */
			MODE_NORMAL,
			/** Local frame*/
			MODE_FRAME,
			/** Feature #1 */
			MODE_FEATURE_1,
			/** Feature #2 */
			MODE_FEATURE_2,
		};

		/** Mode name */
		static const char* ModeName[];

		/** Cloud mode */
		Mode mode;
		/** Cloud 3D mode */
		bool mode3D;
		/** Cloud 3D mode transparency */
		golem::U32 mode3DA;

		/** Point size */
		golem::Real pointSize;
		/** Number of frames to show */
		golem::U32 frameNum;
		/** Frame axes size multiplier */
		golem::Vec3 frameSize;

		/** Show camera frame */
		bool cameraFrame;
		/** Camera Frame size */
		golem::Real cameraFrameSize;

		/** Colour override flag */
		bool colourOverride;
		/** Colour override */
		golem::RGBA colour;

		/** Feature curvature power */
		golem::Real featureCurvPow;

		/** View point */
		mutable golem::Vec3 viewPoint;
		/** View direction */
		mutable golem::Vec3 viewDir;

		/** Constructs description. */
		Appearance() {
			setToDefault();
		}
		/** Sets the parameters to the default values. */
		void setToDefault() {
			mode = MODE_POINT;
			mode3D = true;
			mode3DA = 177;
			pointSize = golem::Real(1.0);
			frameNum = 100;
			frameSize.set(golem::Real(0.01), golem::Real(0.01), golem::Real(0.02));
			cameraFrame = true;
			cameraFrameSize = golem::Real(0.05);
			colourOverride = false;
			colour = golem::RGBA::BLACK;
			viewPoint.set(golem::REAL_ZERO, golem::REAL_ZERO, golem::REAL_ONE);
			viewDir.set(golem::REAL_ZERO, golem::REAL_ZERO, -golem::REAL_ONE);
			featureCurvPow = golem::REAL_ONE;
		}
		/** Assert that the object is valid. */
		void assertValid(const Assert::Context& ac) const {
			Assert::valid(mode3DA <= (golem::U32)golem::numeric_const<golem::U8>::MAX, ac, "mode3DA: > 255", mode3DA);
			Assert::valid(pointSize > golem::REAL_ZERO, ac, "pointSize <= 0");
			Assert::valid(frameNum > 0, ac, "frameNum: 0");
			Assert::valid(frameSize.isPositive(), ac, "frameSize <= 0");
			Assert::valid(cameraFrameSize > 0, ac, "cameraFrameSize: 0");
			Assert::valid(viewPoint.isFinite(), ac, "viewPoint: invalid");
			Assert::valid(viewDir.isFinite(), ac, "viewDir: invalid");
			Assert::valid(golem::Math::isFinite(featureCurvPow), ac, "featureCurvPow: invalid");
		}
		/** Reads/writes object from/to a given XML context */
		void xmlData(golem::XMLContext* context, bool create = false) const;

		/** Point drawing */
		template <typename _Seq> void drawPoints(const _Seq& points, golem::DebugRenderer& renderer, const golem::Mat34* trn = nullptr) const {
			for (typename _Seq::const_iterator i = points.begin(); i != points.end(); ++i) {
				if (Cloud::isNanXYZ(*i))
					continue;
				const golem::Vec3 p = trn ? *trn * Cloud::getPoint<golem::Real>(*i) : Cloud::getPoint<golem::Real>(*i);
				const golem::RGBA rgba = colourOverride ? colour : Cloud::getColour(*i);
				if (mode == MODE_NORMAL) {
					golem::Vec3 n;
					n.multiplyAdd(frameSize.z, trn ? trn->R * Cloud::getNormal<golem::Real>(*i) : Cloud::getNormal<golem::Real>(*i), p);
					renderer.addLine(p, n, rgba);
				}
				else if (mode != MODE_NONE) {
					renderer.addPoint(p, rgba);
				}
			}
			if (cameraFrame) {
				const golem::Mat34 frame = trn ? *trn * Cloud::getSensorFrame(points) : Cloud::getSensorFrame(points);
				mode3D ? renderer.addAxes3D(frame, golem::Vec3(cameraFrameSize), (golem::U8)mode3DA) : renderer.addAxes(frame, golem::Vec3(cameraFrameSize));
			}
		}
		/** Point drawing */
		void draw(const PointSeq& points, golem::DebugRenderer& renderer, const golem::Mat34* trn = nullptr) const;
		/** Point drawing */
		void draw(const PointCurvSeq& points, golem::DebugRenderer& renderer, const golem::OpenGL* openGL = nullptr) const;

	protected:
		/** Point - view direction projection */
		struct Projection {
			typedef std::vector<Projection> Seq;
			golem::Real distance;
			const PointCurv* point;
		};
		/** Projections */
		mutable Projection::Seq projections;
	};

	/** Import algortihms */
	class Import : public grasp::Import {
	public:
		/** Object RGBA colour of the point */
		golem::RGBA colour;
		/** Transform */
		golem::Mat34 transform;

		/** Constructs the object */
		Import() {
			setToDefault();
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			grasp::Import::setToDefault();

			colour = golem::RGBA(127, 127, 127, 255); // grey
			transform.setId();
		}
		/** Assert that the object is valid. */
		void assertValid(const Assert::Context& ac) const {
			grasp::Import::assertValid(ac);
			Assert::valid(transform.isValid(), ac, "transform: invalid");
		}
		/** Reads/writes object from/to a given XML context */
		void xmlData(golem::XMLContext* context, bool create = false);

		/** Import point cloud from XYZ and Normal text file */
		void pointCloudXYZNormal(golem::Context& context, const std::string& path, PointSeq& points) const;
		/** Import triangle mesh from obj file */
		void pointCloudObj(golem::Context& context, const std::string& path, PointSeq& points) const;
		/** Import triangle mesh from ply file */
		void pointCloudPly(golem::Context& context, const std::string& path, PointSeq& points) const;

		/** Import point cloud from XYZ and RGBA PCL file */
		void pointCloudPCLXYZRGBA(golem::Context& context, const std::string& path, PointSeq& points) const;

		/** Generate point cloud */
		void generate(golem::Context& context, const Vec3Seq& vertices, const TriangleSeq& triangles, PointSeq& points) const;
		/** Downample point cloud */
		void downsample(golem::Context& context, PointSeq& points) const;

		/** PCL point creation */
		template <typename _PCLPoint> static _PCLPoint make(const golem::Vec3& p, const golem::Vec3& n, const golem::RGBA& colour) {
			_PCLPoint point; // sets members to the default values
			p.getColumn3(&point.x);
			n.getColumn3(&point.normal_x);
			colour.get(point.r, point.b, point.g, point.a);
			return point;
		}
		/** PCL point creation */
		template <typename _PCLPoint> static _PCLPoint make(const golem::Mat34& frame, golem::Vec3 p, golem::Vec3 n, const golem::RGBA& colour) {
			frame.multiply(p, p);
			frame.R.multiply(n, n);
			return make<_PCLPoint>(p, n, colour);
		}
	};

	/** Erase given range */
	template <typename _Seq, typename _Range> static void erase(_Seq& seq, const _Range &range) {
		seq.erase(range.first, range.second);
	}

	/** Point cloud string info */
	template <typename _Seq> static std::string toString(const _Seq& seq) {
		std::stringstream str;
		str << "size: ";
		if (seq.isOrganized())
			str << seq.width << "x" << seq.height;
		else
			str << seq.size();
		return str.str();
	}
	
	/** Test val is NaN */
	template <typename _Type> static inline bool isNan(const _Type& val) {
		return !golem::Math::isFinite(val);
	}
	/** Test if XYZ vector is NaN */
	template <typename _Point> static inline bool isNanXYZ(const _Point& point) {
		return isNan(point.x) || isNan(point.y) || isNan(point.z);
	}
	/** Test if normal vector is NaN */
	template <typename _Point> static inline bool isNanNormal(const _Point& point) {
		return isNan(point.normal_x) || isNan(point.normal_y) || isNan(point.normal_z);
	}
	/** Test if Curvature vector is NaN */
	template <typename _Point> static inline bool isNanCurvature(const _Point& point) {
		return isNan(point.pc1) || isNan(point.pc2);
	}
	/** Test if XYZ Normal vector is NaN */
	template <typename _Point> static inline bool isNanXYZNormal(const _Point& point) {
		return isNanXYZ(point) || isNanNormal(point);
	}
	/** Test if XYZ Normal Curvature vector is NaN */
	template <typename _Point> static inline bool isNanXYZNormalCurvature(const _Point& point) {
		return isNanXYZNormal(point) || isNanCurvature(point);
	}
	/** Raw point sequence test */
	template <typename _Seq> static inline bool isNanXYZNormalSeq(const _Seq& points) {
		for (typename _Seq::const_iterator i = points.begin(); i != points.end(); ++i)
			if (isNanXYZNormal(*i))
				return true;
		return false;
	}
	/** Raw point sequence test */
	template <typename _Seq> static inline bool isNanXYZNormalCurvatureSeq(const _Seq& points) {
		for (typename _Seq::const_iterator i = points.begin(); i != points.end(); ++i)
			if (isNanXYZNormalCurvature(*i))
				return true;
		return false;
	}

	/** Set val to NaN */
	template <typename _Type> static inline void setNan(_Type& val) {
		val = std::numeric_limits<_Type>::quiet_NaN();
	}
	/** Set XYZ vector to NaN */
	template <typename _Point> static inline void setNanXYZ(_Point& point) {
		setNan(point.x);
		setNan(point.y);
		setNan(point.z);
	}

	/** Test if xyz vector is normalised */
	template <typename _Type> static inline bool isNormalised(const _Type& x, const _Type& y, const _Type& z, _Type eps = golem::numeric_const<_Type>::EPS) {
		return golem::Math::equals(x*x + y*y + z*z, golem::numeric_const<_Type>::ONE, eps);
	}
	/** Normalise xyz vector */
	template <typename _Type> static inline bool normalise(_Type& x, _Type& y, _Type& z, _Type eps = golem::numeric_const<_Type>::EPS) {
		_Type magnitude = golem::Math::sqrt(x*x + y*y + z*z);
		if (magnitude > eps) {
			const _Type length = golem::numeric_const<_Type>::ONE / magnitude;
			x *= length;
			y *= length;
			z *= length;
			return true;
		}
		else
			return false;
	}
	/** Test point is normalised */
	template <typename _Point, typename _Type> static inline bool isNormalised(const _Point& point, _Type eps = golem::numeric_const<_Type>::EPS) {
		return isNormalised(point.normal_x, point.normal_y, point.normal_z, eps);
	}
	/** Normalise xyz vector */
	template <typename _Point, typename _Type> static inline bool normalise(_Point& point, _Type eps = golem::numeric_const<_Type>::EPS) {
		return normalise(point.normal_x, point.normal_y, point.normal_z, eps);
	}
	/** Default point sequence test */
	template <typename _Seq, typename _Type> static inline bool isNormalisedSeq(const _Seq& points, _Type eps = golem::numeric_const<_Type>::EPS) {
		for (typename _Seq::const_iterator i = points.begin(); i != points.end(); ++i)
			if (!isNanXYZ(*i) && !isNormalised(*i, eps))
				return false;
		return true;
	}
	/** Normalise xyz vector */
	template <typename _Seq, typename _Type> static inline void normaliseSeq(_Seq& points, _Type eps = golem::numeric_const<_Type>::EPS) {
		for (typename _Seq::iterator i = points.begin(); i != points.end(); ++i)
			if (!isNanXYZ(*i) && (isNanNormal(*i) || !normalise(*i, eps)))
				setNanXYZ(*i);
	}

	/** Dense point cloud */
	template <typename _Seq> static void setDense(_Seq& points) {
		points.width = 1;
		points.height = (int)points.size();
		points.is_dense = true; // i.e. has no invalid points NaNs/Infs
	}

	/** Resize point cloud */
	template <typename _Seq> static void resize(_Seq& points, size_t size) {
		if (size <= 0)
			throw golem::Message(golem::Message::LEVEL_ERROR, "Cloud::resize(): size must be greater than zero");
		points.resize(size);
		setDense(points);
	}

	/** Point cloud camera origin */
	template <typename _Seq> static inline golem::Vec3 getSensorOrigin(const _Seq& points) {
		return golem::Vec3(points.sensor_origin_.x(), points.sensor_origin_.y(), points.sensor_origin_.z());
	}
	/** Point cloud camera orientation */
	template <typename _Seq> static inline golem::Quat getSensorOrientation(const _Seq& points) {
		return golem::Quat(points.sensor_orientation_.w(), points.sensor_orientation_.x(), points.sensor_orientation_.y(), points.sensor_orientation_.z());
	}
	/** Point cloud camera frame */
	template <typename _Seq> static golem::Mat34 getSensorFrame(const _Seq& points) {
		return golem::Mat34(golem::Mat33(getSensorOrientation(points)), getSensorOrigin(points));
	}

	/** Point cloud camera origin */
	template <typename _Seq> static inline void setSensorOrigin(const golem::Vec3& p, _Seq& points) {
		points.sensor_origin_.x() = (float)p.x;
		points.sensor_origin_.y() = (float)p.y;
		points.sensor_origin_.z() = (float)p.z;
		points.sensor_origin_.w() = (float)0.0;
	}
	/** Point cloud camera orientation */
	template <typename _Seq> static inline void setSensorOrientation(const golem::Quat& q, _Seq& points) {
		points.sensor_orientation_.x() = (float)q.x;
		points.sensor_orientation_.y() = (float)q.y;
		points.sensor_orientation_.z() = (float)q.z;
		points.sensor_orientation_.w() = (float)q.w;
	}
	/** Point cloud camera frame */
	template <typename _Seq> static void setSensorFrame(const golem::Mat34& cameraFrame, _Seq& points) {
		setSensorOrigin(cameraFrame.p, points);
		setSensorOrientation(golem::Quat(cameraFrame.R), points);
	}

	/** Get Golem RGBA colour */
	template <typename _Point> static inline golem::RGBA getColour(const _Point& point) {
		return golem::RGBA(point.r, point.g, point.b, point.a);
	}
	/** Set Golem RGBA colour */
	template <typename _Point> static inline void setColour(const golem::RGBA& rgba, _Point& point) {
		point.r = (uint8_t)rgba._rgba.r;
		point.g = (uint8_t)rgba._rgba.g;
		point.b = (uint8_t)rgba._rgba.b;
		point.a = (uint8_t)rgba._rgba.a;
	}

	/** Get Golem point */
	template <typename _Real, typename _Point> static inline golem::_Vec3<_Real> getPoint(const _Point& point) {
		return golem::_Vec3<_Real>(point.x, point.y, point.z);
	}
	/** Set Golem point */
	template <typename _Real, typename _Point> static inline void setPoint(const golem::_Vec3<_Real>& vec, _Point& point) {
		vec.getColumn3(&point.x);
	}

	/** Get Golem normal */
	template <typename _Real, typename _Point> static inline golem::_Vec3<_Real> getNormal(const _Point& point) {
		return golem::_Vec3<_Real>(point.normal_x, point.normal_y, point.normal_z);
	}
	/** Set Golem normal */
	template <typename _Real, typename _Point> static inline void setNormal(const golem::_Vec3<_Real>& vec, _Point& point) {
		vec.getColumn3(&point.normal_x);
	}

	/** Compute (scaled) curvature from principal curvature */
	template <typename _Real, typename _Point> static inline golem::_Vec3<_Real> getCurvature(const _Point& point, _Real pow = golem::numeric_const<_Real>::ONE) {
		using namespace golem;
		//return _Vec3<_Real>(_Real(point.pc1), _Real(point.pc2), numeric_const<_Real>::ONE);
		return _Vec3<_Real>(Math::sign(Math::pow(Math::abs(_Real(point.pc1)), pow), _Real(point.pc1)), Math::sign(Math::pow(Math::abs(_Real(point.pc2)), pow), _Real(point.pc2)), numeric_const<_Real>::ONE);
	}

	/** Compute local orientation from normal (z axis) and principal curvature vector (x axis) */
	template <typename _Real, typename _Point> inline static golem::_Mat33<_Real> getOrientation(const golem::_Vec3<_Real>& normal, const _Point& point) {
		using namespace golem;
		_Vec3<_Real> x, y, z(normal);
		x.setColumn3(point.principal_curvature);
		y.cross(z, x);
		y.normalise();
		x.cross(y, z);
		x.normalise();
		_Mat33<_Real> orientation;
		orientation.fromAxes(x, y, z);
		return orientation;
	}
	/** Compute local orientation from normal (z axis) and principal curvature vector (x axis) */
	template <typename _Real, typename _Point> inline static golem::_Mat33<_Real> getOrientation(const _Point& point) {
		return getOrientation<_Real>(getNormal<_Real>(point), point);
	}

	/** Compute local frame from normal (z axis) and principal curvature vector (x axis) */
	template <typename _Real, typename _Point> inline static golem::_Mat34<_Real> getFrame(const _Point& point) {
		return golem::_Mat34<_Real>(getOrientation<_Real>(getNormal<_Real>(point), point), getPoint<_Real>(point));
	}

	/** Point copying */
	template <typename _Real, typename _Out> inline static void copyPointXYZ(const golem::_Vec3<_Real>& inp, _Out& out) {
		out.x = (float)inp.x;
		out.y = (float)inp.y;
		out.z = (float)inp.z;
		out.data[3] = golem::numeric_const<float>::ZERO;
	}
	/** Point copying */
	template <typename _Inp, typename _Out> inline static void copyPointXYZ(const _Inp& inp, _Out& out) {
		out.x = inp.x;
		out.y = inp.y;
		out.z = inp.z;
		out.data[3] = inp.data[3];
	}
	/** Point copying */
	template <typename _Inp, typename _Out> inline static void copyRGBA(const _Inp& inp, _Out& out) {
		out.r = inp.r;
		out.g = inp.g;
		out.b = inp.b;
		out.a = inp.a;
	}
	/** Point copying */
	template <typename _Inp, typename _Out> inline static void copyNormal(const _Inp& inp, _Out& out) {
		out.normal_x = inp.normal_x;
		out.normal_y = inp.normal_y;
		out.normal_z = inp.normal_z;
		out.data_n[3] = inp.data_n[3];
	}
	/** Point copying */
	template <typename _Inp, typename _Out> inline static void copyPrincipalCurvatures(const _Inp& inp, _Out& out) {
		out.principal_curvature_x = inp.principal_curvature_x;
		out.principal_curvature_y = inp.principal_curvature_y;
		out.principal_curvature_z = inp.principal_curvature_z;
		out.pc1 = inp.pc1;
		out.pc2 = inp.pc2;
	}
	/** Point copying */
	inline static void copyPoint(const pcl::_PointXYZRGBNormal& inp, pcl::_PointXYZRGBNormal& out) {
		copyPointXYZ(inp, out);
		copyRGBA(inp, out);
		copyNormal(inp, out);
	}
	/** Point copying */
	inline static void copyPoint(const pcl::_PointNormal& inp, pcl::_PointNormal& out) {
		copyPointXYZ(inp, out);
		copyNormal(inp, out);
	}
	/** Point copying */
	inline static void copyPoint(const PointCurv& inp, PointCurv& out) {
		copyPointXYZ(inp, out);
		copyRGBA(inp, out);
		copyNormal(inp, out);
		copyPrincipalCurvatures(inp, out);
	}
	/** Cloud header copying */
	template <typename _Inp, typename _Out> inline static void copyHeader(const _Inp& inp, _Out& out) {
		out.is_dense = inp.is_dense;
		out.width = inp.width;
		out.height = inp.height;
		out.sensor_origin_ = inp.sensor_origin_;
		out.sensor_orientation_ = inp.sensor_orientation_;
	}

	/** Filtering algortihm descriptiton */
	class FilterDesc {
	public:
		/** registration */
		bool enabled;

		/** Window size */
		golem::U32 window;
		/** Number of samples */
		golem::U32 samples;

		/** Constructs from description object */
		FilterDesc() {
			setToDefault();
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			enabled = true;
			window = 10;
			samples = 9;
		}
		/** Assert that the object is valid. */
		void assertValid(const Assert::Context& ac) const {
			Assert::valid(window >= samples, ac, "window: < samples");
		}
	};

	/** PCL outlier removal algortihm descriptiton */
	class OutRemDesc {
	public:
		/** Sequence */
		typedef std::vector<OutRemDesc> Seq;

		/** Outlier removal (RadiusOutlierRemoval) */
		bool enabledRadius;
		/** Outlier removal (StatisticalOutlierRemoval) */
		bool enabledStatistical;
		// Outlier removal parameters
		double radius;
		int minNeighborsInRadius;
		int meanK;
		double stddevMulThreshold;

		/** Constructs from description object */
		OutRemDesc() {
			setToDefault();
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			enabledRadius = true;
			enabledStatistical = false;
			radius = 0.005;
			minNeighborsInRadius = 20;
			meanK = 50;
			stddevMulThreshold = 1.0;
		}
		/** Assert that the object is valid. */
		void assertValid(const Assert::Context& ac) const {
			Assert::valid(golem::Math::isPositive(radius), ac, "radius: <= 0");
			Assert::valid(minNeighborsInRadius > 0, ac, "minNeighborsInRadius: < 1");
			Assert::valid(meanK > 1, ac, "meanK: < 2");
			Assert::valid(golem::Math::isPositive(stddevMulThreshold), ac, "stddevMulThreshold: <= 0");
		}
	};

	/** PCL downsampling algortihm descriptiton */
	class DownsampleDesc {
	public:
		/** Downsampling */
		bool enabled;

		/** Downsampling (with normals) */
		bool enabledWithNormals;
		/** Downsampling (VoxelGrid) */
		bool enabledVoxelGrid;

		// Downsampling parameters
		float gridLeafSize;

		/** Constructs from description object */
		DownsampleDesc() {
			setToDefault();
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			enabled = false;
			enabledWithNormals = true;
			enabledVoxelGrid = false;
			gridLeafSize = 0.003f;
		}
		/** Assert that the object is valid. */
		void assertValid(const Assert::Context& ac) const {
			Assert::valid(golem::Math::isPositive(gridLeafSize), ac, "gridLeafSize: <= 0");
		}
	};

	/** PCL segmentation algortihm descriptiton */
	class SegmentationDesc {
	public:
		/** Incremental segmentation */
		bool incremental;
		// segmentation parameters
		double distanceThreshold;

		/** Constructs from description object */
		SegmentationDesc() {
			setToDefault();
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			incremental = false;
			distanceThreshold = 0.0003;
		}
		/** Assert that the object is valid. */
		void assertValid(const Assert::Context& ac) const {
			Assert::valid(golem::Math::isPositive(distanceThreshold), ac, "distanceThreshold: <= 0");
		}
	};

	/** PCL normal estimation algortihm descriptiton */
	class NormalDesc {
	public:
		/** PCA (NormalEstimation) */
		bool enabledPCA;
		/** Integral image (IntegralImageNormalEstimation) */
		bool enabledII;
		/** MLS (MovingLeastSquares) */
		bool enabledMLS;
		/** Polynomial (better/slow) vs tangent estimation (worse/faster) */
		bool polynomialFit;
		/** Normal epsilon */
		float normalEps;
		/** Maximum distance to neighbours */
		double radiusSearch;
		/** MaxDepthChangeFactor */
		double maxDepthChangeFactor;
		/** NormalSmoothingSize */
		double normalSmoothingSize;

		/** Constructs from description object */
		NormalDesc() {
			setToDefault();
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			enabledPCA = true;
			enabledII = false;
			enabledMLS = false;
			normalEps = float(1e-5);
			polynomialFit = true;
			radiusSearch = 0.005;
			maxDepthChangeFactor = 0.02;
			normalSmoothingSize = 10.0;
		}
		/** Assert that the object is valid. */
		void assertValid(const Assert::Context& ac) const {
			Assert::valid(enabledPCA || enabledII || enabledMLS, ac, "enabledPCA || enabledII || enabledMLS: false");
			Assert::valid(golem::Math::isPositive(normalEps), ac, "normalEps: <= 0");
			Assert::valid(golem::Math::isPositive(radiusSearch), ac, "radiusSearch: <= 0");
			Assert::valid(golem::Math::isPositive(maxDepthChangeFactor), ac, "maxDepthChangeFactor: <= 0");
			Assert::valid(golem::Math::isPositive(normalSmoothingSize), ac, "normalSmoothingSize: <= 0");
		}
	};

	/** PCL curvature estimation algortihm descriptiton */
	class CurvatureDesc {
	public:
		/** Maximum distance to neighbours */
		double radiusSearch;
			
		/** Constructs from description object */
		CurvatureDesc() {
			setToDefault();
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			radiusSearch = 0.005;
		}
		/** Assert that the object is valid. */
		void assertValid(const Assert::Context& ac) const {
			Assert::valid(golem::Math::isPositive(radiusSearch), ac, "radiusSearch: <= 0");
		}
	};

	/** PCL registration algortihm descriptiton */
	class RegistrationDesc {
	public:
		/** registration */
		bool enabled;

		/** IterativeClosestPoint (RANSAC) */
		bool enabledIcp;
		/** IterativeClosestPointNonLinear */
		bool enabledIcpnl;
		// IPC parameters
		double maxCorrespondenceDistance;
		double RANSACOutlierRejectionThreshold;
		double transformationEpsilon;
		int maximumIterations;
		
		/** Constructs from description object */
		RegistrationDesc() {
			setToDefault();
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			enabled = false;

			enabledIcp = true;
			enabledIcpnl = false;

			maxCorrespondenceDistance = 0.1;//golem::Math::sqrt(golem::numeric_const<double>::MAX);
			RANSACOutlierRejectionThreshold = 0.05;
			transformationEpsilon = 0.0;
			maximumIterations = 50;
		}
		/** Assert that the object is valid. */
		void assertValid(const Assert::Context& ac) const {
			Assert::valid(maximumIterations > 0, ac, "maximumIterations: < 1");
			Assert::valid(golem::Math::isPositive(maxCorrespondenceDistance), ac, "maxCorrespondenceDistance: <= 0");
			Assert::valid(!golem::Math::isNegative(RANSACOutlierRejectionThreshold), ac, "RANSACOutlierRejectionThreshold: < 0");
			Assert::valid(!golem::Math::isNegative(transformationEpsilon), ac, "transformationEpsilon: < 0");
		}
	};

	/** PCL descriptiton */
	class Desc {
	public:
		/** Filtering algortihm descriptiton */
		FilterDesc filterDesc;

		/** PCL outlier removal algortihm descriptiton, alignment */
		OutRemDesc::Seq outremAlignment;
		/** PCL outlier removal algortihm descriptiton, segmentation */
		OutRemDesc::Seq outremSegmentation;

		/** PCL downsampling algortihm descriptiton */
		DownsampleDesc downsampleAlignment;
		/** PCL downsampling algortihm descriptiton */
		DownsampleDesc downsampleSegmentation;

		/** PCL segmentation algortihm descriptiton */
		SegmentationDesc segmentation;

		/** PCL normal estimation algortihm descriptiton */
		NormalDesc normal;

		/** PCL curvature estimation algortihm descriptiton */
		CurvatureDesc curvature;

		/** PCL registration algortihm descriptiton, alignment */
		RegistrationDesc registrationAlignment;
		/** PCL registration algortihm descriptiton, segmentation */
		RegistrationDesc registrationSegmentation;

		/** Point cloud processing thread chunk size */
		golem::U32 threadChunkSize;

		/** Region in global coordinates */
		golem::Bounds::Desc::Seq regionDesc;
		/** Region colour solid */
		golem::RGBA regionColourSolid;
		/** Region colour wireframe */
		golem::RGBA regionColourWire;

		/** Constructs from description object */
		Desc() {
			Desc::setToDefault();
		}
		/** Sets the parameters to the default values */
		void setToDefault() {
			filterDesc.setToDefault();
			
			outremAlignment.clear();
			outremSegmentation.clear();
			
			downsampleAlignment.setToDefault();
			downsampleSegmentation.setToDefault();

			segmentation.setToDefault();
			
			normal.setToDefault();
			
			curvature.setToDefault();
			
			registrationAlignment.setToDefault();
			registrationSegmentation.setToDefault();

			threadChunkSize = 100;

			regionDesc.clear();
			regionColourSolid.set(golem::RGBA::GREEN._U8[0], golem::RGBA::GREEN._U8[1], golem::RGBA::GREEN._U8[2], golem::numeric_const<golem::U8>::MAX/8);
			regionColourWire.set(golem::RGBA::GREEN);
		}
		/** Assert that the object is valid. */
		void assertValid(const Assert::Context& ac) const {
			filterDesc.assertValid(Assert::Context(ac, "filterDesc."));

			for (OutRemDesc::Seq::const_iterator i = outremAlignment.begin(); i != outremAlignment.end(); ++i)
				i->assertValid(Assert::Context(ac, "outremAlignment[]."));
			for (OutRemDesc::Seq::const_iterator i = outremSegmentation.begin(); i != outremSegmentation.end(); ++i)
				i->assertValid(Assert::Context(ac, "outremSegmentation[]."));

			normal.assertValid(Assert::Context(ac, "normal."));
			curvature.assertValid(Assert::Context(ac, "curvature."));
			registrationAlignment.assertValid(Assert::Context(ac, "registrationAlignment."));
			registrationSegmentation.assertValid(Assert::Context(ac, "registrationSegmentation."));

			Assert::valid(threadChunkSize > 0, ac, "threadChunkSize: < 1");

			for (golem::Bounds::Desc::Seq::const_iterator i = regionDesc.begin(); i != regionDesc.end(); ++i)
				Assert::valid((*i)->isValid(), ac, "regionDesc[]: invalid");
		}
	};

	/** Nan/Inf removal */
	template <typename _Seq>  static void assertValid(const _Seq& seq) {
		if (seq.size() <= 0)
			throw golem::Message(golem::Message::LEVEL_ERROR, "Cloud::assertValid(): empty point cloud");
	};
	/** Nan/Inf removal */
	template <typename _Seq, typename _IsNan>  static void nanRem(golem::Context& context, _Seq& seq, _IsNan isNan) {
		const std::string seqStr = toString(seq);
		size_t size = 0;
		for (typename _Seq::const_iterator i = seq.begin(); i != seq.end(); ++i)
			if (!isNan(*i))
				seq[size++] = *i;
		resize(seq, size);
		context.debug("Cloud::nanRem(): (%s) --> (%s)\n", seqStr.c_str(), toString(seq).c_str());
		assertValid(seq);
	};
	
	/** Point copying */
	template <typename _Inp, typename _Out> static void copy(const _Inp& inp, _Out& out) {
		out.resize(inp.size());
		// copy header
		copyHeader(inp, out);
		// copy points
		for (size_t i = 0; i < out.size(); ++i)
			copyPoint(inp[i], out[i]);
	}

	/** Region clipping */
	template <typename _Seq, typename _IsNan> static void regionClip(const golem::Bounds::Seq& region, _Seq& seq, _IsNan isNan) {
		// Check initial conditions
		if (region.empty() || seq.empty())
			return;
		// clip point cloud
		for (typename _Seq::iterator k = seq.begin(); k != seq.end(); ++k)
			if (!isNan(*k) && !golem::Bounds::intersect(region.begin(), region.end(), getPoint<golem::Real>(*k)))
				setNanXYZ(*k);
	}
	/** Region clipping */
	template <typename _Seq> static void regionClip(golem::Context& context, const golem::Bounds::Seq& region, size_t threadChunkSize, _Seq& seq, bool silent = false) {
		// Check initial conditions
		if (region.empty())
			throw golem::Message(golem::Message::LEVEL_ERROR, "Cloud::regionClip(): Empty region");
		if (seq.empty())
			throw golem::Message(golem::Message::LEVEL_ERROR, "Cloud::regionClip(): No points to clip");
		// clip point cloud
		size_t i = 0, inpSize = 0, outSize = 0;
		golem::CriticalSection cs;
		ParallelsTask(context.getParallels(), [&] (ParallelsTask*) {
			size_t size = 0, inv = 0;
			for (size_t j;;) {
				{
					golem::CriticalSectionWrapper csw(cs);
					if (i*threadChunkSize > seq.size()) {
						inpSize += size;
						outSize += size - inv;
						break;
					}
					j = i++;
				}
				for (typename _Seq::iterator k = seq.begin() + j*threadChunkSize, end = seq.begin() + std::min((j + 1)*threadChunkSize, seq.size()); k != end; ++k)
					if (!isNanXYZ(*k)) {
						++size;
						if (!golem::Bounds::intersect(region.begin(), region.end(), getPoint<golem::Real>(*k))) {
							++inv;
							setNanXYZ(*k);
						}
					}
			}
		});
		if (!silent)
			context.debug("Cloud::regionClip(): Non-Nan cloud size (%u) --> (%u)\n", inpSize, outSize);
	}
	/** Region clipping */
	template <typename _Seq> static void regionClip(golem::Context& context, const golem::Bounds::Desc::Seq& regionDesc, size_t threadChunkSize, _Seq& seq, const golem::Mat34* trn = nullptr) {
		// region in global coordinates
		golem::Bounds::Seq region;
		for (golem::Bounds::Desc::Seq::const_iterator i = regionDesc.begin(); i != regionDesc.end(); ++i) {
			region.push_back((*i)->create());
			if (trn) region.back()->multiplyPose(*trn, region.back()->getPose());
		}
		// clip point cloud
		regionClip(context, region, threadChunkSize, seq);
	}
	
	/** Filtering */
	template <typename _Seq> static void filter(golem::Context& context, const FilterDesc& desc, size_t threadChunkSize, const _Seq& inp, PointSeq& out) {
		// check dimensions
		if (inp.size() <= 0)
			throw golem::Message(golem::Message::LEVEL_ERROR, "Cloud::filter(): no input point clouds");
		for (typename _Seq::const_iterator k = inp.begin(); k != inp.end(); ++k)
			if (inp.begin()->size() != k->size())
				throw golem::Message(golem::Message::LEVEL_ERROR, "Cloud::filter(): input point clouds sizes does not match");
		// resize
		if (out.size() != inp.begin()->size())
			out.resize(inp.begin()->size());
		out.width = inp.begin()->width;
		out.height = inp.begin()->height;
		// sensor origins
		typedef std::vector<pcl::PointXYZ> PointXYZSeq;
		PointXYZSeq originSeq;
		for (typename _Seq::const_iterator k = inp.begin(); k != inp.end(); ++k)
			originSeq.push_back(pcl::PointXYZ(k->sensor_origin_.x(), k->sensor_origin_.y(), k->sensor_origin_.z()));
		// run filter
		typedef std::vector<std::pair<size_t, float> > DepthRank;
		auto depthRankCmp = [] (const DepthRank::value_type& l, const DepthRank::value_type& r) -> bool { return l.first < r.first; };
		const size_t samples = std::min(size_t(desc.samples), inp.size());
		size_t i = 0;
		golem::CriticalSection cs;
		ParallelsTask(context.getParallels(), [&] (ParallelsTask*) {
			DepthRank depthRank;
			for (size_t l;;) {
				{
					golem::CriticalSectionWrapper csw(cs);
					if (i*threadChunkSize > out.size())
						break;
					l = i++;
				}
				for (size_t j = l*threadChunkSize, end = std::min((l + 1)*threadChunkSize, out.size()); j < end; ++j) {
					depthRank.clear();
					for (size_t k = 0; k < inp.size(); ++k) {
						const Point point = (*(inp.begin() + k))[j];
						if (isNanXYZ(point))
							continue;
						const pcl::PointXYZ origin = originSeq[k];
						const float d = golem::Math::sqr(point.x - origin.x) + golem::Math::sqr(point.y - origin.y) + golem::Math::sqr(point.z - origin.z);
						depthRank.push_back(std::make_pair(k, d));
					}
					if (depthRank.size() < desc.samples) {
						setNanXYZ(out[j]);
						continue;
					}
					const size_t element = depthRank.size()/2;
					std::nth_element(depthRank.begin(), depthRank.begin() + element + 1, depthRank.end(), depthRankCmp);
					out[j] = (*(inp.begin() + depthRank[element].first))[j];
				}
			}
		});
	}
	
	/** Outlier removal (RadiusOutlierRemoval) */
	static void outRemRad(golem::Context& context, const OutRemDesc& desc, const PointSeq& inp, PointSeq& out);
	/** Outlier removal (StatisticalOutlierRemoval) */
	static void outRemStat(golem::Context& context, const OutRemDesc& desc, const PointSeq& inp, PointSeq& out);
	/** Outlier removal */
	static void outRem(golem::Context& context, const OutRemDesc::Seq& descSeq, const PointSeq& inp, PointSeq& out);
	/** Downsampling on grid with surface manifold extraction */
	static void downsampleWithNormals(golem::Context& context, const DownsampleDesc& desc, const PointSeq& inp, PointSeq& out);
	/** Downsampling (VoxelGrid) */
	static void downsampleVoxelGrid(golem::Context& context, const DownsampleDesc& desc, const PointSeq& inp, PointSeq& out);
	/** Downsampling */
	static void downsample(golem::Context& context, const DownsampleDesc& desc, const PointSeq& inp, PointSeq& out);
	/** Subtracts two point clouds */
	static void segmentation(golem::Context& context, const SegmentationDesc& desc, const PointSeq& prev, const PointSeq& next, PointSeq& out);
	/** Estimates mormals of a given point cloud using PCA */
	static void normalPCA(golem::Context& context, const NormalDesc& desc, const PointSeq& inp, PointSeq& out);
	/** Estimates mormals of a given point cloud using integral images */
	static void normalII(golem::Context& context, const NormalDesc& desc, const PointSeq& inp, PointSeq& out);
	/** Estimates mormals of a given point cloud using moving least squares */
	static void normalMLS(golem::Context& context, const NormalDesc& desc, const PointSeq& inp, PointSeq& out);
	/** Estimates mormals of a given point cloud */
	static void normal(golem::Context& context, const NormalDesc& desc, const PointSeq& inp, PointSeq& out);
	/** IterativeClosestPointNonLinear */
	static void registrationIcpnl(golem::Context& context, const RegistrationDesc& desc, const PointSeq& prev, const PointSeq& next, PointSeq& out, golem::Mat34& trn);
	/** IterativeClosestPoint (RANSAC) */
	static void registrationIcp(golem::Context& context, const RegistrationDesc& desc, const PointSeq& prev, const PointSeq& next, PointSeq& out, golem::Mat34& trn);
	/** Aligns of a range of point clouds */
	static void registration(golem::Context& context, const RegistrationDesc& desc, const PointSeq& prev, const PointSeq& next, PointSeq& out, golem::Mat34& trn);
	
	/** Estimates curvature of a given point cloud */
	static void curvature(golem::Context& context, const CurvatureDesc& desc, PointCurvSeq& points);

	/** Raw point transform */
	static void transform(const golem::Mat34& trn, const PointSeq& inp, PointSeq& out);
	/** Point transform */
	static void transform(const golem::Mat34& trn, const PointCurvSeq& inp, PointCurvSeq& out);

	/** Relative transformation: ab*a = b => ab = b*a^-1 */
	static golem::Mat34 diff(const golem::Mat34& a, const golem::Mat34& b);

	/** Relative transformation in body frame of a: body(a, diff(a, b)) = a^-1*diff(a, b)*a = a^-1*b*a^-1*a = a^-1*b */
	static golem::Mat34 body(const golem::Mat34& a, const golem::Mat34& b);

	/** Aligns of a range of point clouds */
	template <typename _Ptr, typename _Ref, typename _Show> static void align(golem::Context& context, const Desc& desc, _Ptr begin, _Ptr end, PointSeq& out, _Ref ref, _Show show) {
		// nothing to align
		if (begin == end)
			return;

		// outlier removal
		outRem(context, desc.outremAlignment, ref(*begin), out);
		// find normals and curvature of the first cloud
		normal(context, desc.normal, out, out); // sets cameraFrame and label
		// remove NaNs
		//nanRem(context, out, isNanXYZNormal<Point>);

		// render
		show(*begin, out);

		// if there are at least two point clouds
		PointSeq current;
		// trn is a difference between actual and guess, initially identity
		golem::Mat34 trn = golem::Mat34::identity();
		for (_Ptr ptr = begin; ++ptr != end;) {
			// outlier removal
			outRem(context, desc.outremAlignment, ref(*ptr), current);
			// find normals and curvature
			normal(context, desc.normal, current, current);
			// remove NaNs
			//nanRem(context, current, isNanXYZNormal<Point>);

			// find transformation such that: out = trn*current, i.e. align current with out
			const golem::Mat34 guess = golem::Mat34::identity();
			trn = trn * guess; // account for a difference from previous iteration
			registration(context, desc.registrationAlignment, out, current, current, trn);
			trn = diff(trn, guess); // difference between actual and guess
			// sum up clouds
			out += current;
			
			// downsample
			downsample(context, desc.downsampleAlignment, out, out);

			// render
			show(*ptr, out);
		}

		// outlier removal
		outRem(context, desc.outremSegmentation, out, out);
		// downsample
		downsample(context, desc.downsampleSegmentation, out, out);

		// remove NaNs
		nanRem(context, out, isNanXYZNormal<Point>);
	}
};

/** Reads/writes object from/to a given XML context */
void XMLData(const std::string &attr, Cloud::Appearance::Mode& val, golem::XMLContext* context, bool create = false);
/** Reads/writes object from/to a given XML context */
void XMLData(Cloud::FilterDesc &val, golem::XMLContext* context, bool create = false);
/** Reads/writes object from/to a given XML context */
void XMLData(Cloud::OutRemDesc &val, golem::XMLContext* context, bool create = false);
/** Reads/writes object from/to a given XML context */
void XMLData(Cloud::DownsampleDesc &val, golem::XMLContext* context, bool create = false);
/** Reads/writes object from/to a given XML context */
void XMLData(Cloud::SegmentationDesc &val, golem::XMLContext* context, bool create = false);
/** Reads/writes object from/to a given XML context */
void XMLData(Cloud::NormalDesc &val, golem::XMLContext* context, bool create = false);
/** Reads/writes object from/to a given XML context */
void XMLData(Cloud::CurvatureDesc &val, golem::XMLContext* context, bool create = false);
/** Reads/writes object from/to a given XML context */
void XMLData(Cloud::RegistrationDesc &val, golem::XMLContext* context, bool create = false);
/** Reads/writes object from/to a given XML context */
void XMLData(Cloud::Desc &val, golem::XMLContext* context, bool create = false);

//------------------------------------------------------------------------------

};	// namespace

POINT_CLOUD_REGISTER_POINT_STRUCT(
	grasp::Cloud::PointCurv,
	(float, x, x)(float, y, y)(float, z, z)(float, rgb, rgb)(float, normal_x, normal_x)(float, normal_y, normal_y)(float, normal_z, normal_z)(float, curvature, curvature)
	(float, principal_curvature_x, principal_curvature_x)(float, principal_curvature_y, principal_curvature_y)(float, principal_curvature_z, principal_curvature_z)(float, pc1, pc1)(float, pc2, pc2)
)

//------------------------------------------------------------------------------


#endif /*_GRASP_CORE_CLOUD_H_*/
