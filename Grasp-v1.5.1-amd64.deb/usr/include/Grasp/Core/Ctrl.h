/** @file Ctrl.h
 * 
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_CORE_CTRL_H_
#define _GRASP_CORE_CTRL_H_

//------------------------------------------------------------------------------

#include <Grasp/Core/Defs.h>
#include <Golem/Plan/Planner.h>
#include <Golem/UI/Renderer.h>
#include <Golem/Tools/Stream.h>

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** Find controller leaf from a given id */
golem::Controller* findController(golem::Controller &controller, const std::string& id);
/** Sequentially find controller leafs from given ids */
void findController(golem::Controller &controller, const StringSeq& idSeq, golem::Controller::PtrSeq& controllerSeq);

//------------------------------------------------------------------------------

/** General planner debug info */
std::string plannerDebug(const golem::Planner& planner);
/** Configspace coordinate planner debug info */
std::string plannerConfigspaceDebug(const golem::Planner& planner, const golem::ConfigspaceCoord* c = nullptr);
/** Workspace coordinate planner debug info */
std::string plannerWorkspaceDebug(const golem::Planner& planner, const golem::WorkspaceChainCoord* w = nullptr);

//------------------------------------------------------------------------------

/** Waypoint */
class Waypoint {
public:
	/** Trajectory */
	typedef std::vector<Waypoint> Seq;

	/** Current state */
	golem::Controller::State state;
	/** Current command */
	golem::Controller::State command;

	/** From state and command */
	Waypoint(const golem::Controller::State& state, const golem::Controller::State& command);

	/** Empty waypoint */
	static Waypoint create(const golem::Controller& controller);
	/** Waypoint at time t */
	static Waypoint lookup(const golem::Controller& controller, golem::SecTmReal t = golem::SEC_TM_REAL_MAX);

	/** Make commands or states */
	static golem::Controller::State::Seq make(const Waypoint::Seq& waypoints, bool command = false);
	/** Make commands or states */
	static grasp::Waypoint::Seq make(const golem::Controller::State::Seq& states, const golem::Controller::State::Seq& commands);

protected:
	/** Creates blank waypoint, requires controller */
	Waypoint(const golem::Controller& controller);
};

//------------------------------------------------------------------------------

/** Collision detection */
class CollisionBounds : public golem::Planner::CallbackDataSync {
public:
	typedef golem::shared_ptr<CollisionBounds> Ptr;

	template <typename _Points> CollisionBounds(golem::Planner& planner, _Points points, golem::DebugRenderer* renderer = nullptr, golem::CriticalSection* cs = nullptr, const golem::RGBA& colourSolid = golem::RGBA(0, 0, 255, 64), const golem::RGBA& colourWire = golem::RGBA(0, 0, 255, 255)) :
		planner(planner), pCallback(planner.getCallbackDataSync()), renderer(renderer), cs(cs), colourSolid(colourSolid), colourWire(colourWire), local(false)
	{
		setCollisionBounds(points);
		draw();
	}
	template <typename _Points> void setCollisionBounds(_Points points) {
		// collision bounds
		golem::BoundingBox::Desc boundingBoxDesc;
		getBoundingBox(points, boundingBoxDesc.pose, boundingBoxDesc.dimensions);
		pBounds = boundingBoxDesc.create();
		if (pBounds == nullptr)
			throw golem::Message(golem::Message::LEVEL_ERROR, "CollisionBounds::setCollisionBounds(): unable to create collision bounds");
		// install callback
		planner.setCallbackDataSync(this);
	};

	/** golem::Planner::CallbackDataSync */
	virtual void syncCollisionBounds();
	/** golem::Planner::CallbackDataSync */
	virtual void syncFindTrajectory(golem::Controller::Trajectory::const_iterator begin, golem::Controller::Trajectory::const_iterator end, const golem::GenWorkspaceChainState* wend = NULL);
	
	bool collides(const golem::ConfigspaceCoord& c, golem::Configspace::Index joint);

	void setLocal(bool local = true);

	/** uninstall callback and reset rendering */
	virtual ~CollisionBounds();

protected:
	golem::Planner& planner;
	golem::Planner::CallbackDataSync* pCallback;
	golem::Bounds::Ptr pBounds;

	golem::DebugRenderer* renderer;
	golem::CriticalSection* cs;
	golem::RGBA colourSolid, colourWire;

	bool local;

	/** Draw bounds */
	void draw(const golem::Heuristic::BoundsSet* boundsSet = nullptr, const golem::Mat34* frame = nullptr);

	/** Point cloud bounding box */
	template <typename _Points> static void getBoundingBox(_Points points, golem::Mat34& frame, golem::Vec3& dimensions) {
		golem::Vec3 min(golem::REAL_MAX), max(-golem::REAL_MAX), v[3];
		for (size_t j = 0; j < 3; ++j) {
			v[j].setZero();
			v[j][j] = golem::REAL_ONE;
			((const golem::Mat33&)frame.R).multiply(v[j], v[j]);
		}
		golem::Vec3 point;
		for (size_t i = 0; points(i, point); ++i) {
			for (size_t j = 0; j < 3; ++j) {
				const golem::Real proj = point.dot(v[j]);
				min[j] = std::min(min[j], proj);
				max[j] = std::max(max[j], proj);
			}
		}
		for (size_t j = 0; j < 3; ++j) {
			dimensions[j] = golem::REAL_HALF*(max[j] - min[j]);
			frame.p[j] = min[j] + dimensions[j];
		}
		frame.R.multiplyByTranspose(frame.p, frame.p);
	}
};

//------------------------------------------------------------------------------

};	// namespace grasp

//------------------------------------------------------------------------------

namespace golem {
	template <> void Stream::read(Controller::State& state) const;
	template <> void Stream::write(const Controller::State& state);

	template <> void Stream::read(grasp::Waypoint& waypoint) const;
	template <> void Stream::write(const grasp::Waypoint& waypoint);
};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_CORE_CTRL_H_*/
