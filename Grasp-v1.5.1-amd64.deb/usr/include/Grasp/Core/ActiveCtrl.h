/** @file ActiveCtrl.h
 * 
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_CORE_ACTIVECTRL_H_
#define _GRASP_CORE_ACTIVECTRL_H_

//------------------------------------------------------------------------------

#include <Grasp/Core/Library.h>
#include <Grasp/Core/Sensor.h>
#include <Grasp/Core/Ctrl.h>

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** Active interface */
class Active {
public:
	/** Activate/deactivate */
	virtual void setActive(bool active = true) {
		this->active = active;
	}
	/** Is active */
	virtual bool isActive() const {
		return active;
	}

	/** Reset */
	Active(bool active = false) : active(active) {}

private:
	/** Active flag */
	bool active;
};

//------------------------------------------------------------------------------

/** ActiveCtrl interface */
class ActiveCtrl : public Active, public Library {
public:
	typedef golem::shared_ptr<ActiveCtrl> Ptr;
	typedef std::map<std::string, Ptr> Map;
	typedef std::vector<Ptr> Seq;

	/** ActiveCtrl description */
	class Desc : public Library::Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;

		/** (Optional) required controller leafs ids in the controller tree */
		StringSeq controllerIDSeq;
		/** (Optional) required sensors ids */
		StringSeq sensorIDSeq;

		/** Start as active */
		bool active;

		/** Constructs description. */
		Desc() {
			setToDefault();
		}
		
		/** Sets the parameters to the default values. */
		void setToDefault() {
			Library::Desc::setToDefault();

			libraryPrefix = "Grasp";
			libraryName = "grasp activectrl";

			controllerIDSeq.clear();
			sensorIDSeq.clear();

			active = true;
		}

		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			Library::Desc::assertValid(ac);
		}

		/** Load descritpion from xml context. */
		virtual void load(golem::Context& context, const golem::XMLContext* xmlcontext);

		/** Creates the object from the description. */
		virtual ActiveCtrl::Ptr create(golem::Planner &planner, const Sensor::Map& sensors) const = 0;
	};

	/** Planner reference */
	golem::Planner& getPlanner() {
		return planner;
	}
	/** Planner reference */
	const golem::Planner& getPlanner() const {
		return planner;
	}

	/** Controller reference */
	golem::Controller& getController() {
		return controller;
	}
	/** Controller reference */
	const golem::Controller& getController() const {
		return controller;
	}

	/** Sensors reference */
	const Sensor::Map& getSensors() const {
		return sensors;
	}

	/** Used controller leafs in the controller tree */
	const golem::Controller::PtrSeq& getControllerSeq() const {
		return controllerSeq;
	}
	/** Used sensors */
	const Sensor::Seq& getSensorSeq() const {
		return sensorSeq;
	}

protected:
	/** Planner reference */
	golem::Planner &planner;
	/** Controller reference */
	golem::Controller &controller;
	/** Sensors reference */
	const Sensor::Map& sensors;

	/** Controller state info */
	golem::Controller::State::Info info;

	/** Used controller leafs in the controller tree */
	golem::Controller::PtrSeq controllerSeq;
	/** Used sensors */
	Sensor::Seq sensorSeq;

	/** Creates/initialises the ActiveCtrl */
	void create(const Desc& desc);
	
	/** Constructs the ActiveCtrl */
	ActiveCtrl(golem::Planner &planner, const Sensor::Map& sensors);
};

//------------------------------------------------------------------------------

};	// namespace grasp

#endif /*_GRASP_CORE_ACTIVECTRL_H_*/
