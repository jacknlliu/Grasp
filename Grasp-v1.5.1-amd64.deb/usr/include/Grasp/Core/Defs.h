/** @file Defs.h
 * 
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */
 
#pragma once
#ifndef _GRASP_CORE_DEFS_H_
#define _GRASP_CORE_DEFS_H_

//------------------------------------------------------------------------------

#include <Golem/Math/Twist.h>
#include <Golem/Sys/Thread.h>
#include <Golem/Tools/Message.h>
#include <Golem/Tools/Parallels.h>
#include <Golem/UI/UI.h>
#include <vector>
#include <map>
#include <set>
#include <functional>
#include <stdexcept>

//------------------------------------------------------------------------------

namespace golem {
	class Context;
	class XMLContext;
	class MsgXMLParser;
	template <typename SEQ> void XMLDataSeq(SEQ &seq, const char* attr, XMLContext* context, bool create, const typename SEQ::value_type& dflt);
};

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

typedef std::vector<bool> BoolSeq;
typedef std::vector<int> IntSeq;
typedef std::vector<golem::U8> U8Seq;
typedef std::vector<golem::I32> I32Seq;
typedef std::vector<golem::U32> U32Seq;
typedef std::vector<golem::Real> RealSeq;
typedef std::vector<golem::Vec3> Vec3Seq;
typedef std::vector<golem::Mat34> Mat34Seq;
typedef std::vector<golem::Twist> TwistSeq;
typedef std::vector<std::string> StringSeq;

typedef std::set<std::string> StringSet;

typedef std::map<std::string, golem::Mat34> Mat34Map;

typedef std::function<void()> Function;

//------------------------------------------------------------------------------

/** Assert */
class Assert {
public:
	/** Context */
	class Context {
	public:
		friend class Assert;

		/** Creates linked list of messages */ 
		explicit inline Context(const char* info) : context(nullptr), info(info) {}
		/** Creates linked list of messages */ 
		explicit inline Context(const Context& context, const char* info) : context(&context), info(info) {}

	private:
		const Context *context;
		const char *info;
	};

	/** Throw an exception is expression=false */
	static void valid(bool expression, const char* format, ...);
	/** Throw an exception is expression=false */
	static void valid(bool expression, const Context& context, const char* format, ...);
};

//------------------------------------------------------------------------------

/** Dynamic casting _Inp to _Out */
template <typename _Out, typename _Inp> inline _Out* is(_Inp* inp) {
	return dynamic_cast<_Out*>(inp);
}
/** Dynamic casting _Inp to _Out */
template <typename _Out, typename _Inp> inline const _Out* is(const _Inp* inp) {
	return dynamic_cast<const _Out*>(inp);
}
/** Dynamic casting _Inp to _Out (reference argument assumes map<whatever, pointer>) */
template <typename _Out, typename _Inp> inline _Out* is(_Inp& inp) {
	return dynamic_cast<_Out*>(&*inp->second);
}
/** Dynamic casting _Inp to _Out (reference argument assumes map<whatever, pointer>) */
template <typename _Out, typename _Inp> inline const _Out* is(const _Inp& inp) {
	return dynamic_cast<const _Out*>(&*inp->second);
}

/** Static casting _Inp to _Out (assumes _Out is derived from _Inp) */
template <typename _Out, typename _Inp> inline _Out* to(_Inp* inp) {
	return static_cast<_Out*>(inp);
}
/** Static casting _Inp to _Out (assumes _Out is derived from _Inp) */
template <typename _Out, typename _Inp> inline const _Out* to(const _Inp* inp) {
	return static_cast<const _Out*>(inp);
}
/** Static casting (assumes _Type::Ptr is defined) */
template <typename _Type> inline _Type* to(const typename _Type::Ptr& inp) {
	return static_cast<_Type*>(inp.get());
}
/** Static casting (assumes _Type::Map is defined) */
template <typename _Type> inline _Type* to(typename _Type::Map::iterator& inp) {
	return static_cast<_Type*>(&*inp->second);
}
/** Static casting (assumes _Type::Map is defined) */
template <typename _Type> inline _Type* to(const typename _Type::Map::const_iterator& inp) {
	return static_cast<_Type*>(&*inp->second);
}

//------------------------------------------------------------------------------

class ScopeGuard {
public:
	typedef golem::shared_ptr<ScopeGuard> Ptr;
	/** Guard function */
	typedef grasp::Function Function;

	ScopeGuard(Function function) : function(function) {
	}
	~ScopeGuard() {
		function();
	}

private:
	Function function;
};

//------------------------------------------------------------------------------

/** golem::Thread helper class */
class ThreadTask : protected golem::Runnable {
public:
	typedef golem::shared_ptr<ThreadTask> Ptr;
	/** Task function */
	typedef grasp::Function Function;

	/** Task construction */
	ThreadTask(Function function = nullptr, golem::Thread::Priority priority = golem::Thread::NORMAL, golem::MSecTmU32 timeOut = golem::MSEC_TM_U32_INF) : timeOut(timeOut), function(function), terminate(false) {
		if (!thread.start(this))
			throw golem::Message(golem::Message::LEVEL_CRIT, "ThreadTask::ThreadTask(): Unable to start thread");
		(void)thread.setPriority(priority); // ignore retval
	}
	~ThreadTask() {
		terminate = true;
		ev.set(true);
		(void)thread.join(timeOut); // ignore retval
	}
	/** Set new thread task */
	void start(Function function = nullptr) {
		if (function)
			this->function = function; // atomic
		ev.set(true);
	}

protected:
	/** Thread */
	golem::Thread thread;
	/** New task */
	golem::Event ev;
	/** Time to stop */
	golem::MSecTmU32 timeOut;
	/** Stop condition variable */
	bool terminate;
	/** Task function */
	Function function;

	/** Runnable: thread function */
	virtual void run() {
		for (;;) {
			if (!ev.wait(timeOut))
				continue;
			ev.set(false);
			if (terminate)
				break;
			const Function function = this->function; // atomic
			if (function)
				function();
		}
	}
};

//------------------------------------------------------------------------------

/** golem::Parallels helper class */
class ParallelsTask : protected golem::Runnable {
public:
	typedef golem::shared_ptr<ParallelsTask> Ptr;
	/** Task function */
	typedef std::function<void(ParallelsTask*)> Function;

	/** Task construction */
	ParallelsTask(golem::Parallels* parallels, Function function, golem::Thread::Priority priority = golem::Thread::LOWEST, golem::MSecTmU32 timeOut = golem::MSEC_TM_U32_INF) : function(function), stopping(false) {
		// setup Parallels
		if (parallels == nullptr)
			throw golem::Message(golem::Message::LEVEL_CRIT, "ParallelsTask::ParallelsTask(): Parallels required");
		// launch Parallels
		for (size_t t = (size_t)parallels->getNumOfThreads(); t > 0; --t) {
			golem::Job* job = parallels->startJob(this);
			if (!job)
				throw golem::Message(golem::Message::LEVEL_CRIT, "ParallelsTask::ParallelsTask(): Unable to start job");
			job->setThreadPriority(priority); // ignore retval
		}
		// wait for completion or stop now
		if (!parallels->joinJobs(timeOut)) {
			stopping = true;
			(void)parallels->joinJobs(golem::MSEC_TM_U32_INF); // ignore retval
		}
	}
	/** Stop condition */
	bool stop() const {
		return stopping;
	}

protected:
	/** Stop condition variable */
	bool stopping;
	/** Task function */
	Function function;

	/** Runnable: parallels thread function */
	virtual void run() {
		function(this);
	}
};

//------------------------------------------------------------------------------

/** Configuration and 3D pose/frame */
template <typename _Pose> class ConfigPose {
public:
	typedef std::vector<ConfigPose> Seq;
	typedef std::multimap<std::string, ConfigPose> Map;
	typedef std::pair<typename Map::const_iterator, typename Map::const_iterator> Range;

	/** Configuration */
	RealSeq c;
	/** Frame */
	_Pose w;

	/** Set all to default values */
	ConfigPose() {
		c.clear();
		w.setId();
	}
	ConfigPose(const RealSeq& c) : c(c) {
		w.setId();
	}
	ConfigPose(const _Pose& w) : w(w) {
		c.clear();
	}
	ConfigPose(const RealSeq& c, const _Pose& w) : c(c), w(w) {
	}

	/** Set to id transformations and reset cpos */
	void setToDefault() {
		c.clear();
		w.setId();
	}
	/** Assert that the description is valid. */
	void assertValid(const Assert::Context& ac) const {
		for (RealSeq::const_iterator i = c.begin(); i != c.end(); ++i)
			Assert::valid(golem::Math::isFinite(*i), ac, "c[]: infinite");
		Assert::valid(w.isValid(), ac, "w: invalid");
	}

	/** Reads/writes object from/to a given XML context */
	void xmlData(golem::XMLContext* context, bool create = false) const {
		if (!create)
			const_cast<ConfigPose*>(this)->setToDefault();

		golem::XMLDataSeq(const_cast<RealSeq&>(c), "c", context, create, golem::REAL_ZERO);
		try {
			XMLData(const_cast<_Pose&>(w), context, create);
		}
		catch (const golem::MsgXMLParser&) {
			if (create) throw;
		}
	}
};

typedef grasp::ConfigPose<golem::Mat34> ConfigMat34;

/** Reads/writes object from/to a given XML context */
void XMLData(ConfigMat34 &val, golem::XMLContext* xmlcontext, bool create = false);
/** Reads/writes object from/to a given XML context */
void XMLData(ConfigMat34::Map::value_type &val, golem::XMLContext* xmlcontext, bool create = false);

//------------------------------------------------------------------------------

/** Formats a string */
std::string makeString(const char* format, ...);

/** Extracts directory */
std::string getDir(const std::string& path);

/** Extracts name */
std::string getName(const std::string& path);

/** Extracts extension */
std::string getExt(const std::string& path);

/** Compares extension */
bool isExt(const std::string& path, const std::string& ext);

//------------------------------------------------------------------------------

/** Data time stamp. */
class TimeStamp {
public:
	typedef std::vector<TimeStamp> Seq;

	/** Time stamp */
	golem::SecTmReal timeStamp;

	/** Default initialisation */
	TimeStamp(golem::SecTmReal timeStamp = golem::SEC_TM_REAL_ZERO) : timeStamp(timeStamp) {}

	/** Set time stamp */
	void set(const TimeStamp& timeStamp) {
		this->timeStamp = timeStamp.timeStamp;
	}
	/** Set time stamp */
	void get(TimeStamp& timeStamp) const {
		timeStamp.timeStamp = this->timeStamp;
	}

	/** Reads/writes object from/to a given XML context */
	void xmlData(golem::XMLContext* context, bool create = false) const;
};

//------------------------------------------------------------------------------

/** Exception: program exit */
class Exit {};

/** Exception: cancel operation */
struct Cancel : public std::runtime_error { Cancel(const char* reason) : std::runtime_error(reason) {} };

//------------------------------------------------------------------------------

};	// namespace

//------------------------------------------------------------------------------

namespace golem {

/** Reads/writes object from/to a given XML context */
void XMLData(grasp::Mat34Map::value_type& val, golem::XMLContext* context, bool create = false);

};	// namespace

//------------------------------------------------------------------------------

/** Object creating function from the description. */
#define GRASP_CREATE_FROM_OBJECT_DESC1(OBJECT, POINTER, PARAMETER) virtual POINTER create(PARAMETER parameter) const {\
	OBJECT *pObject = new OBJECT(parameter);\
	POINTER pointer(pObject);\
	pObject->create(*this);\
	return pointer;\
}

/** Object creating function from the description. */
#define GRASP_CREATE_FROM_OBJECT_DESC2(OBJECT, POINTER, PARAMETER1, PARAMETER2) virtual POINTER create(PARAMETER1 parameter1, PARAMETER2 parameter2) const {\
	OBJECT *pObject = new OBJECT(parameter1, parameter2);\
	POINTER pointer(pObject);\
	pObject->create(*this);\
	return pointer;\
}

//------------------------------------------------------------------------------

#endif /*_GRASP_CORE_DEFS_H_*/
