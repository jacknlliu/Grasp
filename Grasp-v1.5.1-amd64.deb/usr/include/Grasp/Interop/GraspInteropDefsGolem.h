/** @file GraspInteropDefsGolem.h
 * 
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_GRASP_INTEROP_GRASP_INTEROP_DEFS_GOLEM_H_ // if #pragma once is not supported
#define _GRASP_GRASP_INTEROP_GRASP_INTEROP_DEFS_GOLEM_H_

#include "GraspInteropDefs.h"
#include <Golem/Ctrl/Controller.h>
#include <Grasp/Core/RB.h>
#include <Grasp/Contact/Manipulator.h>
#include <Grasp/Contact/Data.h>

//------------------------------------------------------------------------------

/** Grasp name space */
namespace grasp {
/** Grasp interoperability name space */
namespace interop {
	template <typename _SrcType, size_t _SrcSize, typename _DstType, size_t _DstSize> void convert(const golem::_VecN<_SrcType, _SrcSize>& src, interop::Vec<_DstType, _DstSize>& dst, std::uint32_t& size) {
		//Assert::valid(_SrcSize == _DstSize, "interop::convert(): VecN dimensions mismatch");
		copy(src.v, src.v + _DstSize, dst.v);
		size = (std::uint32_t)src.size();
	}
	template <typename _SrcType, size_t _SrcSize, typename _DstType, size_t _DstSize> void convert(const interop::Vec<_SrcType, _SrcSize>& src, const std::uint32_t& size, golem::_VecN<_DstType, _DstSize>& dst) {
		//Assert::valid(_SrcSize == _DstSize, "interop::convert(): VecN dimensions mismatch");
		dst.resize((size_t)size);
		copy(src.v, src.v + _DstSize, dst.v);
	}

	template <> inline void convert(const golem::Vec3& src, interop::Vec3& dst) {
		src.getColumn3(dst.v);
	}
	template <> inline void convert(const interop::Vec3& src, golem::Vec3& dst) {
		dst.setColumn3(src.v);
	}
	template <typename _Src, typename _Dst> inline void convertQuat(const _Src& src, _Dst& dst) {
		convert(src.x, dst.x); convert(src.y, dst.y); convert(src.z, dst.z); convert(src.w, dst.w);
	}
	template <> inline void convert(const golem::Quat& src, interop::Quat& dst) {
		convertQuat(src, dst);
	}
	template <> inline void convert(const interop::Quat& src, golem::Quat& dst) {
		convertQuat(src, dst);
	}
	template <typename _Src, typename _Dst> inline void convertMat33(const _Src& src, _Dst& dst) {
		convert(src.m11, dst.m11); convert(src.m12, dst.m12); convert(src.m13, dst.m13);
		convert(src.m21, dst.m21); convert(src.m22, dst.m22); convert(src.m23, dst.m23);
		convert(src.m31, dst.m31); convert(src.m32, dst.m32); convert(src.m33, dst.m33);
	}
	template <> inline void convert(const golem::Mat34& src, interop::Mat34& dst) {
		convert(src.p, dst.p);
		convertMat33(src.R, dst.R);
	}
	template <> inline void convert(const interop::Mat34& src, golem::Mat34& dst) {
		convert(src.p, dst.p);
		convertMat33(src.R, dst.R);
	}
	template <typename _Src, typename _Dst> inline void convertDist(const _Src& src, _Dst& dst) {
		convert(src.lin, dst.lin); convert(src.ang, dst.ang);
	}
	template <> inline void convert(const grasp::RBDist& src, interop::Dist& dst) {
		convertDist(src, dst);
	}
	template <> inline void convert(const interop::Dist& src, grasp::RBDist& dst) {
		convertDist(src, dst);
	}
	template <typename _Src, typename _Dst> inline void convertFrame3D(const _Src& src, _Dst& dst) {
		convert(src.p, dst.p);
		convert(src.q, dst.q);
	}
	template <> inline void convert(const grasp::RBCoord& src, interop::Frame3D& dst) {
		convertFrame3D(src, dst);
	}
	template <> inline void convert(const interop::Frame3D& src, grasp::RBCoord& dst) {
		convertFrame3D(src, dst);
	}

	inline void convert(const golem::ConfigspaceCoord& src, interop::ConfigspaceCoord& dst) {
		//Assert::valid((size_t)golem::Configspace::DIM == (size_t)interop::ConfigspaceCoord::SIZE, "interop::convert(): Configspace dimensions mismatch");
		copy(src.data(), src.data() + golem::Configspace::DIM, dst.v);
	}
	inline void convert(const interop::ConfigspaceCoord& src, golem::ConfigspaceCoord& dst) {
		//Assert::valid((size_t)golem::Configspace::DIM == (size_t)interop::ConfigspaceCoord::SIZE, "interop::convert(): Configspace dimensions mismatch");
		copy(src.v, src.v + interop::ConfigspaceCoord::SIZE, dst.data());
	}

	inline void convert(const golem::WorkspaceChainCoord& src, interop::WorkspaceCoord& dst) {
		//Assert::valid((size_t)golem::Chainspace::DIM == (size_t)interop::WorkspaceCoord::SIZE, "interop::convert(): Chainspace dimensions mismatch");
		copy(src.data(), src.data() + golem::Chainspace::DIM, dst.v);
	}
	inline void convert(const interop::WorkspaceCoord& src, golem::WorkspaceChainCoord& dst) {
		//Assert::valid((size_t)golem::Chainspace::DIM == (size_t)interop::WorkspaceCoord::SIZE, "interop::convert(): Chainspace dimensions mismatch");
		copy(src.v, src.v + interop::WorkspaceCoord::SIZE, dst.data());
	}

	inline void convert(const golem::Controller::State& src, interop::Config& dst) {
		convert(src.t, dst.t);
		convert(src.cpos, dst.cpos);
		convert(src.cvel, dst.cvel);
	}
	inline void convert(const interop::Config& src, golem::Controller::State& dst) {
		convert(src.t, dst.t);
		convert(src.cpos, dst.cpos);
		convert(src.cvel, dst.cvel);
	}

	template <typename _Real> inline void convert(const golem::Sample<_Real>& src, interop::Sample& dst) {
		convert(src.weight, dst.weight);
	}
	template <typename _Real> inline void convert(const interop::Sample& src, golem::Sample<_Real>& dst) {
		dst.setToDefault();
		convert(src.weight, dst.weight);
	}

}; // namespace interop
}; // namespace grasp

//------------------------------------------------------------------------------

#endif // _GRASP_GRASP_INTEROP_GRASP_INTEROP_DEFS_GOLEM_H_