/** @file TinyPCL.h
 * 
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_TINY_TINYPCL_H_ // if #pragma once is not supported
#define _GRASP_TINY_TINYPCL_H_

#include "GraspInteropDefsPCL.h"
#include <Grasp/Tiny/Tiny.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>

//------------------------------------------------------------------------------

/** Grasp name space */
namespace grasp {
/** Grasp interoperability name space */
namespace interop {
	/** pcl::PrincipalCurvatures point conversion */
	inline void convert(const pcl::PrincipalCurvatures& src, tiny::Feature& dst) {
		dst.v[0] = convertPCLFloat<float_t>(src.principal_curvature[0]);
		dst.v[1] = convertPCLFloat<float_t>(src.principal_curvature[1]);
		dst.v[2] = convertPCLFloat<float_t>(src.principal_curvature[2]);
		dst.v[3] = convertPCLFloat<float_t>(src.pc1);
		dst.v[4] = convertPCLFloat<float_t>(src.pc2);
	}
	/** pcl::PrincipalCurvatures point conversion */
	inline void convert(const tiny::Feature& src, pcl::PrincipalCurvatures& dst) {
		dst.principal_curvature[0] = convertPCLFloat<float>(src.v[0]);
		dst.principal_curvature[1] = convertPCLFloat<float>(src.v[1]);
		dst.principal_curvature[2] = convertPCLFloat<float>(src.v[2]);
		dst.pc1 = convertPCLFloat<float>(src.v[3]);
		dst.pc2 = convertPCLFloat<float>(src.v[4]);
	}

	/** pcl::PointXYZRGBNormal and pcl::PrincipalCurvatures point conversion */
	template <typename _PointXYZRGBNormalPrincipalCurvatures> void convert(const _PointXYZRGBNormalPrincipalCurvatures& src, tiny::Feature3D& dst) {
		convert(static_cast<const pcl::PointXYZRGBNormal&>(src), static_cast<interop::Point3D&>(dst));
		convert(static_cast<const pcl::PrincipalCurvatures&>(src), dst.feature);
		//dst.featureSize = 2;
	}
	/** pcl::PointXYZRGBNormal point conversion */
	template <typename _PointXYZRGBNormalPrincipalCurvatures> void convert(const tiny::Feature3D& src, _PointXYZRGBNormalPrincipalCurvatures& dst) {
		convert(static_cast<const interop::Point3D&>(src), static_cast<pcl::PointXYZRGBNormal&>(dst));
		convert(src.feature, static_cast<pcl::PrincipalCurvatures&>(dst));
	}

}; // namespace interop
}; // namespace grasp

//------------------------------------------------------------------------------

#endif // _GRASP_TINY_TINYPCL_H_