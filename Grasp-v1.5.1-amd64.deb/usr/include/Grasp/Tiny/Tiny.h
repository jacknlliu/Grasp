/** @file Tiny.h
 * 
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_TINY_TINY_H_ // if #pragma once is not supported
#define _GRASP_TINY_TINY_H_

//------------------------------------------------------------------------------

#include "GraspInteropDefs.h"

//------------------------------------------------------------------------------

/** Grasp name space */
namespace grasp {
/** Grasp interoperability name space */
namespace interop {
/** Grasp Tiny name space */
namespace tiny {

	/** Memory buffer */
	typedef std::vector<std::uint8_t> Buffer;

	/*************************************************************************
	*
	* Tiny interface container
	*
	**************************************************************************/

	/** Tiny interface container controls life time of the encapsulated interfaces */
	class Tiny {
	public:
		/** Pointer  */
		typedef std::shared_ptr<Tiny> Ptr;

		/** Creates container
		*	@param[in]	configPath		configuration file path
		*	@return						Tiny interface container
		*/
		static Ptr create(const std::string& configPath);

		/** Current time counted from an arbitrary moment
		*	@return						current time [sec]
		*/
		virtual double time() const = 0;

		/** Run menu once
		*	@return						<FALSE> exit, <TRUE> otherwise
		*/
		virtual bool menu() = 0;
	};

	/*************************************************************************
	*
	* Sensor interface and data structures
	*
	**************************************************************************/

	/** Visual feature type, max dim = Feature::SIZE */
	typedef Vec<float_t, 12> Feature;

	/** 3D point with feature vector and weight. */
	class Feature3D : public Point3D, public Sample {
	public:
		/** Sequence */
		typedef std::vector<Feature3D> Seq;

		/** Feature size. */
		//std::uint32_t featureSize;
		/** Feature vector */
		Feature feature;

		/** Default constructor sets the default values. */
		Feature3D() {
			clear();
		}
		/** Set to the default values. */
		void clear() {
			Point3D::clear();
			Sample::clear();
			//featureSize = 0;
			feature.clear();
		}
	};

	/** Sensor interface */
	class Sensor {
	public:
		/** Capture point cloud
		*	@param[out]	cloud			captured point cloud
		*/
		virtual void capture(Point3DCloud& cloud) = 0;

		/** Process a sequence of point clouds
		*	@param[in]	inp				point cloud sequence to be processed
		*	@param[out]	out				set of features
		*/
		virtual void process(const Point3DCloud::Seq& inp, Feature3D::Seq& out) = 0;

		/** Sensor interface access
		*	@param[in]	tiny			Tiny container
		*	@return						Sensor interface
		*/
		static Sensor* get(Tiny& tiny);
		static const Sensor* get(const Tiny& tiny);
	};

	/*************************************************************************
	*
	* Control interface and data structures
	*
	**************************************************************************/

	/** Control and planning interface */
	class Control {
	public:
		/** Robot control cycle duration
		*	@return						cycle duration [sec]
		*/
		virtual double cycleDuration() const = 0;

		/**	State of a robot at time t
		*	@param[in]	t				query time [sec]
		*	@param[out]	state			robot state
		*/
		virtual void lookupState(double t, Config& state) const = 0;

		/**	Robot control (position)
		*	@param[in]	command			command sequence begin
		*	@param[in]	size			number of commands in the sequence
		*/
		virtual void sendCommand(const Config* command, std::uintptr_t size = 1) = 0;

		/**	Wait for begin of the robot control cycle
		*	@param[in]	timewait		maximum time wait [sec]
		*	@return						true if success, false otherwise
		*/
		virtual bool waitForCycleBegin(double timewait = std::numeric_limits<double>::max()) = 0;

		/**	Wait for end of the robot trajectory execution
		*	@param[in]	timewait		maximum time wait [sec]
		*	@return						true if success, false otherwise
		*/
		virtual bool waitForTrajectoryEnd(double timewait = std::numeric_limits<double>::max()) = 0;

		/** Finds (optimal) trajectory target in the obstacle-free configuration space.
		* @param[in]	cbegin			trajectory begin in the configuration space
		* @param[in]	wend			query trajectory end (target) in the workspace
		* @param[out]	cend			computed trajectory end (target) in the configuration space
		* @param[out]	werr			workspace error per kinematic chain
		*/
		virtual void findTarget(const ConfigspaceCoord &cbegin, const WorkspaceCoord& wend, ConfigspaceCoord &cend, WorkspaceDist& werr) = 0;

		/** Finds obstacle-free trajectory in the configuration space from begin to end.
		* @param[in]	cbegin			trajectory begin in the configuration space
		* @param[in]	cend			trajectory end in the configuration space
		* @param[out]	ctrajectory		output trajectory in the configuration space
		*/
		virtual void findTrajectory(const ConfigspaceCoord &cbegin, const ConfigspaceCoord &cend, Config::Seq &ctrajectory) = 0;

		/** Control interface access
		*	@param[in]	tiny			Tiny container
		*	@return						Control interface
		*/
		static Control* get(Tiny& tiny);
		static const Control* get(const Tiny& tiny);
	};

	/*************************************************************************
	*
	* Contact interface and data structures
	*
	**************************************************************************/

	/** Training data */
	class Training3D {
	public:
		/** Map contact type -> data */
		typedef std::map<std::string, Training3D> Map;

		/** Trajectory */
		Config::Seq trajectory;
		/** Features */
		Feature3D::Seq features;

		/** Set to the default values. */
		void clear() {
			trajectory.clear();
			features.clear();
		}
	};

	/** Configuration model represents robot configuration density at contact  */
	class ConfigModel : public Sample {
	public:
		/** Sequence representing configuration model density */
		typedef std::vector<ConfigModel> Seq;

		/** Robot configuration */
		ConfigspaceCoord config;
		/** Robot end-effector frame */
		Frame3D frame;

		/** Set to the default values. */
		void clear() {
			Sample::clear();
			config.clear();
			frame.clear();
		}
	};

	/** Robot path model */
	class PathModel : public ConfigModel::Seq, public Sample {
	public:
		/** Weighted sequence of path models */
		typedef std::vector<PathModel> Seq;

		/** Set to the default values. */
		void clear() {
			ConfigModel::Seq::clear();
			Sample::clear();
		}
	};

	/** Feature/parts-link contact */
	class ContactModel3D : public Sample {
	public:
		/** Sequence representing contact model density */
		typedef std::vector<ContactModel3D> Seq;
		/** Map link name -> contact model density */
		typedef std::map<std::string, Seq> Map;

		/** Reserved area */
		typedef Vec<std::uint8_t, 128> Reserved;

		/** Feature/parts global frame */
		Frame3D global;
		/** Feature/parts-link local frame */
		Frame3D local;

		/** Feature size. */
		std::uint32_t featureSize;
		/** Feature vector */
		Feature feature;
		/** Part id */
		std::uint64_t id;

		/** Reserved area */
		Reserved reserved;

		/** Default constructor sets the default values. */
		ContactModel3D() {
			clear();
		}
		/** Set to the default values. */
		void clear() {
			Sample::clear();
			global.clear();
			local.clear();
			featureSize = 0;
			feature.clear();
			id = 0;
			reserved.clear();
		}
	};

	/** Contact and configuration model data */
	class Model3D {
	public:
		/** Map contact type -> data */
		typedef std::map<std::string, Model3D> Map;

		/** Approach paths leading to contact (last waypoint) */
		PathModel::Seq paths;
		/** Config model at contact */
		ConfigModel::Seq configs;
		/** Contact models for each link */
		ContactModel3D::Map contacts;

		/** Model reserved area */
		Buffer reserved;

		/** Set to the default values. */
		void clear() {
			paths.clear();
			contacts.clear();
			reserved.clear();
		}
	};

	/** Robot path hypothesis */
	class Path : public Sample {
	public:
		/** Weighted sequence of paths */
		typedef std::vector<Path> Seq;

		/** Reserved area */
		typedef Vec<std::uint8_t, 1024> Reserved;

		/** Contact type */
		std::string type;
		/** Robot path */
		ConfigModel::Seq path;

		/** Reserved area */
		Reserved reserved;

		/** Set to the default values. */
		void clear() {
			Sample::clear();
			type.clear();
			path.clear();
		}
	};

	/** Query data */
	class Query {
	public:
		/** Robot path hypothesis */
		Path::Seq paths;

		/** Query reserved area */
		Buffer reserved;

		/** Set to the default values. */
		void clear() {
			paths.clear();
			reserved.clear();
		}
	};

	/** Robot trajectory */
	class Trajectory {
	public:
		/** Sequence of trajectories */
		typedef std::vector<Trajectory> Seq;

		/** Contact type */
		std::string type;
		/** Robot trajectory */
		Config::Seq trajectory;
		/** Trajectory workspace error */
		WorkspaceDist error;

		/** Set to the default values. */
		void clear() {
			type.clear();
			trajectory.clear();
		}
	};

	/** Contact interface */
	class Contact {
	public:
		/** Training: Creates contact models from training data - a set of trajectories and point cloud features
		*	@param[in]	training		training data
		*	@param[out]	models			contact and configuration models
		*/
		virtual void findModel(const Training3D::Map& training, Model3D::Map& models) = 0;

		/** Test: Finds path hypotheses from contact models and point cloud features
		*	@param[in]	models			contact and configuration models
		*	@param[in]	features		point cloud features
		*	@param[out]	query			query data
		*/
		virtual void findQuery(const Model3D::Map& models, const Feature3D::Seq& features, Query& query) = 0;

		/** Selection: Selects most likely path hypothesis and computes collision-free trajectory
		*	@param[in]	query			query data
		*	@param[out]	trajectory		most likely feasible trajectory
		*/
		virtual void selectTrajectory(const Query& query, Trajectory& trajectory) = 0;

		/** Contact interface access
		*	@param[in]	tiny			Tiny container
		*	@return						Contact interface
		*/
		static Contact* get(Tiny& tiny);
		static const Contact* get(const Tiny& tiny);
	};

}; // namespace tiny
}; // namespace interop
}; // namespace grasp

//------------------------------------------------------------------------------

#endif // _GRASP_TINY_TINY_H_