/** @file TinyGolem.h
 * 
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_TINY_TINYGOLEM_H_ // if #pragma once is not supported
#define _GRASP_TINY_TINYGOLEM_H_

#include "GraspInteropDefsGolem.h"
#include <Grasp/Tiny/Tiny.h>
#include <Golem/Ctrl/Controller.h>
#include <Grasp/Core/RB.h>
#include <Grasp/Contact/Manipulator.h>
#include <Grasp/Contact/Data.h>

//------------------------------------------------------------------------------

/** Grasp name space */
namespace grasp {
/** Grasp interoperability name space */
namespace interop {
	inline void convert(const golem::Controller::State::Seq& src, interop::Config::Seq& dst) {
		dst.resize(src.size());
		interop::copy(src.begin(), src.end(), dst.begin());
	}
	void convert(const tiny::Tiny& tiny, const interop::Config::Seq& src, golem::Controller::State::Seq& dst);

	/** Import trajectory from file */
	void loadTrajectory(const tiny::Tiny& tiny, const std::string& path, interop::Config::Seq& trajectory);

	inline void convert(const grasp::Configuration::Kernel& src, tiny::ConfigModel& dst) {
		convert((const golem::Sample<golem::Real>&)src, (interop::Sample&)dst);
		convert(src.config, dst.config);
		convert(src.frame, dst.frame);
	}
	inline void convert(const tiny::ConfigModel& src, grasp::Configuration::Kernel& dst) {
		convert((const interop::Sample&)src, (golem::Sample<golem::Real>&)dst);
		convert(src.config, dst.config);
		convert(src.frame, dst.frame);
	}

	inline void convert(const grasp::Configuration::Path& src, tiny::PathModel& dst) {
		convert((const golem::Sample<golem::Real>&)src, (interop::Sample&)dst);
		dst.resize(src.size());
		interop::copy(src.begin(), src.end(), dst.begin());
	}
	inline void convert(const tiny::PathModel& src, grasp::Configuration::Path& dst) {
		convert((const interop::Sample&)src, (golem::Sample<golem::Real>&)dst);
		dst.resize(src.size());
		interop::copy(src.begin(), src.end(), dst.begin());
	}

	void convert(const grasp::Manipulator::Waypoint& src, tiny::ConfigModel& dst);
	void convert(const tiny::ConfigModel& src, grasp::Manipulator::Waypoint& dst);

	void convert(const grasp::Contact3D& src, tiny::ContactModel3D& dst);
	void convert(const tiny::ContactModel3D& src, grasp::Contact3D& dst);

	void convert(const grasp::Contact::Config& src, tiny::Path& dst);
	void convert(const tiny::Path& src, grasp::Contact::Config& dst);

	inline void convert(const grasp::Contact::Config::Ptr& src, tiny::Path& dst) {
		convert(*src, dst);
	}
	inline void convert(const tiny::Path& src, grasp::Contact::Config::Ptr& dst) {
		dst.reset(new grasp::Contact::Config());
		convert(src, *dst);
	}

	void convert(const grasp::data::ContactModel::Data& src, tiny::Model3D& dst);
	void convert(const tiny::Model3D& src, grasp::data::ContactModel::Data& dst);

	void convert(const grasp::data::ContactQuery::Data& src, tiny::Query& dst);
	void convert(const tiny::Query& src, grasp::data::ContactQuery::Data& dst);


	template <typename _Dst> inline void bufferCast(const tiny::Buffer& src, _Dst& dst) {
		const typename _Dst::value_type* begin = reinterpret_cast<const typename _Dst::value_type*>(src.data() + sizeof(std::uint64_t));
		const typename _Dst::value_type* end = begin + *reinterpret_cast<const std::uint64_t*>(src.data());
		dst.clear();
		for (; begin != end; ++begin)
			dst.insert(dst.end(), *begin);
	}
	template <typename _Src> inline void bufferCast(const _Src& src, tiny::Buffer& dst) {
		dst.resize(sizeof(std::uint64_t) + src.size()*sizeof(typename _Src::value_type));
		*reinterpret_cast<std::uint64_t*>(dst.data()) = src.size();
		typename _Src::value_type* begin = reinterpret_cast<typename _Src::value_type*>(dst.data() + sizeof(std::uint64_t));
		typename _Src::value_type* end = begin + src.size();
		for (typename _Src::const_iterator ptr = src.begin(); begin != end; ++begin, ++ptr)
			*begin = *ptr;
	}

}; // namespace interop
}; // namespace grasp

//------------------------------------------------------------------------------

#endif // _GRASP_TINY_TINYGOLEM_H_