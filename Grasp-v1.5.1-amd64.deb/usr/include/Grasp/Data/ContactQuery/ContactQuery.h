/** @file ContactQuery.h
 *
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_DATA_CONTACTQUERY_CONTACTQUERY_H_
#define _GRASP_DATA_CONTACTQUERY_CONTACTQUERY_H_

//------------------------------------------------------------------------------

#include <Golem/Tools/Library.h>
#include <Golem/UI/Renderer.h>
#include <Grasp/Core/Data.h>
#include <Grasp/Core/UI.h>
#include <Grasp/Contact/Classifier.h>
#include <Grasp/Contact/Cluster.h>
#include <Grasp/App/Manager/Data.h>
#include <Grasp/App/Player/Data.h>
#include <Grasp/Contact/Data.h>

//------------------------------------------------------------------------------

extern "C" {
	GOLEM_LIBRARY_DECLDIR void* graspDescLoader(void);
};

//------------------------------------------------------------------------------

namespace grasp {
namespace data {

//------------------------------------------------------------------------------

class ItemContactQuery;
class HandlerContactQuery;

/** Data item representing a collection of contact query densities.
*/
class GOLEM_LIBRARY_DECLDIR ItemContactQuery : public Item, public Convert, public ContactQuery {
public:
	friend class HandlerContactQuery;

	/** Query data */
	ContactQuery::Data data;

	/** Query file */
	mutable File dataFile;

	/** Cluster index */
	mutable golem::U32 clusterIndex;
	/** Config index */
	mutable golem::U32 configIndex;
	/** Model index */
	mutable golem::U32 modelIndex;

	/** Sets contact query data. */
	virtual void setData(const ContactQuery::Data& data);
	/** Returns contact query data. */
	virtual const ContactQuery::Data& getData() const;

	/** Current config */
	Contact::Config* getConfig() const;

	/** Clones item. */
	virtual Item::Ptr clone() const;

	/** Creates render buffer, the buffer can be shared and allocated on Handler */
	virtual void createRender();

protected:
	/** Data handler */
	HandlerContactQuery& handler;

	/** Convert: Convert current item */
	virtual Item::Ptr convert(const Handler& handler);
	/** Convert: return available interfaces */
	virtual const StringSeq& getConvertInterfaces() const;
	/** Convert: is supported by the interface */
	virtual bool isConvertSupported(const Handler& handler) const;

	/** Load item from xml context, accessible only by Data. */
	virtual void load(const std::string& prefix, const golem::XMLContext* xmlcontext);
	/** Save item to xml context, accessible only by Data. */
	virtual void save(const std::string& prefix, golem::XMLContext* xmlcontext) const;

	/** Initialise data item */
	ItemContactQuery(HandlerContactQuery& handler);
};

/** Data handler is associated with a particular item type, it knows how to create items, it can hold shared buffer.
*/
class GOLEM_LIBRARY_DECLDIR HandlerContactQuery : public Handler, public HandlerPlan, public UI, public Transform {
public:
	friend class ItemContactQuery;

	/** Data handler description */
	class GOLEM_LIBRARY_DECLDIR Desc : public Handler::Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;
		typedef std::map<std::string, Ptr> Map;

		/** Manipulator description */
		Manipulator::Desc::Ptr manipulatorDesc;
		/** Classifier description */
		Classifier::Desc::Ptr classifierDesc;

		/** Clustering algorithm */
		Cluster::Desc clusterDesc;

		/** Query appearance */
		ContactQuery::Data::Appearance appearance;

		/** Query suffix */
		std::string querySuffix;

		/** Set to default */
		Desc() {
			setToDefault();
		}

		/** Sets the parameters to the default values */
		void setToDefault() {
			grasp::data::Handler::Desc::setToDefault();

			manipulatorDesc.reset(new Manipulator::Desc);
			classifierDesc.reset(new Classifier::Desc);
			clusterDesc.setToDefault();
			appearance.setToDefault();

			querySuffix = getFileExtContactQuery();
		}

		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			grasp::data::Handler::Desc::assertValid(ac);

			Assert::valid(manipulatorDesc != nullptr, ac, "manipulatorDesc: null");
			manipulatorDesc->assertValid(Assert::Context(ac, "manipulatorDesc->"));
			Assert::valid(classifierDesc != nullptr, ac, "classifierDesc: null");
			classifierDesc->assertValid(Assert::Context(ac, "classifierDesc->"));

			clusterDesc.assertValid(Assert::Context(ac, "clusterDesc."));

			appearance.assertValid(Assert::Context(ac, "appearance."));

			Assert::valid(querySuffix.length() > 0, ac, "querySuffix: empty");
		}

		/** Load descritpion from xml context. */
		virtual void load(golem::Context& context, const golem::XMLContext* xmlcontext);

		/** Creates the object from the description. */
		virtual Handler::Ptr create(golem::Context &context) const;
	};

	/** File extension: query */
	static std::string getFileExtContactQuery();

protected:
	/** Manipulator description */
	Manipulator::Desc::Ptr manipulatorDesc;
	/** Classifier description */
	Classifier::Desc::Ptr classifierDesc;
	/** Clustering algorithm */
	Cluster::Desc clusterDesc;
	/** Query appearance */
	ContactQuery::Data::Appearance appearance;

	/** Manipulator */
	Manipulator::Ptr manipulator;
	/** Classifier */
	Classifier::Ptr classifier;

	/** Rendering */
	golem::DebugRenderer renderer, rendererPoints, rendererBounds;

	/** Pseudorandom numer generator */
	mutable golem::Rand rand;

	/** Cluster index request */
	golem::I32 clusterIndexRequest;
	/** Config index request */
	golem::I32 configIndexRequest;
	/** Model index request */
	golem::I32 modelIndexRequest;
	/** Clustering likelihood */
	bool likelihoodRequest;
	/** Clustering type */
	bool typeRequest;
	/** Clustering pose */
	bool poseRequest;
	/** Subspace dist request */
	bool subspaceDistRequest;

	/** Query suffix */
	std::string querySuffix;

	/** Transform interfaces */
	StringSeq transformInterfaces;
	/** Convert interfaces */
	StringSeq convertInterfaces;

	/** HandlerPlan: Sets planner and controllers. */
	virtual void set(const golem::Planner& planner, const StringSeq& controllerIDSeq);

	/** Draw data */
	void draw(const ItemContactQuery& item, golem::DebugRenderer& renderer, golem::DebugRenderer& rendererPoints) const;
	/** Print current config information */
	void printConfigInfo(const ItemContactQuery& item) const;

	/** Creates render buffer */
	void createRender(const ItemContactQuery& item);
	/** golem::UIRenderer: Render on output device. */
	virtual void render() const;
	/** golem::UIRenderer: Render on output device. */
	virtual void customRender() const;

	/** golem::UIRenderer: Mouse button handler. */
	virtual void mouseHandler(int button, int state, int x, int y);
	/** golem::UIRenderer: Mouse motion handler. */
	virtual void motionHandler(int x, int y);
	/** golem::UIRenderer: Keyboard handler. */
	virtual void keyboardHandler(int key, int x, int y);

	/** Construct empty item, accessible only by Data. */
	virtual Item::Ptr create() const;

	/** Transform: Transform input items */
	virtual Item::Ptr transform(const Item::List& input);
	/** Transform: return available interfaces */
	virtual const StringSeq& getTransformInterfaces() const;
	/** Transform: is supported by the interface */
	virtual bool isTransformSupported(const Item& item) const;

	/** Convert: Convert current item */
	virtual Item::Ptr convert(ItemContactQuery& item, const Handler& handler);
	/** Convert: is supported by the interface */
	virtual bool isConvertSupported(const Handler& handler) const;

	/** Initialise handler */
	void create(const Desc& desc);
	/** Initialise handler */
	HandlerContactQuery(golem::Context &context);
};

//------------------------------------------------------------------------------

};	// namespace
};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_DATA_CONTACTQUERY_CONTACTQUERY_H_*/
