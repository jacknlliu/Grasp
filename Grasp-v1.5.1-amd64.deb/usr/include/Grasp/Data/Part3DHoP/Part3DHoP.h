/** @file Part3DHoP.h
 *
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_DATA_PART_3D_HOP_PART_3D_HOP_H_
#define _GRASP_DATA_PART_3D_HOP_PART_3D_HOP_H_

//------------------------------------------------------------------------------

#include <Golem/Tools/Library.h>
#include <Golem/UI/Renderer.h>
#include <Grasp/Core/Data.h>
#include <Grasp/Core/UI.h>
#include <Grasp/Core/Cloud.h>
#include <Grasp/Core/Import.h>
#include <Grasp/App/Manager/Data.h>
#include <Grasp/App/Recorder/Data.h>
#include <Grasp/Contact/Data.h>
#include <Grasp/Data/Part3DHoP/Part3DHoPInterop.h>
#include "GraspInteropStreamSocket.h"

//------------------------------------------------------------------------------

extern "C" {
	GOLEM_LIBRARY_DECLDIR void* graspDescLoader(void);
};

//------------------------------------------------------------------------------

namespace grasp {
namespace data {

//------------------------------------------------------------------------------

class ItemPart3DHoP;
class HandlerPart3DHoP;

/** Data item representing hierarchies of parts 3D.
*/
class GOLEM_LIBRARY_DECLDIR ItemPart3DHoP : public Item, public CloudData, public Part3D, public Normal3D {
public:
	friend class HandlerPart3DHoP;

	/** Point cloud */
	using CloudData::cloud;

	/** Models */
	data::Part3D::IndexSetMap models;

	/** Realisations */
	data::Part3D::IndexSetMap realisations;
	/** Parts */
	data::Part3D::Part::Map parts;
	/** Part-cloud point indices */
	data::Part3D::IndexSetMap indices;

	/** Cloud file */
	mutable File cloudFile;
	/** Part3DHoP file */
	mutable File part3DFile;

	/** Current cloud index */
	golem::U32 cloudIndex;
	/** Current level index */
	golem::U32 levelIndex;
	/** Current part index */
	golem::U32 partIndex;

	/** Clones item. */
	virtual Item::Ptr clone() const;

	/** Creates render buffer, the buffer can be shared and allocated on Handler */
	virtual void createRender();

	/** Point3D: Total number of available points */
	virtual size_t getNumOfPoints() const;
	/** Point3D: Sample point. */
	virtual size_t samplePoint(golem::Rand& rand) const;
	/** Point3D: Conditional point */
	virtual Point3D::Point getPoint(size_t index) const;
	/** Point3D: Point transform */
	virtual void transform(const golem::Mat34& trn);
	/** Point3D: Sensor frame. */
	virtual void getSensorFrame(golem::Mat34& frame) const;

	/** Normal3D: Query density normal covariance */
	virtual Point3D::RBDist getNormalCovariance() const;
	/** Normal3D: Select normal given point index. */
	virtual void getNormal(size_t index, Point3D::Vec3& normal) const;

	/** Part3D: Query density frame covariance for a given id */
	virtual Point3D::RBDist getFrameCovariance(Part3D::Index model) const;
	/** Part3D: Select id given point index. Do not sample orientation - return only mean value to use later with sensor model. */
	virtual void getPart(size_t index, Part3D::Part::Map& partMap) const;
	/** Part3D: Sample local frames from sensor model. */
	virtual void sampleSensorModel(golem::Rand& rand, size_t index, Part3D::Index model, Point3D::Mat34& frame) const;

protected:
	/** Data handler */
	HandlerPart3DHoP& handler;

	/** Part-cloud point and part indices - top-down mapping */
	data::Part3D::IndexSetMap indicesTopDown;
	/** Part-cloud point and part indices - bottom-up mapping */
	data::Part3D::IndexMap indicesBottomUp;
	/** Realisation part indices and level map */
	data::Part3D::IndexMap partToLevelMap;
	/** Realisation part indices and level map */
	data::Part3D::IndexSetMap levelToPartMap;

	/** Process data */
	void process();

	/** Load item from xml context, accessible only by Data. */
	virtual void load(const std::string& prefix, const golem::XMLContext* xmlcontext);
	/** Save item to xml context, accessible only by Data. */
	virtual void save(const std::string& prefix, golem::XMLContext* xmlcontext) const;

	/** Initialise data item */
	ItemPart3DHoP(HandlerPart3DHoP& handler);
};

/** Data handler is associated with a particular item type, it knows how to create items, it can hold shared buffer.
*/
class GOLEM_LIBRARY_DECLDIR HandlerPart3DHoP : public Handler, public UI, public Transform {
public:
	friend class ItemPart3DHoP;

	/** File extension: part3D */
	static const std::string FILE_EXT_CONTACT_PART3D;

	/** Data handler description */
	class GOLEM_LIBRARY_DECLDIR Desc : public Handler::Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;
		typedef std::map<std::string, Ptr> Map;

		/** Hop3D server host name */
		std::string host;
		/** Hop3D server host port */
		unsigned short port;

		/** Cloud frame transformation */
		bool cloudFrameTrn;

		/** Cloud appearance */
		Cloud::Appearance cloudAppearance;
		/** Cloud suffix */
		std::string cloudSuffix;

		/** part3D suffix */
		std::string part3DSuffix;

		/** Set to default */
		Desc() {
			setToDefault();
		}

		/** Sets the parameters to the default values */
		void setToDefault() {
			grasp::data::Handler::Desc::setToDefault();

			host = "localhost";
			port = 26783;

			cloudFrameTrn = false;

			cloudAppearance.setToDefault();
			cloudSuffix = grasp::Import::FILE_EXT_CLOUD_PCD;

			part3DSuffix = FILE_EXT_CONTACT_PART3D;
		}

		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			grasp::data::Handler::Desc::assertValid(ac);

			Assert::valid(host.length() > 0, ac, "host: empty");
			Assert::valid(port > 0, ac, "port: invalid");

			cloudAppearance.assertValid(Assert::Context(ac, "cloudAppearance."));
			Assert::valid(cloudSuffix.length() > 0, ac, "cloudSuffix: empty");

			Assert::valid(part3DSuffix.length() > 0, ac, "part3DSuffix: invalid");
		}

		/** Load descritpion from xml context. */
		virtual void load(golem::Context& context, const golem::XMLContext* xmlcontext);

		/** Creates the object from the description. */
		virtual Handler::Ptr create(golem::Context &context) const;
	};

protected:
	/** Rendering */
	golem::DebugRenderer renderer;

	/** Hop3D server host name */
	std::string host;
	/** Hop3D server host port */
	unsigned short port;
	/** Hop3D client */
	interop::Client client;

	/** Cloud frame transformation */
	bool cloudFrameTrn;

	/** Part3D models */
	data::Part3D::IndexSetMap models;
	/** Part3D available cloud names */
	StringSeq names;
	/** Model part indices and level map */
	data::Part3D::IndexMap modelToLevelMap;
	/** Model part indices and level map */
	data::Part3D::IndexSetMap levelToModelMap;

	/** Transform interfaces */
	StringSeq transformInterfaces;

	/** Cloud appearance */
	Cloud::Appearance cloudAppearance;
	/** Cloud suffix */
	std::string cloudSuffix;

	/** part3D suffix */
	std::string part3DSuffix;

	/** Claud request */
	golem::I32 cloudRequest;
	/** Level request */
	golem::I32 levelRequest;
	/** Part request */
	golem::I32 partRequest;

	/** Process data */
	void process();

	/** Hierarchy level finder */
	void findLevel(const data::Part3D::IndexSetMap& map, data::Part3D::IndexMap& level) const;

	/** Creates render buffer */
	void createRender(const ItemPart3DHoP& item);
	/** golem::UIRenderer: Render on output device. */
	virtual void render() const;
	/** golem::UIRenderer: Render on output device. */
	virtual void customRender() const;

	/** golem::UIRenderer: Mouse button handler. */
	virtual void mouseHandler(int button, int state, int x, int y);
	/** golem::UIRenderer: Mouse motion handler. */
	virtual void motionHandler(int x, int y);
	/** golem::UIRenderer: Keyboard handler. */
	virtual void keyboardHandler(int key, int x, int y);

	/** Construct empty item, accessible only by Data. */
	virtual Item::Ptr create() const;

	/** Transform: Transform input items */
	virtual Item::Ptr transform(const Item::List& input);
	/** Transform: return available interfaces */
	virtual const StringSeq& getTransformInterfaces() const;
	/** Transform: is supported by the interface */
	virtual bool isTransformSupported(const Item& item) const;

	/** Initialise handler */
	void create(const Desc& desc);
	/** Initialise handler */
	HandlerPart3DHoP(golem::Context &context);
};

//------------------------------------------------------------------------------

};	// namespace
};	// namespace

//------------------------------------------------------------------------------

namespace golem {
	template <> GOLEM_LIBRARY_DECLDIR void Stream::read(grasp::data::Part3D::IndexSetMap::value_type& value) const;
	template <> GOLEM_LIBRARY_DECLDIR void Stream::write(const grasp::data::Part3D::IndexSetMap::value_type& value);
};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_DATA_PART_3D_HOP_PART_3D_HOP_H_*/
