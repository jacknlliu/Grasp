/** @file ContactModel.h
 *
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_DATA_CONTACTMODEL_CONTACTMODEL_H_
#define _GRASP_DATA_CONTACTMODEL_CONTACTMODEL_H_

//------------------------------------------------------------------------------

#include <Golem/Tools/Library.h>
#include <Golem/UI/Renderer.h>
#include <Grasp/Core/Data.h>
#include <Grasp/Core/UI.h>
#include <Grasp/Contact/Model.h>
#include <Grasp/Contact/Configuration.h>
#include <Grasp/App/Manager/Data.h>
#include <Grasp/App/Player/Data.h>
#include <Grasp/Contact/Data.h>

//------------------------------------------------------------------------------

extern "C" {
	GOLEM_LIBRARY_DECLDIR void* graspDescLoader(void);
};

//------------------------------------------------------------------------------

namespace grasp {
namespace data {

//------------------------------------------------------------------------------

class ItemContactModel;
class HandlerContactModel;

/** Data item representing grasp training data.
*/
class GOLEM_LIBRARY_DECLDIR ItemContactModel : public Item , public ContactModel {
public:
	friend class HandlerContactModel;

	/** Training data */
	ContactModel::Data::Map dataMap;

	/** Training data file */
	mutable File dataFile;

	/** Data index */
	mutable golem::U32 dataIndex;
	/** Path index */
	mutable golem::U32 pathIndex;

	/** data::Model: Sets contact model data. */
	virtual void setData(const ContactModel::Data::Map& dataMap);
	/** data::Model: Returns contact model data. */
	virtual const ContactModel::Data::Map& getData() const;

	/** Clones item. */
	virtual Item::Ptr clone() const;

	/** Creates render buffer, the buffer can be shared and allocated on Handler */
	virtual void createRender();

protected:
	/** Data handler */
	HandlerContactModel& handler;

	/** Load item from xml context, accessible only by Data. */
	virtual void load(const std::string& prefix, const golem::XMLContext* xmlcontext);
	/** Save item to xml context, accessible only by Data. */
	virtual void save(const std::string& prefix, golem::XMLContext* xmlcontext) const;

	/** Initialise data item */
	ItemContactModel(HandlerContactModel& handler);
};

/** Data handler is associated with a particular item type, it knows how to create items, it can hold shared buffer.
*/
class GOLEM_LIBRARY_DECLDIR HandlerContactModel : public Handler, public HandlerPlan, public UI, public Transform {
public:
	friend class ItemContactModel;

	/** Data handler description */
	class GOLEM_LIBRARY_DECLDIR Desc : public Handler::Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;
		typedef std::map<std::string, Ptr> Map;

		/** Manipulator description */
		Manipulator::Desc::Ptr manipulatorDesc;
		/** Configuration description */
		Configuration::Desc::Ptr configurationDesc;

		/** Model descriptions */
		grasp::Model::Desc::Map modelDescMap;

		/** Appearance */
		ContactModel::Data::Appearance appearance;

		/** Cloud suffix */
		std::string modelSuffix;

		/** Set to default */
		Desc() {
			setToDefault();
		}

		/** Sets the parameters to the default values */
		void setToDefault() {
			grasp::data::Handler::Desc::setToDefault();

			manipulatorDesc.reset(new Manipulator::Desc);
			configurationDesc.reset(new Configuration::Desc);
			
			modelDescMap.insert(std::make_pair(Manipulator::Link(Manipulator::Link::TYPE_ANY).toString(), grasp::Model::Desc::Ptr(new grasp::Model::Desc)));

			appearance.setToDefault();

			modelSuffix = getFileExtContactModel();
		}

		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			grasp::data::Handler::Desc::assertValid(ac);

			Assert::valid(manipulatorDesc != nullptr, ac, "manipulatorDesc: null");
			manipulatorDesc->assertValid(Assert::Context(ac, "manipulatorDesc->"));
			Assert::valid(configurationDesc != nullptr, ac, "configurationDesc: null");
			configurationDesc->assertValid(Assert::Context(ac, "configurationDesc->"));

			Assert::valid(!modelDescMap.empty(), ac, "modelDescMap: empty");
			for (grasp::Model::Desc::Map::const_iterator i = modelDescMap.begin(); i != modelDescMap.end(); ++i) {
				Assert::valid(i->second != nullptr, ac, "modelDescMap[]: null");
				i->second->assertValid(Assert::Context(ac, "modelDescMap[]->"));
			}

			appearance.assertValid(Assert::Context(ac, "appearance."));

			Assert::valid(modelSuffix.length() > 0, ac, "modelSuffix: empty");
		}

		/** Load descritpion from xml context. */
		virtual void load(golem::Context& context, const golem::XMLContext* xmlcontext);

		/** Creates the object from the description. */
		virtual Handler::Ptr create(golem::Context &context) const;
	};

	/** File extension: model */
	static std::string getFileExtContactModel();

protected:
	/** Manipulator description */
	Manipulator::Desc::Ptr manipulatorDesc;
	/** Configuration description */
	Configuration::Desc::Ptr configurationDesc;
	/** Model descriptions */
	grasp::Model::Desc::Map modelDescMap;
	/** Appearance */
	ContactModel::Data::Appearance appearance;

	/** Manipulator */
	Manipulator::Ptr manipulator;
	/** Configuration */
	Configuration::Ptr configuration;

	/** Models */
	grasp::Model::Map modelMap;

	/** Rendering */
	golem::DebugRenderer renderer;

	/** Data index request */
	golem::I32 dataIndexRequest;
	/** Path index request */
	golem::I32 pathIndexRequest;
	/** Subspace dist request */
	bool subspaceDistRequest;

	/** Cloud suffix */
	std::string modelSuffix;

	/** Transform interfaces */
	StringSeq transformInterfaces;

	/** Create training data */
	virtual void create(const Point3D::ConstSeq& points, const grasp::Waypoint::Seq& waypoints, grasp::data::ContactModel::Data& data) const;

	/** HandlerPlan: Sets planner and controllers. */
	virtual void set(const golem::Planner& planner, const StringSeq& controllerIDSeq);

	/** Info */
	std::string toString(const golem::U32 pathIndex, const grasp::data::ContactModel::Data& data) const;

	/** Creates render buffer */
	void createRender(const ItemContactModel& item);
	/** golem::UIRenderer: Render on output device. */
	virtual void render() const;
	/** golem::UIRenderer: Render on output device. */
	virtual void customRender() const;

	/** golem::UIRenderer: Mouse button handler. */
	virtual void mouseHandler(int button, int state, int x, int y);
	/** golem::UIRenderer: Mouse motion handler. */
	virtual void motionHandler(int x, int y);
	/** golem::UIRenderer: Keyboard handler. */
	virtual void keyboardHandler(int key, int x, int y);

	/** Construct empty item, accessible only by Data. */
	virtual Item::Ptr create() const;

	/** Transform: Transform input items */
	virtual Item::Ptr transform(const Item::List& input);
	/** Transform: return available interfaces */
	virtual const StringSeq& getTransformInterfaces() const;
	/** Transform: is supported by the interface */
	virtual bool isTransformSupported(const Item& item) const;

	/** Initialise handler */
	void create(const Desc& desc);
	/** Initialise handler */
	HandlerContactModel(golem::Context &context);
};

//------------------------------------------------------------------------------

};	// namespace
};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_DATA_CONTACTMODEL_CONTACTMODEL_H_*/
