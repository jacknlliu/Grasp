/** @file PointsCurv.h
 *
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_DATA_POINTSCURV_POINTSCURV_H_
#define _GRASP_DATA_POINTSCURV_POINTSCURV_H_

//------------------------------------------------------------------------------

#include <Golem/Tools/Library.h>
#include <Golem/UI/Renderer.h>
#include <Grasp/Core/Data.h>
#include <Grasp/Core/UI.h>
#include <Grasp/Core/Cloud.h>
#include <Grasp/App/Manager/Data.h>
#include <Grasp/Contact/Data.h>

//------------------------------------------------------------------------------

extern "C" {
	GOLEM_LIBRARY_DECLDIR void* graspDescLoader(void);
};

//------------------------------------------------------------------------------

namespace grasp {
namespace data {

//------------------------------------------------------------------------------

class ItemPointsCurv;
class HandlerPointsCurv;

/** Data item representing RGB image.
*/
class GOLEM_LIBRARY_DECLDIR ItemPointsCurv : public Item, public TimeStamp, public Feature3D {
public:
	friend class HandlerPointsCurv;

	/** Point with curvature sequence pointer */
	Cloud::PointCurvSeqPtr cloud;

	/** Robot configuration (optional) */
	grasp::ConfigMat34 config;

	/** Cloud file */
	mutable File cloudFile;

	/** Curvature std deviation multiplier */
	golem::Vec3 curvatureStdDevFac;
	/** Magnitude of random orientation on surface = randGauss(0, PI*exp(-factor*curvature)) */
	golem::Real normalRandAng;
	/** Query distribution standard deviation */
	grasp::RBDist queryPoseStdDev;

	/** Curvature covariance */
	golem::Vec3 curvatureCov;

	/** Update cloud settings */
	void update();

	/** Clones item. */
	virtual Item::Ptr clone() const;

	/** Creates render buffer, the buffer can be shared and allocated on Handler */
	virtual void createRender();

	/** Point3D: Total number of available points */
	virtual size_t getNumOfPoints() const;
	/** Point3D: Sample point. */
	virtual size_t samplePoint(golem::Rand& rand) const;
	/** Point3D: Point */
	virtual Point getPoint(size_t index) const;

	/** Point3D: transform */
	virtual void transform(const golem::Mat34& trn);

	/** Point3D: Sensor frame. */
	virtual void getSensorFrame(golem::Mat34& frame) const;

	/** Feature3D: Select feature given point index. Do not sample orientation - return only mean value to use later with sensor model.  */
	virtual void getFeature(size_t index, Feature& feature, Mat33& orientation) const;
	/** Feature3D: Sample local frame orientations from sensor model given mean value. */
	virtual void sampleSensorModel(golem::Rand& rand, size_t index, Mat33& orientation) const;

	/** Feature3D: Featur covariance */
	virtual Feature getFeatureCovariance() const;
	/** Feature3D: Query density frame covariance */
	virtual RBDist getFrameCovariance() const;

	/** Point3D: Debug reset */
	virtual void debugReset() const;
	/** Point3D: Debug string */
	virtual void debugString(std::string& str) const;

protected:
	/** Data handler */
	HandlerPointsCurv& handler;

	/** Samples */
	mutable golem::U32 samplesCount;
	/** Rotation angle */
	mutable golem::Real curvRandMag;

	/** Load item from xml context, accessible only by Data. */
	virtual void load(const std::string& prefix, const golem::XMLContext* xmlcontext);
	/** Save item to xml context, accessible only by Data. */
	virtual void save(const std::string& prefix, golem::XMLContext* xmlcontext) const;

	/** Initialise data item */
	ItemPointsCurv(HandlerPointsCurv& handler);
};

/** Data handler is associated with a particular item type, it knows how to create items, it can hold shared buffer.
*/
class GOLEM_LIBRARY_DECLDIR HandlerPointsCurv : public Handler, public UI, public Transform {
public:
	friend class ItemPointsCurv;

	/** Data handler description */
	class GOLEM_LIBRARY_DECLDIR Desc : public Handler::Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;
		typedef std::map<std::string, Ptr> Map;

		/** Cloud appearance */
		Cloud::Appearance cloudAppearance;
		/** Cloud suffix */
		std::string cloudSuffix;

		/** Cloud description */
		Cloud::Desc cloudDesc;

		/** Curvature std deviation multiplier */
		golem::Vec3 curvatureStdDevFac;
		/** Magnitude of random orientation on surface = randGauss(0, PI*exp(-factor*curvature)) */
		golem::Real normalRandAng;
		/** Query distribution standard deviation */
		grasp::RBDist queryPoseStdDev;

		/** Set to default */
		Desc() {
			setToDefault();
		}

		/** Sets the parameters to the default values */
		void setToDefault() {
			grasp::data::Handler::Desc::setToDefault();

			cloudAppearance.setToDefault();
			cloudSuffix = getFileExtCloudPCD();
			cloudDesc.setToDefault();

			normalRandAng = golem::Real(100.0);
			curvatureStdDevFac.set(golem::Real(10.0), golem::Real(10.0), golem::REAL_ONE);
			queryPoseStdDev.set(golem::Real(0.005), golem::Real(200.0));
		}

		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			grasp::data::Handler::Desc::assertValid(ac);

			cloudAppearance.assertValid(Assert::Context(ac, "cloudAppearance."));
			Assert::valid(cloudSuffix.length() > 0, ac, "cloudSuffix: empty");

			cloudDesc.assertValid(Assert::Context(ac, "cloudDesc."));

			Assert::valid(normalRandAng >= golem::REAL_ZERO, ac, "normalRandAng: < 0");
			Assert::valid(curvatureStdDevFac > golem::REAL_EPS, ac, "curvatureStdDevFac: < eps");
			Assert::valid(queryPoseStdDev.isValid(), ac, "queryPoseStdDev: invalid");
		}

		/** Load descritpion from xml context. */
		virtual void load(golem::Context& context, const golem::XMLContext* xmlcontext);

		/** Creates the object from the description. */
		virtual Handler::Ptr create(golem::Context &context) const;
	};

	/** File extension: cloud pcd */
	static std::string getFileExtCloudPCD();

	/** Cloud appearance */
	const Cloud::Appearance& getCloudAppearance() const {
		return cloudAppearance;
	}

protected:
	/** Point cloud rendering */
	golem::DebugRenderer cloudRenderer;

	/** Cloud appearance */
	Cloud::Appearance cloudAppearance;
	/** Cloud suffix */
	std::string cloudSuffix;

	/** Cloud description */
	Cloud::Desc cloudDesc;
	/** Region */
	golem::Bounds::Seq region;

	/** Curvature std deviation multiplier */
	golem::Vec3 curvatureStdDevFac;
	/** Magnitude of random orientation on surface = randGauss(0, PI*exp(-factor*curvature)) */
	golem::Real normalRandAng;
	/** Query distribution standard deviation */
	grasp::RBDist queryPoseStdDev;

	/** Transform interfaces */
	StringSeq transformInterfaces;

	/** Creates render buffer */
	void createRender(const ItemPointsCurv& image);
	/** golem::UIRenderer: Render on output device. */
	virtual void render() const;
	/** golem::UIRenderer: Render on output device. */
	virtual void customRender() const;

	/** golem::UIRenderer: Mouse button handler. */
	virtual void mouseHandler(int button, int state, int x, int y);
	/** golem::UIRenderer: Mouse motion handler. */
	virtual void motionHandler(int x, int y);
	/** golem::UIRenderer: Keyboard handler. */
	virtual void keyboardHandler(int key, int x, int y);

	/** Construct empty item, accessible only by Data. */
	virtual Item::Ptr create() const;

	/** Transform: Transform input items */
	virtual Item::Ptr transform(const Item::List& input);
	/** Transform: return available interfaces */
	virtual const StringSeq& getTransformInterfaces() const;
	/** Transform: is supported by the interface */
	virtual bool isTransformSupported(const Item& item) const;

	/** Initialise handler */
	void create(const Desc& desc);
	/** Initialise handler */
	HandlerPointsCurv(golem::Context &context);
};

//------------------------------------------------------------------------------

};	// namespace
};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_DATA_POINTSCURV_POINTSCURV_H_*/
