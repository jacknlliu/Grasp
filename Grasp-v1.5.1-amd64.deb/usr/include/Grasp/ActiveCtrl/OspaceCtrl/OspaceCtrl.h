/** @file OspaceCtrl.h
 * 
 * @author	Maxime Adjigble 
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_ACTIVECTRL_OSPACE_CTRL_OSPACE_CTRL_H_
#define _GRASP_ACTIVECTRL_OSPACE_CTRL_OSPACE_CTRL_H_

//------------------------------------------------------------------------------

#include <Grasp/Core/ActiveCtrl.h>
#include <Grasp/Core/UI.h>
#include <Grasp/Core/FT.h>
#include <Grasp/ActiveCtrl/ActiveCtrl/ActiveSingleCtrl.h>
#include <Golem/Math/Vec2.h>

//------------------------------------------------------------------------------

extern "C" {
	GOLEM_LIBRARY_DECLDIR void* graspDescLoader(void);
};

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** OspaceCtrl implements operational space control. */
class GOLEM_LIBRARY_DECLDIR OspaceCtrl : public ActiveCtrl, public ActiveSingleCtrl, public UI {
public:
	/** OspaceCtrl factory */
	class GOLEM_LIBRARY_DECLDIR Desc : public ActiveCtrl::Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;

		/** Init timeout */
		golem::MSecTmU32 timeOut;

		/** Constructs from description object */
		Desc() {
			Desc::setToDefault();
		}
		/** Sets the parameters to the default values */
		virtual void setToDefault() {
			ActiveCtrl::Desc::setToDefault();

			timeOut = golem::MSEC_TM_U32_INF;
		}
		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			ActiveCtrl::Desc::assertValid(ac);

		}

		/** Load descritpion from xml context. */
		virtual void load(golem::Context& context, const golem::XMLContext* xmlcontext);

		GRASP_CREATE_FROM_OBJECT_DESC2(OspaceCtrl, ActiveCtrl::Ptr, golem::Planner&, const Sensor::Map&)
	};

	/** Activate/deactivate */
	virtual void setActive(bool active = true);

protected:
	golem::SingleCtrl* controller;

	/** Init timeout */
	golem::MSecTmU32 timeOut;

	/** Force access cs */
	mutable golem::CriticalSection csData;
	/** Render data */
	mutable golem::DebugRenderer renderer;

	/** SingleCtrl::CallbackIO: Data receive */
	virtual void sysRecv(golem::SingleCtrl* ctrl, golem::Controller::State& state);
	/** SingleCtrl::CallbackIO: Data send */
	virtual void sysSend(golem::SingleCtrl* ctrl, const golem::Controller::State& prev, golem::Controller::State& next, bool bSendPrev, bool bSendNext);

	/** golem::UIRenderer: Render on output device. */
	virtual void render() const;
	/** golem::UIRenderer: Render on output device. */
	virtual void customRender() const {}

	/** golem::UIKeyboardMouse: Mouse button handler. */
	virtual void mouseHandler(int button, int state, int x, int y);
	/** golem::UIKeyboardMouse: Mouse motion handler. */
	virtual void motionHandler(int x, int y);
	/** golem::UIKeyboardMouse: Keyboard handler. */
	virtual void keyboardHandler(int key, int x, int y);

	/** Creates/initialises the ActiveCtrl */
	void create(const Desc& desc);

	/** Constructs the ActiveCtrl */
	OspaceCtrl(golem::Planner &planner, const Sensor::Map& sensors);
	/** Cleaning */
	~OspaceCtrl();
};

//------------------------------------------------------------------------------

};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_ACTIVECTRL_OSPACE_CTRL_OSPACE_CTRL_H_*/
