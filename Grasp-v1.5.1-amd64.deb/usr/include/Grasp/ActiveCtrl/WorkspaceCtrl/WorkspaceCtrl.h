/** @file WorkspaceCtrl.h
 *
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_ACTIVECTRL_ARMHAND_WORKSPACE_ARMHAND_WORKSPACE_H_
#define _GRASP_ACTIVECTRL_ARMHAND_WORKSPACE_ARMHAND_WORKSPACE_H_

//------------------------------------------------------------------------------

#include <Grasp/Core/ActiveCtrl.h>
#include <Grasp/Core/UI.h>
#include <Grasp/Core/RB.h>
#include <Golem/Math/Vec2.h>

//------------------------------------------------------------------------------

extern "C" {
	GOLEM_LIBRARY_DECLDIR void* graspDescLoader(void);
};

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** WorkspaceCtrl is the interafce to a robot (right arm + hand), sensing devices and objects. */
class GOLEM_LIBRARY_DECLDIR WorkspaceCtrl : public ActiveCtrl, public UI {
public:
	/** Control mode */
	enum Mode {
		/** Disabled */
		MODE_DISABLED,
		/** Position */
		MODE_POSITION,
		/** Orientation */
		MODE_ORIENTATION,
		/** Position x */
		MODE_POSITION_X,
		/** Position y */
		MODE_POSITION_Y,
		/** Position z */
		MODE_POSITION_Z,
		/** Orientation x */
		MODE_ORIENTATION_X,
		/** Orientation y */
		MODE_ORIENTATION_Y,
		/** Orientation z */
		MODE_ORIENTATION_Z,
		/** Waypoint */
		MODE_WAYPOINT,

		/** First */
		MODE_FIRST = MODE_POSITION,
		/** Last */
		MODE_LAST = MODE_WAYPOINT,
	};

	/** Mode name */
	static const std::string ModeName[MODE_LAST + 1];

	/** WorkspaceCtrl factory */
	class GOLEM_LIBRARY_DECLDIR Desc : public ActiveCtrl::Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;

		/** Simulated mode control gains */
		golem::Twist ctrlSimGain;
		/** Simulated mode control reaction period of time */
		golem::Real ctrlSimReac;
		/** Simulated mode control prediction period of time */
		golem::Real ctrlSimPred;

		/** Frame increment */
		grasp::RBDist frameIncrement;

		/** Frame size */
		golem::Vec3 frameSize;

		/** Constructs from description object */
		Desc() {
			Desc::setToDefault();
		}
		/** Sets the parameters to the default values */
		virtual void setToDefault() {
			ActiveCtrl::Desc::setToDefault();

			ctrlSimGain.set(golem::Real(0.0002), golem::Real(0.0002), golem::Real(0.001), golem::Real(0.001), golem::Real(0.001), golem::Real(0.01));
			ctrlSimReac = golem::Real(0.1);
			ctrlSimPred = golem::Real(0.2);
			frameIncrement.set(golem::Real(0.05), golem::Real(0.05)*golem::REAL_PI);
			frameSize.set(0.1);
		}
		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			ActiveCtrl::Desc::assertValid(ac);

			Assert::valid(ctrlSimGain.isValid(), ac, "ctrlSimGain: invalid");
			Assert::valid(ctrlSimReac > golem::REAL_ZERO, ac, "ctrlSimReac: <= 0");
			Assert::valid(ctrlSimReac <= ctrlSimPred, ac, "ctrlSimReac: > ctrlSimPred");
			Assert::valid(frameIncrement.isValid(), ac, "frameIncrement: invalid");
			Assert::valid(frameSize.isPositive(), ac, "frameSize: <= 0");
		}

		/** Load descritpion from xml context. */
		virtual void load(golem::Context& context, const golem::XMLContext* xmlcontext);

		GRASP_CREATE_FROM_OBJECT_DESC2(WorkspaceCtrl, ActiveCtrl::Ptr, golem::Planner&, const Sensor::Map&)
	};

protected:
	/** Controller */
	golem::Controller* ctrl;
	/** Controller state info */
	golem::Controller::State::Info ctrlInfo;
	
	/** Control mode */
	golem::U32 mode;
	/** Controller task */
	ThreadTask::Ptr task;
	/** Reference frame */
	golem::Mat34 referenceFrame;
	/** Target frame */
	golem::Mat34 targetFrame;

	/** Increment step */
	golem::U32 incrementStep;
	/** Frame increment */
	grasp::RBDist frameIncrement;

	/** Simulated mode control gains */
	golem::Twist ctrlSimGain;
	/** Simulated mode control reaction period of time */
	golem::Real ctrlSimReac;
	/** Simulated mode control prediction period of time */
	golem::Real ctrlSimPred;
	/** Simulated mode */
	bool ctrlSimMode;
	/** Simulated mode vector */
	golem::Vec3 ctrlSimModeVec;
	/** Simulated mode screen coords */
	golem::Vec2 ctrlSimModeScr;

	/** Waypoints */
	golem::Controller::State::Seq waypoints;
	/** Waypoint index */
	golem::U32 waypointIndex;

	/** Frame size */
	golem::Vec3 frameSize;
	/** Renderer */
	mutable golem::DebugRenderer renderer;
	/** Critical section */
	mutable golem::CriticalSection cs;

	/** Command time */
	golem::SecTmReal getCommandTime() const;
	/** Controller command */
	golem::Controller::State getCommand(golem::SecTmReal t = golem::SEC_TM_REAL_MAX) const;
	/** Controller frame */
	golem::Mat34 getFrame(const golem::Controller::State& state) const;

	/** Controller sim run */
	void ctrlSimRun();

	/** golem::UIRenderer: Render on output device. */
	virtual void render() const;
	/** golem::UIRenderer: Render on output device. */
	virtual void customRender() const {}

	/** golem::UIKeyboardMouse: Mouse button handler. */
	virtual void mouseHandler(int button, int state, int x, int y);
	/** golem::UIKeyboardMouse: Mouse motion handler. */
	virtual void motionHandler(int x, int y);
	/** golem::UIKeyboardMouse: Keyboard handler. */
	virtual void keyboardHandler(int key, int x, int y);

	/** Creates/initialises the ActiveCtrl */
	void create(const Desc& desc);

	/** Constructs the ActiveCtrl */
	WorkspaceCtrl(golem::Planner &planner, const Sensor::Map& sensors);
};

//------------------------------------------------------------------------------

};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_ACTIVECTRL_ARMHAND_WORKSPACE_ARMHAND_WORKSPACE_H_*/
