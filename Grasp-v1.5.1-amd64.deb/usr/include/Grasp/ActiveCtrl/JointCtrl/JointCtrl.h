/** @file JointCtrl.h
 *
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_ACTIVECTRL_JOINT_CTRL_JOINT_CTRL_H_
#define _GRASP_ACTIVECTRL_JOINT_CTRL_JOINT_CTRL_H_

//------------------------------------------------------------------------------

#include <Grasp/Core/ActiveCtrl.h>
#include <Grasp/Core/UI.h>
#include <Golem/Math/Vec2.h>

//------------------------------------------------------------------------------

extern "C" {
	GOLEM_LIBRARY_DECLDIR void* graspDescLoader(void);
};

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** JointCtrl is the interafce to a robot (right arm + hand), sensing devices and objects. */
class GOLEM_LIBRARY_DECLDIR JointCtrl : public ActiveCtrl, public UI {
public:
	/** JointCtrl factory */
	class GOLEM_LIBRARY_DECLDIR Desc : public ActiveCtrl::Desc {
	public:
		typedef golem::shared_ptr<Desc> Ptr;

		/** Coordinate tolerance at limits */
		golem::GenCoord tolerance;

		/** Trajectory velocity multiplier */
		golem::Real velocity;
		/** Trajectory acceleration multiplier */
		golem::Real acceleration;
		/** Trajectory duration */
		golem::SecTmReal duration;

		/** Trajectory increment */
		golem::Real increment;

		/** Frame size */
		golem::Vec3 frameSize;
		/** Frame size */
		golem::Vec3 frameSizeActive;

		/** Constructs from description object */
		Desc() {
			Desc::setToDefault();
		}
		/** Sets the parameters to the default values */
		virtual void setToDefault() {
			ActiveCtrl::Desc::setToDefault();

			tolerance.setToDefault();
			velocity = golem::Real(0.1);
			acceleration = golem::Real(0.1);
			increment = golem::Real(0.05)*golem::REAL_PI;
			duration = golem::SecTmReal(1.0);
			frameSize.set(golem::Real(0.2), golem::Real(0.2), golem::Real(0.2));
			frameSizeActive.set(golem::Real(0.3), golem::Real(0.3), golem::Real(0.3));
		}
		/** Assert that the description is valid. */
		virtual void assertValid(const Assert::Context& ac) const {
			ActiveCtrl::Desc::assertValid(ac);

			Assert::valid(tolerance.pos >= golem::REAL_ZERO && tolerance.vel >= golem::REAL_ZERO && tolerance.vel >= golem::REAL_ZERO, ac, "tolerance: <= 0");
			Assert::valid(velocity > golem::REAL_ZERO, ac, "velocity: <= 0");
			Assert::valid(acceleration > golem::REAL_ZERO, ac, "acceleration: <= 0");
			Assert::valid(increment > golem::SEC_TM_REAL_ZERO, ac, "increment: <= 0");
			Assert::valid(duration > golem::SEC_TM_REAL_ZERO, ac, "duration: <= 0");
			Assert::valid(frameSize.isPositive(), ac, "frameSize: <= 0");
			Assert::valid(frameSizeActive.isPositive(), ac, "frameSizeActive: <= 0");
		}

		/** Load descritpion from xml context. */
		virtual void load(golem::Context& context, const golem::XMLContext* xmlcontext);

		GRASP_CREATE_FROM_OBJECT_DESC2(JointCtrl, ActiveCtrl::Ptr, golem::Planner&, const Sensor::Map&)
	};

protected:
	/** Limits min */
	golem::GenConfigspaceCoord cmin;
	/** Limits max */
	golem::GenConfigspaceCoord cmax;
	
	/** Coordinate tolerance at limits */
	golem::GenCoord tolerance;
	/** Trajectory velocity multiplier */
	golem::Real velocity;
	/** Trajectory acceleration multiplier */
	golem::Real acceleration;
	/** Trajectory increment */
	golem::Real increment;
	/** Trajectory increment step */
	golem::U32 incrementStep;
	/** Trajectory duration */
	golem::SecTmReal duration;
	/** Current joint */
	golem::U32 joint;
	/** Frame size */
	golem::Vec3 frameSize;
	/** Frame size */
	golem::Vec3 frameSizeActive;
	/** Trajectory time stamp */
	golem::SecTmReal timeStamp;

	/** Render data */
	mutable golem::DebugRenderer renderer;

	/** golem::UIRenderer: Render on output device. */
	virtual void render() const;
	/** golem::UIRenderer: Render on output device. */
	virtual void customRender() const {}

	/** golem::UIKeyboardMouse: Mouse button handler. */
	virtual void mouseHandler(int button, int state, int x, int y);
	/** golem::UIKeyboardMouse: Mouse motion handler. */
	virtual void motionHandler(int x, int y);
	/** golem::UIKeyboardMouse: Keyboard handler. */
	virtual void keyboardHandler(int key, int x, int y);

	/** Creates/initialises the ActiveCtrl */
	void create(const Desc& desc);

	/** Constructs the ActiveCtrl */
	JointCtrl(golem::Planner &planner, const Sensor::Map& sensors);
};

//------------------------------------------------------------------------------

};	// namespace

//------------------------------------------------------------------------------

#endif /*_GRASP_ACTIVECTRL_JOINT_CTRL_JOINT_CTRL_H_*/
