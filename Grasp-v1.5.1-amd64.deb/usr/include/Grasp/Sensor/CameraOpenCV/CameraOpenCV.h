/** @file OpenCV.h
 * 
 * @author	Marek Kopicki
 *
 * @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
 *
 * @license  This file copy is licensed to you under the terms described in
 *           the License.txt file included in this distribution.
 *
 */

#pragma once
#ifndef _GRASP_CAMERA_OPENCV_OPENCV_H_
#define _GRASP_CAMERA_OPENCV_OPENCV_H_

//------------------------------------------------------------------------------

#include <Grasp/Core/Camera.h>

//------------------------------------------------------------------------------

extern "C" {
	GOLEM_LIBRARY_DECLDIR void* graspDescLoader(void);
};

//------------------------------------------------------------------------------

namespace grasp {

//------------------------------------------------------------------------------

/** OpenCV Camera */
class GOLEM_LIBRARY_DECLDIR CameraOpenCV : public Camera {
public:
	/** Camera description */
	class GOLEM_LIBRARY_DECLDIR Desc : public Camera::Desc {
	public:
		/** Creates Camera from the description. */
		GRASP_CREATE_FROM_OBJECT_DESC1(CameraOpenCV, Sensor::Ptr, golem::Context&)
	};

protected:
	/** Capture sequence start */
	virtual void start();
	/** Capture sequence stop */
	virtual void stop();

	/** Creates/initialises the Camera */
	void create(const Desc& desc);
	/** Constructs the Camera */
	CameraOpenCV(golem::Context& context);
};

//------------------------------------------------------------------------------

};	// namespace grasp

#endif /*_GRASP_CAMERA_OPENCV_OPENCV_H_*/
