/* used in gradient.c only */
extern int RofI[4];        /* xs, ys, xe, ye of the Region of Interest */
extern int doRofI;
extern int fix_thresh;       
extern int four_con;
extern char * grad_non_name;
extern char * derivative_name;
extern int derivatives_only;

