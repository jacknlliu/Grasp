#include <camcalb/matas/vector2.h>

void XYLL2pointset(t_LL list) ;
void XYintLL2pointset(t_LL list) ;
void YXintLL2pointset(t_LL list) ;
t_LL XYedgeSet2LLofV2(t_LLSet set);
t_LL XYpointSet2LLofV2(t_LLSet set, char * pointName);
t_LL PointStr2xyLL(char * s);
