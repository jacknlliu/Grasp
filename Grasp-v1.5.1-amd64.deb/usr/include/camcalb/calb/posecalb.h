#pragma once
#ifndef _CAMCALB_POSECALB_H_
#define _CAMCALB_POSECALB_H_

#include <stdlib.h>
#include <stdio.h>
#include <opencv2/opencv.hpp>
#include <opencv2/legacy/compat.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <camcalb/calb/ell_markers.h>
#include <camcalb/calb/CamPars.h>

namespace camcalb {

//-----------------------------------------------------------------------------

class CamParsCam : public CamPars
{
private:
  virtual void Read(FILE *file);
public:
  float cam_matrix[9];
  float distortion[4];
};

//-----------------------------------------------------------------------------

class CalibObj
{
public:
  CvPoint3D32f *model_points;
  CvPoint2D32f *img_points;
  int npoints;
  int cnt;
  bool have_pose;
  float t[3], r[3];    // pose (translation and rotation vector)
  float ti[3], ri[3];  // inverse pose
  IplImage *img;  // whence the image points come from

  CalibObj();
  ~CalibObj();
  void Load(const char *filename);
  void SavePose(const char *filename);
  void WriteRotationMatrix(FILE *file, float r[3]);
  void FindPose(CamParsCam &cam, const IplImage *img);
  void FindPosePOSIT(CamParsCam &cam, const IplImage *img);
  void ProjectPoint(float *R, float *t,
      float X, float Y, float Z, float *x, float *y, float *cam_matrix);
  void InvertPose(float t[3], float r[3], float ti[3], float ri[3]);
  void DrawProjectedPoints(CamParsCam &cam, IplImage *img);
  void DrawPose(CamParsCam &cam, IplImage *img, float *R = NULL, float *t = NULL);
  void DrawImagePoints(IplImage *img);
};

//-----------------------------------------------------------------------------

};

#endif // _CAMCALB_POSECALB_H_
