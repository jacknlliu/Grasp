#pragma once
#ifndef _CAMCALB_CAMCALB_H_
#define _CAMCALB_CAMCALB_H_

#ifdef WIN32
#define _USE_MATH_DEFINES
#endif

#include <stdlib.h>
#include <stdio.h>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <camcalb/calb/ell_markers.h>
#include <camcalb/calb/CamPars.h>

namespace camcalb {

//-----------------------------------------------------------------------------

// These are the parameters calculated by cvCalibrateCamera()
class CamParsPoses : public CamPars
{
private:
  void WriteRowVector(FILE *file, CvMat *m, int i) const;
protected:
  virtual void Write(FILE *file) const;
public:
  CvMat *cam_matrix;   // 3x3 camera matrix
  CvMat *dist_coeffs;  // 4x1 distortion coefficients
  CvMat *trans_vecs;   // translation parts of pose (camera to model) per image
  CvMat *rot_vecs;     // rotation parts of pose (camera to model) per image
  double mean_reproj_err;   // reprojection error
  int num_points;      // points per image
  int num_images;      // number of images
  CvMat *img_points;   // Nx2 array of 2D marker points, with N =
                       // num_points*num_images
  CvMat *model_points; // Nx3 array of 3D model points
  std::vector<std::string> img_names;  // names of images corresponding to poses

  CamParsPoses();
  virtual ~CamParsPoses();
  /**
   * Add an image to the list of calibration images.
   * @param img_name file name of the image to add
   * @param img the actual image, but note: we just store the filename and only
   *            use the actual image to get and check image size
   */
  void AddImage(const std::string &img_name, const IplImage *img);
  /**
   * Perform the actual calibration.
   * @param markers nxm marker point positions, with n = the number of
   *                calibration image and m the number of model points (same for
   *                each image)
   * @param model the calibration model
   */
  bool Calibrate(std::vector<CvPoint2D64f> &markers, Model &model);
  /**
   * Copy OpenCv calibration parameters to own internal paramters.
   */
  void OpenCVParametersToInternal();
  /**
   * Draw projected model points for given image number.
   * @param img IPL image to draw into
   * @param img_num image number in the sequence of calibration images
   * @param col color to draw the points
   * @param distorted_image whether the input image is distorted, or already
   *                        undistorted (in which case distortion is ommited in
   *                        the projection).
   */
  void DrawProjectedModelPoints(IplImage *img, int img_num, CvScalar col,
      bool distorted_image);
  /**
   * Draw detected marker image points points for given image number.
   * @param img IPL image to draw into
   * @param img_num image number in the sequence of calibration images
   * @param col color to draw the points
   */
  void DrawImagePoints(IplImage *img, int num, CvScalar col);

};

extern void DrawEllipse(IplImage *img, camcalb::Ellipse &e, CvScalar col);

extern void DrawEllipses(IplImage *img, std::vector<camcalb::Ellipse> &ells, CvScalar col);

extern void DrawPairs(IplImage *img, std::vector<EllipsePair> &pairs, CvScalar col);

extern void DrawMarker(IplImage *img, const CvPoint2D64f &p, CvScalar col);

extern void DrawMarkers(IplImage *img, std::vector<CvPoint2D64f>::const_iterator begin, std::vector<CvPoint2D64f>::const_iterator end, CvScalar col);

extern void DrawEdgels(IplImage *img, std::vector<CvPoint2D64f> &all_edgels, CvScalar col);

//-----------------------------------------------------------------------------

};

#endif // _CAMCALB_CAMCALB_H_
