#include <stdio.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <Eigen/Core>

using namespace std;
using namespace Eigen;

class IntrinsicTactile{

private: 

  // surface type, radius of surface in the case of sphere or plane
  char surface_type_;
  //double K_;
  double R_;

  double threshold_;

  // point coordinates in the sensor frame, force and torque at the contact point in gauss frame coordinates
  // the gauss frame expressed in the sensor frame
  Vector3f contact_point_;
  Vector3f contact_force_; // the coordinates are expressed in the gauss frame, with z component aligned with the normal, and x and y component in the tangent plane
  Vector3f contact_torque_;
  
  // the force/torque at the sensor frame
  Vector3f sensor_force_;
  Vector3f sensor_torque_;

  // According to the paper:
  // Contact Sensing from Force Measurements http://www.centropiaggio.unipi.it/sites/default/files/sensor-IJRR93.pdf
  // The surface should be positioned and oriented with respect to the sensor frame such that:
  // 1. Sphere: the origin of the sensor frame should coincide with the center of the sphere.
  // 2. Cylinder: the z-axis of the sensor frame must be aligned with the cylinder axis.
  // 3. Plane: the z-axis of the sensor frame must be aligned with the normal to the plane.
  //
  // In cases where this is not true, you can specify how your surface is positioned and oriented with respect to the sensor frame
  // by specifying a frame B in sensor frame coordinates.
  // Internally, the measurements are transformed to this frame including the point the torques are measured with respect to, such that
  // frame B is our sensor frame.
  Matrix3f rot_B_;
  Vector3f pos_B_;

  // the force/torque at frame B
  Vector3f sensor_force_B_;
  Vector3f sensor_torque_B_;

  // point coordinates in the B frame, force and torque at the contact point in gauss frame coordinates do not change
  // the gauss frame expressed in B frame
  Vector3f contact_point_B_;

  //gauss frameB
  Matrix4f gauss_frame_B_;

  Matrix4f gauss_frame_;
  
  // set data using values computed in frame B, automatically sets the data in sensor frame
  void setData(Vector3f cf, Vector3f ct, Vector3f cp);
  
public:  
  IntrinsicTactile();

  IntrinsicTactile(double t, char surface, double radius);
  
  ///////////////// SET FUNCTIONS  ///////////////////////
  //
  // s for spherical
  // c for cylindrical
  // p for planes
  void setSurface(char s){surface_type_ = s;}

  // if sphere/cylinder, R_ = radius of sphere/cylinder
  // if plane, R_ = offset in the positive z-axis
  void setR(double r){R_ = r;}

  // set rotation/position of your surface w.r.t. to the real sensor frame in order to have the frame correctly aligned with the surface
  void setOrientationB(Matrix3f R){ rot_B_ = R;}
  void setPositionB(Vector3f p){ pos_B_ = p;}

  void setThreshold(double t){threshold_ = t;}

  //////////////// MAIN FUNCTION //////////////////////////
  //
  // IN: RAW force/torque measurements
  //
  // If all settings are done correctly, this function sets everything else.
  void doCalculation(float ft[6]);
 
  // calculate the transformation from frame B to the gauss frame in frame B coordinates
  void calculateGaussFrame(float x, float y, float z);


  ///////////////// GET FUNCTIONS /////////////////////
  //
  // the data is returned in the sensor frame if frameB is false, otherwise it is returned in frameB
  // note that the force/torque are always expressed in the gauss frame coordinates therefore the values are the same.
  Matrix3f getData(bool frameB);
  
  // returns the transformation from the sensor frame to the gauss frame in sensor frame coordinates
  Matrix4f getGaussFrame(){return gauss_frame_;}

  double getRadius(){return R_;}
  Vector3f getContactPoint(){return contact_point_;}
};