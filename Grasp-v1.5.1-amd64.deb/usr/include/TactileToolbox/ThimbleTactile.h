#include <Eigen/Eigen>
#include <TactileToolbox/IntrinsicTactile.h>

using namespace std;
using namespace Eigen;

class ThimbleTactile{

private:  
  // point coordinates in the sensor frame, force and torque at the contact point in gauss frame coordinates
  IntrinsicTactile* surface_part;
  double threshold;
  Matrix3f realData;

  Matrix4f gauss_frame;

  
public:  
  
  ThimbleTactile(double,double);

	void ContactPointCalculation(float ft[]);
	
	Matrix3f getData(){return realData;}

	Matrix4f getGaussFrame(){return gauss_frame;}
};
