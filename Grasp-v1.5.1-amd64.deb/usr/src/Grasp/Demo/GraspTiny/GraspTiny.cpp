/** @file TinyGrasp.cpp
*
* @author	Marek Kopicki
*
* @copyright  Copyright (C) 2015 Marek Kopicki, University of Birmingham, UK
*
* @license  This file copy is licensed to you under the terms described in
*           the License.txt file included in this distribution.
*
*/

#include <Grasp/Tiny/Tiny.h>
#include <Grasp/Tiny/TinyPCL.h>
#include <Grasp/Tiny/TinyGolem.h>
#include <exception>
#include <thread>
#include <chrono>

using namespace grasp;

int main(int argc, char *argv[]) {
	// Tiny container should be alive during exception catching
	interop::tiny::Tiny::Ptr tiny;

	try {
		/*************************************************************************
		*
		* Initialisation
		*
		**************************************************************************/

		// create Tiny - initialise environment, load drivers and plugins (messages filtered in section <messages level="verbose"/>)
		if (argc < 2) {
			fprintf(stderr, "GraspDemoGraspTiny <configuration_file>\n");
			return 1;
		}
		tiny = interop::tiny::Tiny::create(argv[1]);

		/*************************************************************************
		*
		* Training
		*
		**************************************************************************/

		// load at least one model point cloud
		interop::Point3DCloud::Seq trainingClouds(2);
		// preferred: load/store directly interop::Point3DCloud::Seq, NOT '*.pcd' files
		interop::loadPCLCloud("GraspDemoTinyGraspTraining1.pcd", trainingClouds[0]);
		printf("TRAINING: points[1]=%lu\n", trainingClouds[0].size());
		// preferred: load/store directly interop::Point3DCloud::Seq, NOT '*.pcd' files
		interop::loadPCLCloud("GraspDemoTinyGraspTraining2.pcd", trainingClouds[1]);
		printf("TRAINING: points[2]=%lu\n", trainingClouds[1].size());

		// compute features
		interop::tiny::Feature3D::Seq trainingFeatures;
		interop::tiny::Sensor::get(*tiny)->process(trainingClouds, trainingFeatures);
		printf("TRAINING: features=%lu\n", trainingFeatures.size());

		// load model trajectory
		interop::Config::Seq trainingTrajectory;
		// preferred: load/store directly interop::Config::Seq, NOT '*.wp' files
		//interop::loadTrajectory(*tiny, "GraspDemoTinyGraspTraining.wp", trainingTrajectory);
		const interop::float_t positions[][27] = {
			{2.180801, -1.592194, -1.521202, 1.712632, -0.050701, -0.562921, 1.380559, -0.011319, 0.088750, 0.000000, 0.000000, 0.000000, 0.051394, 0.000000, 0.000000, 0.000000, 0.926323, 1.057778, 1.057778, 0.000000, 1.483530, 1.134464, 1.134464, 0.000000, 1.483530, 1.134464, 1.134464, },
			{1.991930, -1.639876, -1.497247, 1.625777, -0.039985, -0.470176, 1.401919, -0.011319, 0.252084, 0.005093, 0.005093, 0.000000, 0.264099, 0.065219, 0.065219, 0.000000, 0.926323, 1.057778, 1.057778, 0.000000, 1.483530, 1.134464, 1.134464, 0.000000, 1.483530, 1.134464, 1.134464, },
			{1.970219, -1.640791, -1.498651, 1.615291, -0.040220, -0.464042, 1.401852, -0.011319, 0.476014, 0.008186, 0.008186, 0.000000, 0.498640, 0.058318, 0.058318, 0.000000, 0.926323, 1.057778, 1.057778, 0.000000, 1.483530, 1.134464, 1.134464, 0.000000, 1.483530, 1.134464, 1.134464, },
		};
		for (size_t i = 0; i < sizeof(positions) / sizeof(positions[0]); ++i) {
			interop::Config config;
			std::copy(positions[i], positions[i] + sizeof(positions[0]) / sizeof(interop::float_t), config.cpos.v);
			// velocities can be ignored because only path is used to create configuration model
			trainingTrajectory.push_back(config);
		}
		printf("TRAINING: waypoints=%lu\n", trainingTrajectory.size());

		// create training data bundle
		interop::tiny::Training3D contactTraining3D;
		contactTraining3D.features = trainingFeatures;
		contactTraining3D.trajectory = trainingTrajectory;
		// contact type
		const std::string contactName = "pinchsupp";
		interop::tiny::Training3D::Map contactTraining3DMap;
		contactTraining3DMap.insert(std::make_pair(contactName, contactTraining3D));
		// contact models
		interop::tiny::Model3D::Map contactModelsMap;
		// optional: load/store directly interop::tiny::Model3D::Map
		// compute contact models from training data
		interop::tiny::Contact::get(*tiny)->findModel(contactTraining3DMap, contactModelsMap);
		for (auto &i : contactModelsMap) {
			printf("TRAINING: type=%s, paths=%lu, config_model_kernels=%lu, contact_models=%lu, reserved_size=%lu\n",
				i.first.c_str(), i.second.paths.size(), i.second.configs.size(), i.second.contacts.size(), i.second.reserved.size());
			for (auto &j : i.second.contacts)
				printf("\tcontact_model=%s, kernels=%lu\n", j.first.c_str(), j.second.size());
		}

		/*************************************************************************
		*
		* Test
		*
		**************************************************************************/

		// optional - move robot: obtain current state
		interop::Config state;
//		interop::tiny::Control::get(*tiny)->lookupState(tiny->time(), state);

		// optional - move robot: use pre-defined target in configuration space
//		interop::ConfigspaceCoord ctarget;
		//ctarget[0] = interop::float_t(2.05575);
		//ctarget[1] = interop::float_t(-0.926678);
		//ctarget[2] = interop::float_t(0.688772);
		//ctarget[3] = interop::float_t(-1.6953);
		//ctarget[4] = interop::float_t(0.721298);
		//ctarget[5] = interop::float_t(0.410064);
		//ctarget[6] = interop::float_t(0.531536);

		// optional - move robot: alternative: find target from workspace coordinates
//		interop::Mat34 frame;
		//frame.p[0] = interop::float_t(0.188549);
		//frame.p[1] = interop::float_t(-0.938590);
		//frame.p[2] = interop::float_t(0.170118);
		//frame.R.m11 = interop::float_t(0.520564); frame.R.m12 = interop::float_t(0.828488); frame.R.m13 = interop::float_t(-0.206449);
		//frame.R.m21 = interop::float_t(0.726453); frame.R.m22 = interop::float_t(-0.556817); frame.R.m23 = interop::float_t(-0.402767);
		//frame.R.m31 = interop::float_t(-0.448641); frame.R.m32 = interop::float_t(0.059690); frame.R.m33 = interop::float_t(-0.891716);
//		interop::WorkspaceCoord wtarget;
//		wtarget[0] = frame; // by default only the first kinematic chain is used in path planning (configurable in xmls)
//		interop::WorkspaceDist werr;
//		interop::tiny::Control::get(*tiny)->findTarget(state.cpos, wtarget, ctarget, werr);
//		printf("tiny::Control::findTarget(): error=(%f, %f)\n", werr[0].lin, werr[0].ang);

		// optional - move robot: find trajectory to the target pose
		interop::Config::Seq ctrajectory;
//		interop::tiny::Control::get(*tiny)->findTrajectory(state.cpos, ctarget, ctrajectory);
//		printf("tiny::Control::findTrajectory(): length=%lu\n", ctrajectory.size());

		// optional - move robot: send trajectory
//		interop::tiny::Control::get(*tiny)->sendCommand(ctrajectory.data(), ctrajectory.size());

		// optional - move robot: wait until the last waypoint has been sent to the controller
		//  + 2 x control cycle duration (max command latency) to make sure the robot is not moving
		//  + extra 1 second to stabilise the robot
//		interop::tiny::Control::get(*tiny)->waitForTrajectoryEnd();
//		std::this_thread::sleep_for(std::chrono::milliseconds(std::uint32_t(1000.0 * 2 * interop::tiny::Control::get(*tiny)->cycleDuration()) + 1000));

		interop::Point3DCloud::Seq testClouds(1);
		// optional - use depth camera: capture point cloud
//		interop::tiny::Sensor::get(*tiny)->capture(testClouds[0]);
		// alternative: load from disk
		interop::loadPCLCloud("GraspDemoTinyGraspTest.pcd", testClouds[0]);
		printf("TEST: points=%lu\n", testClouds[0].size());

		// compute features
		interop::tiny::Feature3D::Seq testFeatures;
		interop::tiny::Sensor::get(*tiny)->process(testClouds, testFeatures);
		printf("TEST: features=%lu\n", testFeatures.size());

		// Find path hypotheses
		interop::tiny::Query query;
		interop::tiny::Contact::get(*tiny)->findQuery(contactModelsMap, testFeatures, query);
		printf("TEST: hypotheses=%lu\n", query.paths.size());

		// select feasible contact trajectory
		interop::tiny::Trajectory testTrajectory;
		interop::tiny::Contact::get(*tiny)->selectTrajectory(query, testTrajectory);
		printf("TEST: waypoints=%lu\n", testTrajectory.trajectory.size());

		// optional - move robot: obtain current state
		interop::tiny::Control::get(*tiny)->lookupState(tiny->time(), state);
		// optional - move robot: find trajectory to the beginning of contact trajectory
		interop::tiny::Control::get(*tiny)->findTrajectory(state.cpos, testTrajectory.trajectory.front().cpos, ctrajectory);
		
		printf("TEST: grasping!\n");
		// optional - move robot: go to to the beginning of contact trajectory, wait to finish
		interop::tiny::Control::get(*tiny)->sendCommand(ctrajectory.data(), ctrajectory.size());
		interop::tiny::Control::get(*tiny)->waitForTrajectoryEnd();
		// optional - move robot: perform contact trajectory, wait to finish
		interop::tiny::Control::get(*tiny)->sendCommand(testTrajectory.trajectory.data(), testTrajectory.trajectory.size());
		interop::tiny::Control::get(*tiny)->waitForTrajectoryEnd();

		// optional: run interactive menu
		printf("Ready!\n");
		while (tiny->menu());
	}
	catch (const std::exception& ex) {
		fprintf(stderr, "tiny::Tiny: %s\n", ex.what());
		return 1;
	}

	return 0;
}